import CountryModel from "../models/Country.js";
import LanguageModel from "../models/Language.js";
import TaxonomyModel from "../models/Taxonomy.js";
import { convertToSlug, organizeIntoTree } from "../utils/utils.js";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import path from 'path'
import fs from 'fs'
import csv from 'fast-csv';
import { once } from 'events';
import UserModel from "../models/User.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class LanguageController{
    static add_languages = (req, res)=>{
        // res.send("DAta created ---");
        res.render('add-language');
    }
    static edit_language = async (req, res)=>{
      const info= await LanguageModel.findById(req.params.id);
      console.log(info)
      res.render('edit-language',{info});
    }

    static get_languages = async (req, res)=>{
        try {
            const result = await LanguageModel.find();
            // res.send(result);
            const all_cookies = req.cookies;
            const current_lang = all_cookies.current_lang || 'en';
            res.render('languages', {result, current_lang});
        } catch (error) {
            res.send(error);
        }
    }

    static save_language = async (req, res)=>{
        // res.send(req.body);
        try {
            const {name, code} = req.body;
            const file = req.file;
            var lang_doc = new LanguageModel({
                language:name,
                langCode:code,
                userId:req.session.userId
            });

            var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
              lang_doc.thumbnail = uploaded_path;
            }

            const result = await lang_doc.save(lang_doc);
            res.status(201).json({ status: 'success', data: result });

        } catch (error) {
            console.log("error message =====");
            console.log(error);
            return res.status(500).json({ error: 'Failed to add langauge.' });   
        }
    }

    static update_language = async (req, res) =>{
      try {
        const {name,code,image} = req.body;
        const file = req.file;
      
        const lang_doc = {
          language: name,
          langCode: code,
          thumbnail:image,
            
        };

        var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
              lang_doc.thumbnail = uploaded_path;
            }

        const result = await LanguageModel.findByIdAndUpdate(req.params.id, lang_doc);

        res.status(201).json({ status: 'success', data: result });
      } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Failed to update month.' });
      }
      
    }

    static UpdateDocById = (req, res)=>{
        res.send("update doc ---");
    }
    static DeleteDocById = (req, res)=>{
        res.send("delete doc ---");
    }

   
    
  static get_countries = async (req,res) =>{
    try {
      const result = await CountryModel.find();
      let user = await UserModel.findById(req.session.userId);
      // res.send(result);
      const all_cookies = req.cookies;
      const current_lang = all_cookies.current_lang || 'en';
      res.render('countries', {user, result, current_lang});
    } catch (error) {
      console.log("erro contries");
      console.log(error);
      res.send(error);
    }
  }

  static add_countries = (req, res)=>{
    res.render('add-countries');
  }

  static edit_countries = async (req, res)=>{
    const info= await CountryModel.findById(req.params.id);
    console.log(info)
    res.render('edit-countries',{info});
  }

  static save_countries = async (req, res)=>{
    try {
        const {name, code,thumbnail} = req.body;
        const file = req.file;
        var country_doc = new CountryModel({
          country:name,
          countryCode:code,
          thumbnail:thumbnail,
          slug:convertToSlug(name),
        });

        var uploaded_path = '';
        if (file && file.path && file.path !== "undefined") 
        {
          uploaded_path =  file.path.replace(`public${path.sep}`, '');
          country_doc.thumbnail = uploaded_path;
        }

        const result = await country_doc.save(country_doc);
        res.status(201).json({ status: 'success', data: result });

    } catch (error) {
        console.log("error message =====");
        console.log(error);
        return res.status(500).json({ error: 'Failed to add country.' });   
    }
  }

  static update_countries = async (req, res) =>{
    try {
      const {name,code,image,term_id} = req.body;
      const file = req.file;

      let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
      
    
      const coun_doc = {
        country: name,
        countryCode: code,
        term_id:term_id,
        thumbnail:image,
        slug:slug,
          
      };
      var uploaded_path = '';
      if (file && file.path && file.path !== "undefined") 
      {
        uploaded_path =  file.path.replace(`public${path.sep}`, '');
        coun_doc.thumbnail = uploaded_path;
      }

      const result = await CountryModel.findByIdAndUpdate(req.params.id, coun_doc);

      res.status(201).json({ status: 'success', data: result });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ error: 'Failed to update' });
    }
    
  }
  static delete_countries = async (req, res) =>{
    try {
      await CountryModel.deleteMany();
      res.status(200).json({ message: 'All countries deleted successfully.' });
    } catch (error) {
      console.error('Error deleting countries:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  } 

 
}

export default LanguageController;