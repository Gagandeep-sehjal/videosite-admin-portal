import mongoose from "mongoose";

// Defining Schema 
const userSchema = new mongoose.Schema({
    user_id: {type: Number}, // Add a new field for the auto-incremented ID
    user_name:{type:String},
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    membertitle:{ type: String },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    thumbnail: String,
    gender: { type: String, enum: ['male', 'female'] },
    phone: {type: Number},
    loggedin:{type:String},
    countryid: { type: mongoose.Schema.Types.ObjectId, ref: 'tora_countries' }, // Reference to the "tora_countries" collection
    preferredLang: [{ type: mongoose.Schema.Types.ObjectId, ref: 'tora_languages' }], // Reference to the "tora_languages" collection
    Lang_code: [{ type:String }], 
    status: { type: String, enum: ['active', 'inactive','pending','expired','trash','reset_required'] },
    role: { type: String, enum: ['admin', 'speaker','user','uploader'] },
    automatic_publish: {
      type: Number,
      enum: [0, 1],
      default: 0, // Set the default value to 0 or 1, whichever you prefer
      required: true // Set this to true if you want to require this field
    },
    video_publisher: {
      type: Number,
      enum: [0, 1],
      default: 0, // Set the default value to 0 or 1, whichever you prefer
    },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
  });

const UserModel = mongoose.model("tora_users", userSchema);

export default UserModel;