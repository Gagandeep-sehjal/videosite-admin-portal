import UserModel  from "../models/User.js";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import LanguageModel from "../models/Language.js";
import mongoose from "mongoose";
import ToraLog from "../models/ToraLog.js";
import ToraVideoModel from "../models/ToraVideo.js";
import {formatDatetime, verifycode,signUpCognito, resetpassword, sendResetPasswordEmail } from "../utils/utils.js";
import AmazonCognitoIdentity from 'amazon-cognito-identity-js';
import UserSessionModel from "../models/UserSession.js";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import CountryModel from "../models/Country.js";


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


const poolData = {
  UserPoolId: 'your-id',
  ClientId: 'your-id',
};




const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);


class UserController{

    static login = async (req, res) => {
      try {
        const session_user = await UserSessionModel.findOne({userId:req.session.userId});
        if (req.session && req.session.userId && session_user != null) {
          res.redirect('/portal/dashboard');
        }else{
          const message = req.session.message;
          // Clear the message from the session to display it only once
          delete req.session.message;
          res.render("login", { message });
        }
      } catch (error) {
        console.log(error);
        res.send(error);
      }
    }

    static registration = async (req, res) => {
        try {
            const message = req.session.message;
            delete req.session.message;
            const languages = await LanguageModel.find();
            // const languages = [];
            
            res.render("register", { message, languages });
        } catch (error) {
          console.log(error);
          res.send(error);
        }
    }

    static dashboard = async (req, res) => {
      try{
        let page_title = "Dashboard Page";
        const all_cookies = req.cookies; 
        var current_lang = 'en';
        if(all_cookies.current_lang){
          var current_lang = all_cookies.current_lang;
        }

        const aggregationPipeline = [
          {
              $lookup: {
                  from: 'tora_users', // The collection you want to join with
                  localField: 'userId', // Field from the "tora_videos" collection
                  foreignField: '_id',  // Field from the "tora_users" collection
                  as: 'user' // Alias for the joined data
              }
          },
          {
              $lookup: {
                  from: 'tora_languages', // The collection you want to join with
                  localField: 'lang', // Field from the "tora_videos" collection
                  foreignField: 'langCode',  // Field from the "tora_users" collection
                  as: 'language' // Alias for the joined data
              }
          },
          {
              $lookup: {
                  from: 'tora_term_relations', // The collection you want to join with
                  localField: '_id', // Field from the "tora_videos" collection
                  foreignField: 'objectId',  // Field from the "tora_users" collection
                  as: 'taxonomies' // Alias for the joined data
              }
          },
          {
              $lookup: {
                  from: 'tora_taxonomies',
                  localField: 'taxonomies.termId',
                  foreignField: '_id',
                  as: 'termRelations',
              },
          },
          {
              $addFields: {
              'termlang': {
                  $filter: {
                  input: '$termRelations.translations',
                  as: 'translation',
                  cond: { 
                  },  
                  },
              },
              },
          },
          {
              $project: {
                  taxonomies: 0, // Exclude the termRelations array from the result
              },
          },
      ];
        let user = await UserModel.findById(req.session.userId);
        const yo = await ToraVideoModel.aggregate(aggregationPipeline).sort({publishedAt:-1}).limit(4);
        let latest_content=await ToraVideoModel.find({status:"publish"},{thumbnail:1,title:1,publishedAt:1}).sort({publishedAt:-1}).limit(3)
        res.render("dashboard", {page_title, user, current_lang,latest_content,yo,formatDatetime});
      
      } catch (error) {
        console.log(error);
        res.send(error);
      }
    }

    static logout = (req, res) => {
        req.session.destroy((err) => {
            if (err) {
              console.error('Error destroying session:', err);
            }
            res.redirect('/login'); // Redirect to the login page after logout
        });
    }

    static userRegistration = async (req, res) => {
      try{
        const {first_name, last_name, email, password, language, gender} = req.body;
        

        // let signUpResult = await signUpCognito(req, res);

        // let response = {
        //     username:signUpResult.user.username,
        //     id:signUpResult.userSub,
        //     success:true
        // }
        
        // if(response.username){
          const user = await UserModel.findOne({email:email});
          if(user){
              req.session.message = 'Email already exists.';
              res.redirect('/register');
          }else{
              if(first_name && last_name && email && password && gender){
                  // if(password === password_confirmation){
                      try {
                          const salt = await bcrypt.genSalt(10);
                          const hashPassword = await bcrypt.hash(password, salt);

                          const lastUser = await UserModel.findOne({}, { user_id: 1 }).sort({ _id: -1 }).exec();
                          let lastAutoIncrementId = 1;
                          if(lastUser && lastUser.user_id){
                              lastAutoIncrementId = lastUser.user_id+1;
                          }
                          const doc = new UserModel({
                              user_id: lastAutoIncrementId,
                              firstName:first_name,
                              lastName:last_name,
                              email:email, 
                              password:hashPassword, 
                              // preferredLang:language,
                              status:"inactive",
                              gender:gender,
                              role:'user',
                          });

                          if(language){
                            doc.preferredLang = language;
                          }

                          await doc.save();
                          const saved_user = await UserModel.findOne({email:email});
                          // Generate JWT Token 
                          // const token = jwt.sign({userId: saved_user._id}, process.env.JWT_SECERT_KEY, {expiresIn: '5d'})
                          // res.status(201).send({"status":"success", "message": "Register successfully.", "token": token})
                          req.session.userId = doc._id;
                          req.session.email = email;
                          console.log("this is our doc id");
                          console.log(doc._id);
                          // req.session.password = password;
                          // res.redirect("/portal/dashboard");
                          res.redirect(`/verifycode/${doc._id}`);
                      } catch (error) {
                          console.log("user regstration error =====");
                          console.log(error);
                          // res.send(error);
                          // res.send({"status":"failed", "message": "Unable to register."});
                          req.session.message = 'Unable to register.';
                          res.redirect('/register');
                          // req.session.message = 'Confirmation password does not match.';
                          // res.redirect('/register');
                      }
              }else{
                  req.session.message = 'All fields are required.';
                  res.redirect('/register');
              }
          }
        // }
        // else{
        //   req.session.message = 'Unable to create users';
        //   res.redirect('/register');
        // }
      } catch (error) {
        console.log(error);
        res.send(error);
      }
    }

    static userLogin = async (req, res) =>{

        try {
          const {email, password} = req.body;

          const authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
              Username: email,
              Password: password
          });

          const userData = {
            Username: email,
            Pool: userPool
        };

        const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

          cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: async (resultdata) =>{
                let accessToken = resultdata.getAccessToken().getJwtToken();
                let idToken = resultdata.getIdToken().getJwtToken();
                let refreshToken = resultdata.getRefreshToken().getToken()
                const decoded = jwt.decode(accessToken, { complete: true });
                const iddecode = jwt.decode(idToken, { complete: true });
                const refreashdecode = jwt.decode(refreshToken, { complete: true });
                if(iddecode && iddecode.payload){
                  req.session.cognito_email = iddecode.payload.email;
                  req.session.cognito_name = iddecode.payload.name;
                }

                if(req.session.cognito_email){
                  let result = await UserModel.findOne({email:req.session.cognito_email});
                  // let result = await UserModel.findOne({email:email});
                  if(result != null && result.status != "reset_required"){
                    const isMatch = await bcrypt.compare(password, result.password);
                    if(result.email == email && isMatch){
                      req.session.userId = result._id;
                      req.session.email = email;
                      const userSession = new UserSessionModel({
                        userId: result._id,
                        userEmail: email,
                        // You can add more fields here if needed
                      });
                      await userSession.save();

                      res.redirect("/portal/dashboard");
                    }else{
                      req.session.message = 'Email or Password not valid.';
                      res.redirect('/login');
                    }
                  }
                  else if(result.status == "reset_required"){
                    req.session.message = '<span class="text-danger">Your password is reset. Reset code is sent to your email address. <a href="/reset-password" class=""><u>Click here</u></a> to get new password.</span>';
                    res.redirect('/login');
                  }
                  else{
                    req.session.message = 'You are not a registered user.';
                    res.redirect('/login');
                    // res.send(req.session.message);
                  }
                  res.send(result);
                }else{
                  res.send("you are not authenticate user");
                }
              },
            onFailure: err => {
               console.log(err);
               console.log("check failed error ===");
                // res.send(err);
                if(err.name == "NotAuthorizedException"){
                  req.session.message = 'You are not a registered user.';
                  res.redirect('/login');
                }
                else if(err.name == "PasswordResetRequiredException"){
                  res.redirect('/reset-password');
                }
                else{
                  req.session.message = "Unable to logged in";
                  res.redirect('/login');
                }
               
            },

          });

          res.send(authenticationDetails);
        } catch (error) {
            console.log("user login error is this -----");
            console.log(error);
            req.session.message = "Unable to logged in";
            res.redirect('/login');
        }


        // try {
        //     const {email, password} = req.body;
        //     const result = await UserModel.findOne({email:email});
        //     if(result != null){
        //         const isMatch = await bcrypt.compare(password, result.password);
        //         // console.log("matching password");
        //         // console.log(isMatch);
        //         if(result.email == email && isMatch){
        //             // console.log("you are in ---");
        //             // Generate JWT Token 
        //             const token = jwt.sign({userId: result._id}, process.env.JWT_SECERT_KEY, {expiresIn: '5d'})
        //             // res.status(201).send({"status":"success", "message": "Login successfully.", "token": token});
        //             req.session.userId = result._id;
        //             req.session.email = email;
        //             // req.session.password = password;
        //             res.redirect("/portal/dashboard");
        //         }else{
        //             // res.status(201).send({"status":"failed", "message": "Email or Password not valid."});
        //             req.session.message = 'Email or Password not valid.';
        //             res.redirect('/login');
        //             // res.send(req.session.message);
        //         }
        //     }else{
        //         // res.status(201).send({"status":"failed", "message": "You are not register user."});
        //         req.session.message = 'You are not a registered user.';
        //         res.redirect('/login');
        //         res.send(req.session.message);
        //     }
        // } catch (error) {
        //     // console.log(error);
        //     // res.send({"status":"failed", "message": "Internal Server Error."})
        //     req.session.message = 'You are not a registered user.';
        //     res.redirect('/login');
        //     // res.send(req.session.message);
        // }
    }

    static changeUserPassword = async(req, res)=>{
        const {password, password_confirmation} = req.body;
        if(password && password_confirmation){
            if(password !== password_confirmation){
                res.send({"status":"failed", "message": "New Password and confirm password does not match"});
            }else{
                const salt = await bcrypt.genSalt(10);
                const hashPassword = await bcrypt.hash(password, salt);
            }
        }else{
            res.send({"status":"failed", "message": "All fields are required."})
        }
    }

    static loggedUser = async (req, res) => {
        res.send({ "user": req.user })
    }

    static sendUserPasswordResetEmail = async (req, res) => {
      const { email } = req.body
      if (email) {
        const user = await UserModel.findOne({ email: email })
        if (user) {
          const secret = user._id + process.env.JWT_SECRET_KEY
          const token = jwt.sign({ userID: user._id }, secret, { expiresIn: '15m' })
          const link = `http://127.0.0.1:3000/api/user/reset/${user._id}/${token}`
          console.log(link)
          // // Send Email
          // let info = await transporter.sendMail({
          //   from: process.env.EMAIL_FROM,
          //   to: user.email,
          //   subject: "GeekShop - Password Reset Link",
          //   html: `<a href=${link}>Click Here</a> to Reset Your Password`
          // })
          res.send({ "status": "success", "message": "Password Reset Email Sent... Please Check Your Email" })
        } else {
          res.send({ "status": "failed", "message": "Email doesn't exists" })
        }
      } else {
        res.send({ "status": "failed", "message": "Email Field is Required" })
      }
    }

    static userPasswordReset = async (req, res) => {
      const { password, password_confirmation } = req.body
      const { id, token } = req.params
      const user = await UserModel.findById(id)
      const new_secret = user._id + process.env.JWT_SECRET_KEY
      try {
        jwt.verify(token, new_secret)
        if (password && password_confirmation) {
          if (password !== password_confirmation) {
            res.send({ "status": "failed", "message": "New Password and Confirm New Password doesn't match" })
          } else {
            const salt = await bcrypt.genSalt(10)
            const newHashPassword = await bcrypt.hash(password, salt)
            await UserModel.findByIdAndUpdate(user._id, { $set: { password: newHashPassword } })
            res.send({ "status": "success", "message": "Password Reset Successfully" })
          }
        } else {
          res.send({ "status": "failed", "message": "All Fields are Required" })
        }
      } catch (error) {
        console.log(error)
        res.send({ "status": "failed", "message": "Invalid Token" })
      }
    }

    static languages = async (req,res) =>{
      const languages = await LanguageModel.find();
      console.log("langauges");
      console.log(languages);
    }

    static user_list = async (req, res) =>{
      try {
          const all_cookies = req.cookies;
          const current_lang = all_cookies.current_lang || 'en';
          let user = await UserModel.findById(req.session.userId);
          let message = req.session.message;
          delete req.session.message;

          let adminuser = await UserModel.countDocuments({role:"admin", status: { $nin: ['trash', 'inactive'] }});
          // let allsubs = await UserModel.countDocuments({ status: { $ne: 'trash' } });
          // let rabbiuser = await UserModel.countDocuments({role:"speaker", status: { $ne: 'trash' }});
          // let simpleuser = await UserModel.countDocuments({role:"user", status: { $ne: 'trash' }});
          // let uploaderuser = await UserModel.countDocuments({role:"uploader", status: { $ne: 'trash' }});
          let allsubs = await UserModel.countDocuments({ status: { $nin: ['trash', 'inactive'] } });
          let rabbiuser = await UserModel.countDocuments({role:"speaker", status: { $nin: ['trash', 'inactive'] }});
          let simpleuser = await UserModel.countDocuments({role:"user", status: { $nin: ['trash', 'inactive'] }});
          let uploaderuser = await UserModel.countDocuments({role:"uploader", status: {$nin: ['trash', 'inactive'] }});
          let inactiveuser = await UserModel.countDocuments({status:"inactive"});
          let pending = await UserModel.countDocuments({status:"pending"});
          let trashcount = await UserModel.countDocuments({status:"trash"});
          let resetusercount = await UserModel.countDocuments({status:"reset_required"});
          res.render('users', {message, user, resetusercount,adminuser, rabbiuser, simpleuser,uploaderuser,allsubs,inactiveuser, current_lang, trashcount, pending});
      } catch (error) {
        console.log("error of user list");
        console.log(error); 
        res.send({ "status": "failed", "message": "Internal server Error" })  
      }
    }

    static add_users = async (req, res) =>{
      const all_cookies = req.cookies;
      const current_lang = all_cookies.current_lang || 'en';
      let user = await UserModel.findById(req.session.userId);
      const languages = await LanguageModel.find();
      const countries= await CountryModel.find();
      res.render('add-user', {current_lang, languages, user,countries});
    }

    static edit_users = async (req, res) =>{
      const all_cookies = req.cookies;
      const current_lang = all_cookies.current_lang || 'en';
      let user = await UserModel.findById(req.session.userId);
      const userPipeline = [
        {
            $lookup:{
                from:'tora_languages',
                localField:'preferredLang',
                foreignField:'_id',
                as:'language'
            }
        },
        {
          $match:{
            '_id': new mongoose.Types.ObjectId(req.params.id) 
          } 
        },
        {
          $limit: 1, // Limit the result to one document
        },
    ];


      const user_data = await UserModel.aggregate(userPipeline);
      const user_info = user_data[0];

      // res.send(user);

      const languages = await LanguageModel.find();
 

      console.log("user data");
      console.log(user);

      const user_log = await ToraLog.aggregate([
        {
          $match: {
            $and: [
              { entity: 'user' },
             { entityId: new mongoose.Types.ObjectId(req.params.id) }, // Assuming req.params.id is the ObjectId
            ],
          },
        },
        {
          $lookup: {
            from: 'tora_users', // Name of the tora_user collection
            localField: 'user', // Field in ToraLog collection to match
            foreignField: '_id', // Field in tora_user collection to match
            as: 'userData', // Name for the merged user data field
          },
        },
      ]);
      const message = req.session.message;
      const countries= await CountryModel.find();
      res.render('user-edit', {user, current_lang, languages, user_log, message, user_info,countries});
    }

    static verify_code = async (req, res) =>{
      // res.send(req.params);
      let id = new mongoose.Types.ObjectId(req.params.id);
       let user_info = await UserModel.findOne(id);
      //  res.send(user_info);
      //  if(user_info){
      //    verifycode(user_info);
      //  }
      const message = req.session.message;
      // Clear the message from the session to display it only once
      delete req.session.message; 
       res.render('verify-code', {message, id, user_info});
    }

    static verify_code_form = async (req, res) =>{
      const message = req.session.message;
      res.render("verify-code-form", {message});
    }

    static verify_code_saving = async (req, res) =>{
      try {
        const {username, code} = req.body;
        let result = await verifycode(username, code);
        if(result == "SUCCESS"){
          const updateFields = {
            status:"active",
          };
          const update_result = await UserModel.findOneAndUpdate({ email: username }, updateFields, { new: true });
          res.status(201).send({"status":"success", "message": "Your email is verified you can register now.", "response": update_result})
        }else{
          res.send({"status":"failed", "message": "An error occure unable to verify."});
        }
      } catch (error) {
        console.log("code verification error during register");
        console.log(error);
        if(error.name == "ExpiredCodeException"){
          res.send({"status":"failed", "message": "Invalid code provided, please request a code again."});
        }else{
          res.send({"status":"failed", "message": "An error occurred."});
        }
      }
    }

    static save_verify_code = async (req, res) =>{
      // res.send(req.params.id);
      const {id} = req.params;
      try {
        const {username, code} = req.body;
        let result = await verifycode(username, code);
        // res.send(result);
        console.log("after verification value ====");
        console.log(result);
        if(result == "SUCCESS"){
          const updateFields = {
            status:"active",
          };
        let mongoid = new mongoose.Types.ObjectId(id);
        const update_result = await UserModel.findByIdAndUpdate(mongoid, updateFields);
        // const update_result = await UserModel.findById(mongoid);
        // console.log(update_result);
        res.redirect('/login');
        }else{
          req.session.message = "An error occurred.";
          res.redirect(`/verifycode/${id}`);
        }
      } catch (error) {
        console.log(error);
        if(error.name == "ExpiredCodeException"){
          req.session.message = "Invalid code provided, please request a code again.";
          res.redirect(`/verifycode/${id}`);
        }else{
          req.session.message = "An error occurred.";
          res.redirect(`/verifycode/${id}`);
        }
      }
      
    }

    static resend_code = async (req, res) =>{
      try {
        const { id, user_email } = req.body;
    
        const userData = {
          Username: user_email,
          Pool: userPool,
        };
    
        const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    
        const resendConfirmationCode = () =>
          new Promise((resolve, reject) => {
            cognitoUser.resendConfirmationCode((err, data) => {
              if (err) {
                reject(err);
              } else {
                resolve(data);
              }
            });
          });
    
        const data = await resendConfirmationCode();
    
        console.log('Code resent successfully', data);
        req.session.message = 'Code resent successfully.';
        // res.send(data);
        res.redirect(`/verifycode/${id}`);
      } catch (error) {
        console.log(error, error.stack);
        req.session.message = 'An error occurred.';
        res.redirect(`/verifycode/${id}`);
      }

    }

    static resend_code_app = async (req, res) =>{
      try {
        const { username } = req.body;
    
        const userData = {
          Username: username,
          Pool: userPool,
        };
    
        const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    
        const resendConfirmationCode = () =>
          new Promise((resolve, reject) => {
            cognitoUser.resendConfirmationCode((err, data) => {
              if (err) {
                reject(err);
              } else {
                resolve(data);
              }
            });
          });
    
        const data = await resendConfirmationCode();
    
        res.status(201).send({"status":"success", "message": "Code resent successfully to email address", "response": data})
      } catch (error) {
        console.log("error while resending code.....")
        console.log(error, error.stack);
        res.send({"status":"failed", "message": "An error occurred."});
      }

    }

    static singout_user = async (req, res) =>{
      // res.send(req.params.id);
      try{
        const id =  new mongoose.Types.ObjectId(req.params.id);
        const delete_user = await UserSessionModel.deleteMany({userId:id});
        req.session.message = 'User is sign out.';
        res.redirect(`/portal/users/edit/${id}`); 
      }
      catch(error){
        req.session.message = 'An error occurred.';
        res.redirect(`/portal/users/edit/${id}`);
      }
    }


    static sendresetemail = async (req, res) =>{
      try {
        const id =  new mongoose.Types.ObjectId(req.params.id);
        const User = await UserModel.findOne({ _id: id });
        let email = User.email;
        const sendpassmail = await sendResetPasswordEmail(email);
        console.log(sendpassmail);
        console.log("mail return data");
        if(sendpassmail){
          const updateFields = {
            status:"reset_required",
          };
          const update_result = await UserModel.findByIdAndUpdate(id, updateFields);
          res.status(201).json({ status: 'success', data: sendpassmail });
        }else{
          return res.status(500).json({ error: "Unable to reset password"  });
        }
        // res.send(sendpassmail);
      } catch (error) {
        console.log("email reset error");
        console.log(error);
        console.log(error.name);
        let err = "Something went wrong";
        if(error.name){
          err = error.message;
        }
        return res.status(500).json({ error: err  });
      }
         
    }


    static resetpassword = (req, res) =>{
      let message = req.session.message;
      res.render("reset-password", {message});
    }

    static setresetpassoword = async (req, res) =>{
      // res.send(req.body);
      try {
       const restpass = await resetpassword(req, res);
       console.log(restpass);
       console.log("checking restpass");
       if(restpass){
        const salt = await bcrypt.genSalt(10);
        const hashPassword = await bcrypt.hash(req.body.password, salt);
        UserModel.findOneAndReplace()
        const updatedUser = await UserModel.findOneAndUpdate(
          { email: req.body.email },
          { $set: { password: hashPassword, status:"active" } },
          { new: true } // Return the updated document
        );
        if (updatedUser) {
          res.status(201).json({ status: 'success', data: updatedUser });
        }else{
          return res.status(500).json({ error: "Unable to update"  });
        }
       }else{
        return res.status(500).json({ error: "Unable to update"  });
       }
      //  res.send(restpass);
      } catch (error) {
        console.log("errro reset");
        console.log(error);
        console.log(error.name);
        // res.send(error);
        // res.status(500).json({ error: error.message || "An error occurred during password reset." });
        let err = "Something went wrong";
        if(error.name){
          err = error.message;
        }
        return res.status(500).json({ error: err  });
      }
    }


    
    
}

export default UserController;