import mongoose from 'mongoose';


const monthSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        unique:true
    },
    slug: {
        type: String,
        required: true
    },
    description: String,
   
});

// Create the Taxonomy model
const MonthModel = mongoose.model('month_data', monthSchema);

export default MonthModel;
