import express from 'express';
const router = express.Router();
import UserController from '../controllers/userController.js';
import checkUserAuth from '../middleware/auth-midleware.js';
import checkUserWebAuth from '../middleware/auth-web-midleware.js';
import UserApiController from '../controllers/Api/UserApiController.js';

// middleware 
// router.use('/changepassword', checkUserAuth);
// router.use('/loggeduser', checkUserAuth)
// router.use('/user-login-app', checkUserAuth)
router.use(['/changepassword', '/loggeduser'], checkUserAuth);
router.use('/portal/dashboard', checkUserWebAuth)
router.get('/', checkUserWebAuth, (req, res) => {
    // User is not authenticated, so redirect to the login page
    res.redirect('/portal/dashboard');
});

// Inside your Express.js server setup
// router.get('/auth/google', passport.authenticate('google', { scope: ['dashboard'] }));


// Public routes 
// router.get('/', UserController.login);
router.get('/login', UserController.login);
router.get('/register', UserController.registration);
router.post('/register', UserController.userRegistration);
// router.get('/dashboard', UserController.dashboard);
router.post('/login', UserController.userLogin);
router.get('/logout', UserController.logout);
router.get('/signout-user/:id', UserController.singout_user);
router.get('/verifycode/:id', UserController.verify_code);
router.post('/verifycode/:id', UserController.save_verify_code);
router.get('/verify-code-app', UserController.verify_code_form);
router.post('/verify-code-app', UserController.verify_code_saving);
router.post('/resend-code/', UserController.resend_code);
router.post('/resend-code-app', UserController.resend_code_app);
// router.get('/languages', UserController.languages);
router.post('/send-reset-password-email', UserController.sendUserPasswordResetEmail)
// router.post('/reset-password/:id/:token', UserController.userPasswordReset)
router.get('/reset-password', UserController.resetpassword)



// Protected routes
router.post('/changepassword', UserController.changeUserPassword);
router.get('/loggeduser', UserController.loggedUser)
router.post('/user-login-app',UserApiController.userLoginApp);
router.post('/user-register-app',UserApiController.userRegistrationApp);


export default router;