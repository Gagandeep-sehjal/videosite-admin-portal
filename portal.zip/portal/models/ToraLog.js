import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema({
  event: {
    type: String, // Description of the event (e.g., "Video Title Changed", "Video Status Updated", "Video Uploaded")
    required: true,
  },
  entity: {
    type: String, // The entity or object being acted upon (e.g., "Video", "Category")
    required: true,
  },
  entityId: {
    type: mongoose.Schema.Types.ObjectId, // The ID of the entity being acted upon
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId, // The ID of the user who performed the action
    required: true,
  },
  timestamp: {
    type: Date, // The timestamp when the event occurred
    default: Date.now,
  },
  changes: {
    type: Object, // Store details of changes (e.g., { field: "title", oldValue: "Old Title", newValue: "New Title" })
  },
});

const ToraLog = mongoose.model('tora_logs', auditLogSchema);

export default ToraLog;
