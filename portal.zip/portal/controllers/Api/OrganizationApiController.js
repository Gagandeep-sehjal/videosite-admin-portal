import TaxonomyModel from "../../models/Taxonomy.js";
import ToraFeaturesModel from "../../models/ToraFeatures.js";
import ToraLog from "../../models/ToraLog.js";
import UserModel from "../../models/User.js";
import { convertToSlug } from "../../utils/utils.js";
import ToraTermRelation2Model from "../../models/ToraTermRelation2.js";

class OrganizationApiController{
    

      static quick_edit_organization = async (req, res) =>{
        try {
          const {cat_id, name, thumbnail} = req.body;
          let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
          let user = await UserModel.findById(req.session.userId);
        let topic_old_detail = await TaxonomyModel.findById(cat_id);

        // res.send(topic_old_detail);
        // title change log
          if(topic_old_detail.title != name){
            const log_doc = new ToraLog({
                                event:"Name Changed",
                                entity:"Organization",
                                entityId: cat_id,
                                user:user._id,
                                changes:{field:"name",oldValue:topic_old_detail.title, newValue:name}
                            });
            const logsave = await log_doc.save();
          }

          const organization_doc = {
            title: name, // Update the title field
            slug: slug,  // Update the slug field
            thumbnail:thumbnail
          };

          const result = await TaxonomyModel.findByIdAndUpdate(cat_id, organization_doc);
          res.status(201).json({ status: 'success', data: result });

        } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
        }
      }

      
}

export default OrganizationApiController;