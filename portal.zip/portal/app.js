import express from 'express';
import cookieParser from 'cookie-parser';
import connectDB from './db/connectdb.js';
import web from './routes/web.js';
import {join} from 'path';
import dotenv from 'dotenv';
import cors from 'cors';
import userRoutes from './routes/userRotues.js';
import portalRoutes from './routes/portalRoutes.js';
import apiRoutes from './routes/api.js';
import session from 'express-session';
import fileUpload from 'express-fileupload';


dotenv.config();
const app = express();
const port = process.env.PORT || '3000';
const DATABASE_URI = process.env.DATABASE_URL;
const hour = 3600000; // 1 hour in milliseconds

app.use(cors());
connectDB(DATABASE_URI);

app.use(express.json());

app.use(session({
    secret: 'videosite',
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxAge: 6 * hour, // Set the session expiration time
    }
  }));
  
app.use(express.urlencoded({extended:false}));
app.use(cookieParser());
app.use(fileUpload());



// Middleware to set the global variable
app.use((req, res, next) => {
  // req.url = `/portal${req.url}`;
  // res.send(req.path);
  // Construct the current site URL
  const currentSiteUrl = `${req.protocol}://${req.get('host')}`;
  const fullUrl = `${currentSiteUrl}${req.originalUrl}`;

  // Assign it to app.locals.myGlobalVariable
  app.locals.myGlobalVariable = currentSiteUrl;
  app.locals.current_path = req.path;
  app.locals.full_url = fullUrl;
  // localStorage.setItem('current_lang', 'en');
  // app.locals.current_lang = localStorage.getItem('current_lang');

  next(); // Continue processing
});

// To use req.body 

// app.use('/api/user',express.static(join(process.cwd(),"public")));
app.use('/',express.static(join(process.cwd(),"public")));
app.use('/verifycode',express.static(join(process.cwd(),"public")));
app.use('/login',express.static(join(process.cwd(),"public")));
app.use('/portal/dashboard',express.static(join(process.cwd(),"public")));
app.use('/portal/feature',express.static(join(process.cwd(),"public")));
app.use('/portal/series',express.static(join(process.cwd(),"public")));
app.use('/portal/topic' ,express.static(join(process.cwd(),"public")));
app.use('/portal/topics' ,express.static(join(process.cwd(),"public")));
app.use('/portal/videos' ,express.static(join(process.cwd(),"public")));
app.use('/portal/organization' ,express.static(join(process.cwd(),"public")));
app.use('/portal/series/edit' ,express.static(join(process.cwd(),"public")));
app.use('/portal/topic/edit' ,express.static(join(process.cwd(),"public")));
app.use('/portal/organization/edit' ,express.static(join(process.cwd(),"public")));
app.use('/portal/videos/edit' ,express.static(join(process.cwd(),"public")));
app.use('/portal/user' ,express.static(join(process.cwd(),"public")));
app.use('/portal/users' ,express.static(join(process.cwd(),"public")));
app.use('/portal/users/edit' ,express.static(join(process.cwd(),"public")));
app.use('/portal/language' ,express.static(join(process.cwd(),"public")));
app.use('/portal/library/add' ,express.static(join(process.cwd(),"public")));
app.use('/api/users/reset-password/:id/' ,express.static(join(process.cwd(),"public")));
app.use('/portal/countries' ,express.static(join(process.cwd(),"public")));
app.use('/api/language/edit' ,express.static(join(process.cwd(),"public")));
app.use('/api/countries/edit' ,express.static(join(process.cwd(),"public")));



app.set('view engine', 'ejs');

// app.use('/api/user', userRoutes);
app.use('/', userRoutes);
app.use('/', web);
app.use('/portal', portalRoutes);
// app.use('/api/:lang', apiRoutes);
app.use('/api', apiRoutes);

app.use('/student', web);

app.get('*', function(req, res){
  res.render('error');
})

app.listen(port, ()=>{
    console.log(`Server listening at http://localhost:${port}`);
})