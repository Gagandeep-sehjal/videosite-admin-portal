import express from 'express';
const router = express.Router();
import SeriesController from '../controllers/SeriesController.js';
import TopicController from '../controllers/TopicController.js';
import setLanguage from '../middleware/set-Language.js';
import OrganizationController from '../controllers/OrganizationController.js';
import checkUserWebAuth from '../middleware/auth-web-midleware.js';
import VideosController from '../controllers/VideosController.js';
import UserController from '../controllers/userController.js';
import checkAdminWebAuth from '../middleware/auth-admin-midleware.js';
import LanguageController from '../controllers/LanguageController.js';
import librarycontroller from '../controllers/librarycontroller.js';



router.post('/language', LanguageController.save_language);
router.get('/get_s3_images', TopicController.get_s3_images);

router.post('/set_s3_image', TopicController.set_s3_image);

router.post('/delete_images', TopicController.delete_images);

router.get('/get_images', TopicController.get_images);


export default router;


