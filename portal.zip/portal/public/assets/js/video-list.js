$( document ).ready(function() {

     // code to delete videos start 
     $(document).on("click",".delete_videos",function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            var id = $(this).data("id");
            var current_ele = $(this);
            $.ajax({
              type: "POST", // Change to "POST" or "PUT" if needed
              url: `/api/videos/delete/${id}`, // Replace with your API endpoint
              success: function (response) {
                  // Handle the success response here
                console.log("Success:", response);
                if(response.status == "success"){
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                        )
                    current_ele.parent().parent().hide();
                }else{
                    console.log(response);
                    console.log("some error occure =====");
                }
              },
              error: function (error) {
                      // Handle the error response here
                console.log("Error:", error);
              },
            });
          }
        })
      });
       // code to delete videos end

      //  move to trash
    $(document).on("click",".move_trash",function(e) {
        e.preventDefault();
        var id = $(this).data("id");
        console.log("id value",id);
        $.ajax({
          type: "POST", // Change to "POST" or "PUT" if needed
          url: `/api/videos/change_status/${id}`, // Replace with your API endpoint
          success: function (response) {
              // Handle the success response here
            console.log("Success:", response);
            location.reload();
          },
          error: function (error) {
                  // Handle the error response here
            console.log("Error:", error);
          },
        });
    });

    $(document).on("click",".restore_vid",function(e) {
        e.preventDefault();
        var id = $(this).data("id");
        console.log("id value",id);
        $.ajax({
          type: "POST", // Change to "POST" or "PUT" if needed
          url: `/api/videos/restore_vid/${id}`, // Replace with your API endpoint
          success: function (response) {
              // Handle the success response here
            console.log("Success:", response);
            location.reload();
          },
          error: function (error) {
                  // Handle the error response here
            console.log("Error:", error);
          },
        });
    });

    // starting to get videos
    // get_videos(1);
    allvideos();

    //top tab api code 
    function allvideos(){
        localStorage.removeItem('current_status');
        localStorage.removeItem('current_author');
        localStorage.removeItem('current_category');
        localStorage.removeItem('current_search');
        $(".video_card").removeClass("video_card_color");
        $("#all_videos").addClass("video_card_color");
        $("#videos_body").html("");
        get_videos(1);
    }

    $("#all_videos").click(function(){
      allvideos();
    });
  

    $("#publish_videos").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "publish");
    })

    $("#pending_videos").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "draft");
    })

    $("#short_clip").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "short_clip");
    })

    $("#audio").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "audio");
    })

    $("#large_videos").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "large_videos");
    })

    $("#trash_videos").click(function(){
      $(".video_card").removeClass("video_card_color");
      $(this).addClass("video_card_color");
      $("#videos_body").html("");
      get_videos(1, "trash");
    })
    // top tab api code end 
    
    // onclick categories list start 
    $(document).on("click",".auth_data",function(e) {
      var auth_id = $(this).data("id");
      $("#videos_body").html("");
      get_videos(1, "","",auth_id);
    })

    $(document).on("click",".cat_data",function(e) {
      var cat_id = $(this).data("id");
      $("#videos_body").html("");
      get_videos(1, "","","",cat_id);
    })
    // onclick categories list start 

    // all categories dropdown 
    $(document).on("change",".all_categories",function(e) {
      var cat_id = $(this).val();
      console.log("categories id value ====");
      console.log(cat_id);
      $("#videos_body").html("");
      get_videos(1, "","","",cat_id);
    })

    // item per page dropdown
    $("#page_size").change(function(){
      let page_size = $(this).val();
      get_videos(1, "","","","",page_size);
    })

    // functionality for searchbox
    $("#search_video").on('input', function () {
        var inputValue = $(this).val();
        console.log(inputValue);
        if(inputValue == ""){
          localStorage.removeItem('current_search');
        }
        get_videos(1,"",inputValue);
        console.log("this is iput value =====");
    });

   

   
    // code for author search select code end  

    // bulk checkbox code 
    // Event handler for the master checkbox
    $('#masterCheckbox').on('click', function() {
        // Get the state of the master checkbox
        const isChecked = $(this).prop('checked');

        // Set the state of all other checkboxes
        $('.rowCheckbox').prop('checked', isChecked);

        // Trigger the change event for the individual checkboxes
        $('.rowCheckbox').trigger('change');
    });

    // checkbox select code 
    let checkedCheckboxes = []; 
    $(document).on("change", ".form-check-input", function(e) {
      var checkedCount = $('.rowCheckbox:checked').length;
      if(checkedCount==0){
        $('#itemcount').hide();
      }else{
        $('#itemcount').show();
        $('#counter').text(checkedCount);
      }
     
        const rowCheckbox = $(this);
        const id = rowCheckbox.data('id');
        const name = rowCheckbox.data('name');

        console.log("outside");
        console.log(checkedCheckboxes);
        if ($(this).prop('checked')) {
        console.log("inside");
        console.log(checkedCheckboxes);
        
        // checkedCheckboxes.push(dataId);
        checkedCheckboxes.push({ id, name });
        } else {
        checkedCheckboxes = checkedCheckboxes.filter(row => row.id !== id);
        }
    });

    // bulk edit drop down code start 
      // Handle bulk edit button click
  $('#bulk-edit-button').click(function () {
    if (checkedCheckboxes.length === 0) {
      alert('Please select at least one row to bulk edit.');
      return;
    }
    console.log(checkedCheckboxes);
    console.log("checking check box");
    var selectedOption = $('#selected_item').val();

    if(selectedOption == "edit"){
    let popupContent = "";
    // let fieldCount = 0;
    for (const row of checkedCheckboxes) {
        popupContent += '<div class="form-group mb-2">';
        popupContent += '<div class="input-group">';
          popupContent += '<div class="input-group-append">';
        popupContent += '<button class="btn btn-danger remove-field" type="button" data-id="' + row.id + '">X</button>';
        popupContent += '</div>';
        popupContent += '<input type="text" class="form-control" id="name' + row.id + '" name="name' + row.id + '" value="' + row.name + '">';
       
        popupContent += '</div>';
        popupContent += '</div>';
        // fieldCount++;
      }
      $("#edit_type").val("Bulk");
      console.log("you click bulk brother");
      $("#form-title").html("Bulk Edit");
      $('#bulk-modal-title').html(popupContent);
      $("#open-bulk-popup").click();

      $(document).on("click",'.remove-field', function () {
        const idToRemove = $(this).data('id');
        $(`#name${idToRemove}`).closest('.form-group').remove();

        console.log($('.remove-field').length);
        console.log("== length is ===");
        // Disable the submit button if there's only one field left
        if ($('.remove-field').length <= 1) {
          $('.remove-field').prop('disabled', true);
        }
      });

    }

    else if(selectedOption == "restore"){
      $.ajax({
                type: "POST", // Change to "POST" or "PUT" if needed
                url: `/api/videos/bulk_restore`, // Replace with your API endpoint
                data: JSON.stringify(checkedCheckboxes),
                contentType: 'application/json', // Set content type to JSON
                dataType: 'json', // Expect JSON in response
                xhr: function () {
                var xhr = new XMLHttpRequest();
                xhr.upload.onprogress = function (e) {
                        if (e.lengthComputable) {
                            var percentComplete = (e.loaded / e.total) * 100;
                            // Update your progress bar or do something with the progress information here
                            console.log('Upload progress: ' + percentComplete + '%');
                            $("#spiner_loading").html(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading....`);
                        }
                    };
                    return xhr;
                },
                success: function (response) {
                    // Handle the success response here
                  console.log("Success:", response);
                  $("#spiner_loading").html(`<div class="text-success">All the selected videos are restored </div>`);
                  location.reload();
                },
                error: function (error) {
                        // Handle the error response here
                  console.log("Error:", error);
                  $("#spiner_loading").html(`<div class="text-danger">Something went wrong please try againg later.</div>`);
                },
            });
    }
  else{

    $.ajax({
      type: "POST", // Change to "POST" or "PUT" if needed
      url: `/api/videos/bulk_trash`, // Replace with your API endpoint
      data: JSON.stringify(checkedCheckboxes),
      contentType: 'application/json', // Set content type to JSON
      dataType: 'json', // Expect JSON in response
      xhr: function () {
      var xhr = new XMLHttpRequest();
      xhr.upload.onprogress = function (e) {
              if (e.lengthComputable) {
                  var percentComplete = (e.loaded / e.total) * 100;
                  // Update your progress bar or do something with the progress information here
                  console.log('Upload progress: ' + percentComplete + '%');
                  $("#spiner_loading").html(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading....`);
              }
          };
          return xhr;
      },
      success: function (response) {
          // Handle the success response here
        console.log("Success:", response);
        $("#spiner_loading").html(`<div class="text-success">All the selected videos moved to trash</div>`);
        location.reload();
      },
      error: function (error) {
              // Handle the error response here
        console.log("Error:", error);
        $("#spiner_loading").html(`<div class="text-danger">Something went wrong please try againg later.</div>`);
      },
  });
  }
     
  
          });
          
        
        });
  
    

    // quick edit code start 
    $(document).on("click",".quick_edit",function(e) {
        e.preventDefault();
        $("#title_field").show();
        var vid_id = $(this).data("id");
        $("#vid_id").val(vid_id);
        $("#modal-title").html("");
        $("#edit_type").val("");
        $("#form-title").html("Quick Edit");
        console.log("vid id");
        console.log(vid_id); 
        $.get(`/api/single-video/${vid_id}`, function(response, status){
              console.log(response);
              const single_vid = response.data;
              $("#hide_home_page").val(single_vid.video_info.hide_home_page);
              $("#title").val(single_vid.video_info.title);
              $("#description").val(single_vid.video_info.description);
              $("#status").val(single_vid.video_info.status);
              $("#status").val(single_vid.video_info.status);
              $('input:radio[name="visible"]').filter(`[value="${single_vid.video_info.visible}"]`).attr('checked', true);
              $("#topics").val(single_vid.topic_id);
              $("#series").val(single_vid.series_id);
              $("#organization").val(single_vid.organization_id);
              $("#author").val(single_vid.video_info.userId);
              const formatpublishDate = new Date(single_vid.video_info.publishedAt).toISOString().slice(0, 16);
              $("#publish_datetime").val(formatpublishDate);
              $('#author').trigger('change');
              console.log("user id val");
              console.log(single_vid.video_info.userId);
              single_vid.video_info.lang.forEach(function(langCode) {
                $('#chk_' + langCode).prop('checked', true);
              });
              console.log("our response ====");
              $("#openCustomModalButton").click();
        });
  });
    // quick edit code start 



      
  




    
  

    

  


    $("form").submit(function (e) {
      e.preventDefault(); 
      console.log("submitting form ====");
      var formData = new FormData(this);
      var id = $("#vid_id").val();
    //   var isValid = validateForm();
      var isValid = true;

      console.log("checking edit typ");
      console.log($("#edit_type").val());
    //   return false;

      if (isValid) {
        var url = `/api/quick_video_submit/${id}`;
        if($("#edit_type").val() == "Bulk"){
          console.log("this is bulk edit");
          url = `/api/bulk_video_submit`;
        }

        $.ajax({
            type: "POST", // Change to "POST" or "PUT" if needed
            url: url, // Replace with your API endpoint
            data: formData,
            processData: false, // Prevent jQuery from p  rocessing the data
            contentType: false, 
            xhr: function () {
                var xhr = new XMLHttpRequest();
                xhr.upload.onprogress = function (e) {
                    if (e.lengthComputable) {
                        var percentComplete = (e.loaded / e.total) * 100;
                        // Update your progress bar or do something with the progress information here
                        console.log('Upload progress: ' + percentComplete + '%');
                        $(".spiner_loading").html(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading....`);
                    }
                };
                return xhr;
            },
            success: function (response) {
                // Handle the success response here
              console.log("Success:", response);
              $(".spiner_loading").html(`<div class="text-success">Video Information updated</div>`);
              location.reload();
            },
            error: function (error) {
                    // Handle the error response here
              console.log("Error:", error);
              let err = error.responseJSON;
              $(".spiner_loading").after(`<div class="text-danger">${error}</div>`);
            },
        });
      }
      
    });

    function validateForm() {
        var isValid = true;

        console.log("=== in validation ====");
        // Clear previous validation messages
        $(".error-message").remove();

        // Validate Name field (required)
        var author = $("#author").val();

        console.log(author);
        console.log("author value ===");
        if (author == "") {
            $("#author").after('<span class="error-message text-danger">Author is required</span>');
            isValid = false;
        }

        // Validate Slug field (required)
        var status = $("#status").val();
        if (status === "") {
            $("#status").after('<span class="error-message text-danger">Status is required</span>');
            isValid = false;
        }

        // Add more validation for other fields here...

        return isValid;
    }

// Event handler for individual checkboxes

    $(document).on("click", ".page-link", function(e) {
        e.preventDefault();
        var current_page = $(this).data("page"); 
        var status = $(this).data("status"); 
        var search = $(this).data("search"); 
        var cat_id = $(this).data("cat_id"); 
        var auth_id = $(this).data("auth_id"); 
        var page_size= $(this).data("page_size"); 
        get_videos(current_page, status, search, auth_id, cat_id, page_size);
    });

    window.onbeforeunload = function() {
      localStorage.removeItem('current_status');
      localStorage.removeItem('current_author');
      localStorage.removeItem('current_category');
      localStorage.removeItem('current_search');
  };
  

      function get_videos(page_no, status="",search="",auth_id="",cat_id="",page_size=10){
            var storedValue = localStorage.getItem('current_lang');
            // Get the current URL
            var currentUrl = window.location.href;
            // Parse the URL using the jQuery URL Parser
            var urlObject = $.url(currentUrl);
            // Get the value of the 'topic_id' parameter
            var catId = urlObject.param('cat_id');
            if(catId){
                cat_id = catId;
            }

            if (status) {
              localStorage.setItem('current_status', status);
          } else {
             
              status = localStorage.getItem('current_status') || "";
          }

          if (cat_id) {
            localStorage.setItem('current_category', cat_id);
        } else {
           
            cat_id = localStorage.getItem('current_category') || "";
        }


          if (auth_id) {
            localStorage.setItem('current_author', auth_id);
        } else {
           
            auth_id = localStorage.getItem('current_author') || "";
        }

        if (search) {
          localStorage.setItem('current_search', search);
      } else {
         
          search = localStorage.getItem('current_search') || "";
      }
          
                
  $.get(`/api/videos?page=${page_no}&status=${status}&search=${search}&auth_id=${auth_id}&cat_id=${cat_id}&current_lang=${storedValue}&page_size=${page_size}`, 
    function(response, statusdata){
      if(response.status == "success"){
        let videos = response.data;
        // $('#counteritem').text(videos.length);
        $('#counteritem').text(response.totalvideos);
          if(videos.length == 0){
            console.log("no video aviablable");
            $(".warning").html("");
            $(".warning").html("<h2>No video available.</h2>");
            $('#pagination').empty();
          }else{
            $(".warning").html("");
            let totalPages = response.totalPages;
            let full_url = '<%= full_url %>';
            let num = 0;
            let videos_rows = videos.map((item, index)=>{
            var order = '';
            if(item.order != null){
              order = item.order;
            }
            const categoryTitles = item.termRelations2.filter(terms => terms.type === "topic").map(terms => `<span class="cat_data cursor_pointer site-blue-color" data-id="${terms.term_id}">${terms.title}</span>`); 
            // Map to titles
            let joinedcategories = categoryTitles.join('<br/>');
            const organization = item.termRelations2.filter(terms => terms.type === "organization").map(terms => `<span class="cat_data cursor_pointer site-blue-color" data-id="${terms.term_id}">${terms.title}</span>`); 
            const country = item.countries.map(country => `<span class="cat_data cursor_pointer site-blue-color" data-id="${country.term_id}">${country.country}</span>`); 
            // Map to titles
            let joinedorganization = (organization) ? organization.join('<br>') : '';
            if(item.taxoinfo.length === 0){
              joinedcategories = '';
              joinedorganization = '';
            }

            var formatdate = item.publishedAt ? formatDate(item.publishedAt) : '';
            var user_first_name = (item?.user && item.user[0]?.firstName) ? item.user[0].firstName : '';
            var user_id = (item?.user && item.user[0]?.user_id) ? item.user[0].user_id : '';
            var lang_data = (item.language.length > 0) ? item.language[0].language : '';
            var short_vid = (item.shortVideo && item.shortVideo == 1) ? 'Yes' : '';

            var lang_ele = "";
            var flag = "";
            for (let langd of item.language) {
            
                lang_ele += `<div class="d-flex align-items-center gap-1 my-1">
                            <img src="${flag}">
                            ${langd.language}
                          </div>`;
            }

            var user_last_name = (item?.user?.[0]?.lastName) ?? '';
            var sta_class = "";
            if(item.status == "draft"){
              sta_class = "danger";
              item.status = "Pending";
            }else if(item.status == "publish"){
              sta_class = "success";
            }else if(item.status == "trash"){
              sta_class = "secondary";
            }

            console.log(status);
            console.log("this staus value ")
            if(status == "trash"){
              console.log("in trash");
              var d_delete = "";
              var d_trash = "d-none";
              $("#trash_option").hide();
              $("#restore_option").show();
            }else{
              console.log("out trash");
              var d_trash = ""
              var d_delete = "d-none";
              $("#trash_option").show();
              $("#restore_option").hide();
            }
            if (item.recordLocation === "Select location") {
              item.recordLocation = '';
            }
            let recordLocation = '';
            if(item.recordLocation){
              recordLocation = item.recordLocation
            }
            num = num+1;
                
                  // Join the array of term titles using a comma
            return `<tr>
                        <td>
                          <input class="form-check-input border-gray-color rowCheckbox" type="checkbox" data-id="${item._id}" data-name="${item.title}" >
                        </td>
                        <td class="hidedata video_image">
                          <img src="${item.thumbnail}" class="video_thumb" />
                        </td>
                        <td  class="hidedata video_image video_title" >
                            <div class="title">${item.title}</div>                                       
                          
                            <div class="filter">
                              <div class="d-flex gap-2 mt-2">
                                <a class="icon" href="/portal/videos/edit/${item._id}"><i class="ri-edit-2-line"></i></a>
                                <a class="icon" href="#"><i class="bi bi-play-btn"></i></a>
                                <div class="position-relative">
                                <a class="icon pe-3 pb-3" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical"></i></a>                                                  
                              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow p-2">
                              <li class="p-1">
                                  <a href="/portal/videos/edit/${item._id}" class="quick_edit" data-id="${item._id}">
                                    <i class="ri-edit-2-line"></i> Quick Edit Video
                                  </a> 
                                </li>
                                <li class="p-1">
                              
                                  <a href="/portal/videos/edit/${item._id}">
                                    <i class="ri-edit-2-line"></i> Edit Video details
                                  </a> 
                                </li>
                                <li class="p-1 ${d_delete}">
                                  <a href="/videos/delete/${item._id}" class="restore_vid" data-status="publish" data-id="${item._id}">
                                    <i class="ri-delete-bin-5-line"></i> Restore
                                  </a>
                                </li>
                                <li class="p-1 ${d_trash}">
                                  <a href="/videos/delete/${item._id}" class="move_trash" data-status="trash" data-id="${item._id}">
                                    <i class="ri-delete-bin-5-line"></i> Move to Trash
                                  </a>
                                </li>
                                <li class="p-1 d_value ${d_delete}">
                                  <a href="/videos/delete/${item._id}" class="delete_videos" data-id="${item._id}">
                                    <i class="ri-delete-bin-5-line"></i> Delete Forever 
                                  </a>
                                </li>
                              </ul>
                              </div>
                            </div>
                            </div>
                          
                        </td>
                        <td class="hidedata author">
                          <span class="auth_data cursor_pointer site-blue-color" data-id="${user_id}">${user_first_name} ${user_last_name}</span></td>
                        <td class="hidedata category">${joinedcategories}</td>
                        <td class="hidedata status"><div class="badge bg-${sta_class}">${item.status}</div></td>
                        <td class="hidedata organization">${joinedorganization}</td>
                        <td class="hidedata language">${lang_ele}</td>
                        <td class="hidedata countries">${country ? country: ''}</td>
                        <td class="hidedata AverageviewTime"></td>
                        <td class="hidedata short">${short_vid}</td>
                        <td class="hidedata publishedDate">${formatdate}</td>
                        <td class="hidedata vimeo_id">${item.vimeoId}</td>
                        <td class="hidedata Size">${item.size ? item.size : " "}</td>
                        <td class="hidedata Views">${item.views ? item.views : " "}</td>
                        <td class="hidedata Comments"></td>
                        <td class="hidedata Likes">${item.likes ? item.likes : " "}</td>
                    <tr>`;
          });


          $("#videos_body").html(videos_rows);
          const pagination = $('#pagination');
          pagination.empty();

          // Add "Previous" link
          if(page_no != 1){
              pagination.append(`<li class="page-item"><a class="page-link" href="#" data-page="${page_no-1}" data-auth_id="${auth_id}"  data-status="${status}" data-search="${search}" data-cat_id="${cat_id}" data-page_size="${page_size}"><</i></a></li>`);
          }

          // Calculate the start and end page numbers
          let startPage = Math.max(1, page_no - 2); // Start with the current page minus 1
          let endPage = Math.min(totalPages, startPage + 5); // Display 3 pages or less

            // Generate page links
          if(totalPages > 1){  
              for (let i = startPage; i <= endPage; i++) {
                  let page_class = '';
                  console.log("page_no", page_no);
                  console.log("page i", i);
                  if(page_no === i){
                      console.log("you are class");
                      page_class = 'page-class';
                  }
                  const listItem = $(`<li class="page-item" ></li>`);
                  const link = $(`<a class="page-link ${page_class}  ${i === page_no ? 'active' : ''}" href="?page=${i}" data-page="${i}"  data-status="${status}" data-auth_id="${auth_id}" data-search="${search}" data-cat_id="${cat_id}" data-page_size="${page_size}">${i}</a>`);

                  listItem.append(link);
                  pagination.append(listItem);
              }
          }

          // Add "Next" link
          if(totalPages != page_no){
              pagination.append(`<li class="page-item"><a class="page-link" href="${page_no+1}" data-page="${page_no+1}" data-status="${status}" data-auth_id="${auth_id}" data-search="${search}" data-cat_id="${cat_id}" data-page_size="${page_size}">></a></li>`);
          }
        }

      }   
  });
}


        // code for select start
      // Open the custom modal when the button is clicked
      $(document).ready(function() {
         // code for select start
        

        // Open the custom modal when the button is clicked
        $("#openCustomModalButton").click(function() {
            $("#customModal").show();
            // Initialize Select2 within the custom modal
            // $("#customSelectDropdown").select2();
            $(".prompt_topic").select2({
                data:content2,
                width: '100%',
                multiple:true,
                placeholder:"Enter Feature Topic",
                matcher: matchCustom
            });

            $(".prompt").select2({
              data:content,
              width: '100%',
              multiple:true,
              placeholder:"Enter Feature Series",
              matcher: matchCustom
            });

            $(".prompt_organization").select2({
              data:content3,
              width: '100%',
              multiple:true,
              placeholder:"Enter Category Name",
              matcher: matchCustom
            });
        });

        // Close the custom modal when the close button is clicked
        $("#closeCustomModalButton").click(function() {
           
            $("#customModal").hide();
        });

           // code for bulk edit start
        $("#closeBulkModalButton").click(function() {
          
            $("#bulkModal").hide();
        });

        $("#author").select2({
            matcher: matchCustom
          });
     
        // Open the custom modal when the button is clicked
        $("#open-bulk-popup").click(function() {
            $("#bulkModal").show();
            // Initialize Select2 within the custom modal
            // $("#customSelectDropdown").select2();
            $(".prompt_topic").select2({
                data:content2,
                width: '100%',
                multiple:true,
                placeholder:"Enter Feature Topic",
                matcher: matchCustom
            });

            $(".prompt").select2({
              data:content,
              width: '100%',
              multiple:true,
              placeholder:"Enter Feature Series",
              matcher: matchCustom
            
            });

            $(".prompt_organization").select2({
              data:content3,
              width: '100%',
              multiple:true,
              placeholder:"Enter Category Name",
              matcher: matchCustom
            });
        });

         // code for author search select code start  
    function matchCustom(params, data) {
        // If there are no search terms, return all of the data
        if ($.trim(params.term) === '') {
          return data;
        }
  
        // Do not display the item if there is no 'text' property
        if (typeof data.text === 'undefined') {
          return null;
        }
  
        // `params.term` should be the term that is used for searching
        // `data.text` is the text that is displayed for the data object
        if (data.text.indexOf(params.term) > -1) {
            var modifiedData = $.extend({}, data, true);
            // modifiedData.text += ' (matched)';
  
          // You can return modified objects from here
          // This includes matching the `children` how you want in nested data sets
          return modifiedData;
        }
  
          // Return `null` if the term should not be displayed
        return null;
      }
    });