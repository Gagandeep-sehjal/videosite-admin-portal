import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
dotenv.config();

// Define a middleware function for JWT authentication
const authenticateToken = async (req, res, next) =>{
  const token_val = req.header('Authorization');

    if(!token_val){
        return res.status(401).json({ message: 'Access denied. No token provided.' });
    }
    // res.send("no data");
    var token = token_val.split(' ')[1];
    // res.send(token_val);

    if (!token) {
        return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECERT_KEY);
        if(decoded.username && decoded.username == ""){
            next();
        }else{
            return res.status(400).json({ message: 'Invalid token.' });
        }
    } catch (ex) {
        return res.status(400).json({ message: 'Invalid token.' });
    }
}

export default authenticateToken;
