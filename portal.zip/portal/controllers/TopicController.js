import mongoose from 'mongoose';
import LanguageModel from "../models/Language.js";
import TaxonomyModel from "../models/Taxonomy.js";
import ToraLog from "../models/ToraLog.js";
import UserModel from "../models/User.js";
import { deleteImageFromURL,getImageDetailsFromURL,getAllFilesFromS3, getTranslation, uploadFileToS3 } from "../utils/utils.js";
import {  formatDatetime } from "../utils/utils.js";
import { ObjectId } from 'mongodb';
import LanguageController from './LanguageController.js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


class TopicController{
    static get_home_topics = async (req, res) =>{
        try {
          
            const all_cookies = req.cookies; 
            const { status } = req.query;
            var current_lang = 'en';
            if(all_cookies.current_lang){
              var current_lang = all_cookies.current_lang;
            }

            let user = await UserModel.findById(req.session.userId);

            const baseMatch = {
              $and: [
                { type: 'topic' },
                { lang: 'en' },
              ]
            };

            if (status === 'trash') {
              baseMatch.$and.push({ status: 'trash' });
            }
            else if(status === 'parent'){
              // baseMatch.$and.push({ parentId: { $eq: null } });
              baseMatch.$and.push({ parent_id: { $eq: 0 } });
            }
            // else if(status == "child" || status == "grand_child"){
            //   baseMatch.$and.push({ parentId: { $ne: null } });
            // }
            else{
              baseMatch.$and.push({ status: { $ne: 'trash' } });
            }

              const topicsonly = await TaxonomyModel.aggregate([
                {
                    $match: baseMatch
                },
                {
                    $lookup: {
                        from: 'tora_term_relations',
                        localField: '_id',
                        foreignField: 'termId',
                        as: 'videos'
                    }
                },
                {
                    $addFields: {
                        videoCount: { $size: '$videos' } // Add a new field for video count
                    }
                },
                {
                    $project: {
                        videos: 0 // Exclude the videos array from the final result if not needed
                    }
                },
                {
                  $sort: {
                    title: 1 // 1 for ascending order, -1 for descending order
                  }
                }
            ]);


            // console.log("topic only ====");
            // console.log(topicsonly);

            const childMatch = {
              $and: [
                { type: 'topic' },
                { lang: 'en' },
              ]
            };
            // childMatch.$and.push({ parentId: { $ne: null } });
            childMatch.$and.push({ parent_id: { $nin: [null, 0] } });

            const topicchildcount = await TaxonomyModel.aggregate([
              {
                  $match: childMatch
              },
              {
                  $lookup: {
                      from: 'tora_term_relations',
                      localField: '_id',
                      foreignField: 'termId',
                      as: 'videos'
                  }
              },
              {
                  $addFields: {
                      videoCount: { $size: '$videos' } // Add a new field for video count
                  }
              },
              {
                  $project: {
                      videos: 0 // Exclude the videos array from the final result if not needed
                  }
              }
          ]);
          

            // Get all topics with only the _id and name fields
            const baseQuery = {
              type: 'topic',
              lang: 'en',
            };
            if (status === 'trash') {
              baseQuery.status = 'trash';
            }

            const allTopics = await TaxonomyModel.find(baseQuery, { _id: 1, term_id:1, title: 1, parent_id: 1 });
            console.log("all topics data ====");
            // console.log(allTopics);

          

            // Create a map for efficient lookup
            // const topicMap = new Map(allTopics.map(topic => [topic._id.toString(), topic.title]));
            const topicMap = new Map(allTopics.map(topic => [topic.term_id, topic.title]));

            // Loop through the topics and add a new field for parent name
            let topics = topicsonly.map(topic => ({
              ...topic, // No need for toObject here
              // parentName: topic.parentId ? topicMap.get(topic.parentId.toString()) : null,
              parentName: topic.parent_id ? topicMap.get(topic.parent_id) : null,
            }));
            let topicschild = topicchildcount.map(topic => ({
              ...topic, // No need for toObject here
              // parentName: topic.parentId ? topicMap.get(topic.parentId.toString()) : null,
              parentName: ((topic.parent_id && topic.parent_id != 0) ? topicMap.get(topic.parent_id) : null),
            }));

            const langauges = await LanguageModel.find();
            let trashcount = await TaxonomyModel.countDocuments({status:"trash",type:"topic"});
            const topicCount = await TaxonomyModel.countDocuments({ status: { $ne: "trash" }, type: "topic", lang: 'en' });

            // const topicparent = await TaxonomyModel.countDocuments({ status: { $ne: "trash" }, type: "topic", lang: 'en', parentId: { $eq: null } });
            const topicparent = await TaxonomyModel.countDocuments({ status: { $ne: "trash" }, type: "topic", lang: 'en',  parent_id: { $in: [null, 0] }  });

            let topicdata = topicschild;

            // let topicchilddata = topicschild.filter(child => {
            //   // Check if the parentId of the child exists in the _id values of topicdata
            //   return !topicdata.some(parent => parent._id.equals(child.parentId));
            // });
            // console.log("topic child first =====");
            // console.log(topicschild)
            // console.log("topic data ====")
            // console.log(topicdata)

            let topicchilddata = topicschild.filter(child => {
              // Check if the parentId of the child exists in the _id values of topicdata
              // return !topicdata.some(parent => parent._id.equals(child.parentId));
              return !topicdata.some(parent => parent.term_id == child.parent_id);
              // return !topicdata.some((parent)=> {
              //   if(parent.term_id)
              //     return parent.term_id.equals(child.parent_id)
              //   }
              // );
            });

            let topicgrandchild = topicschild.filter(child => {
              // Check if the parentId of the child exists in the _id values of topicdata
              // return topicdata.some(parent => parent._id.equals(child.parentId));
              // return topicdata.some((parent)=> {
              //   if(parent.term_id)
              //     return parent.term_id.equals(child.parent_id)
              //   }
              // );
              return topicdata.some(parent => parent.term_id == child.parent_id);

            });

            
            // console.log("topic child ");
            // console.log(topicchilddata);
            

            let topicChild = topicchilddata.length;
            let topicGrand = topicgrandchild.length;

           

            if(status == "child"){
              topics = topicchilddata;
            }else if(status == "grand_child"){
              topics = topicgrandchild;
            }


            // res.send(topics);
            res.render('topics',{user, topics, langauges, current_lang,status,trashcount,topicCount, topicparent,topicChild,topicGrand,  getTranslation });
          } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
          }
    }

    static edit_topic = async (req, res) =>{
        try{
          let user = await UserModel.findById(req.session.userId);
          const all_cookies = req.cookies;
          const current_lang = all_cookies.current_lang || 'en';
          // const result = await TaxonomyModel.findById(req.params.id);
          const result = await TaxonomyModel.findOne({ $and: [
            {_id: req.params.id},
            {lang: current_lang}
          ] });
          // console.log("topic value ====");
          const topics = await TaxonomyModel.find({ _id: { $ne: req.params.id }, type: 'topic',lang: 'en' });
          const languages = await LanguageModel.find();
        


          // console.log('all result are ====');
          // console.log(result);
          // console.log(topics);
          // console.log("topic dddd ===="); 
          const topic_log = await ToraLog.aggregate([
            {
              $match: {
                $and: [
                  { entity: 'Topic' },
                 { entityId: new mongoose.Types.ObjectId(req.params.id) }, // Assuming req.params.id is the ObjectId
                ],
              },
            },
            {
              $lookup: {
                from: 'tora_users', // Name of the tora_user collection
                localField: 'user', // Field in ToraLog collection to match
                foreignField: '_id', // Field in tora_user collection to match
                as: 'userData', // Name for the merged user data field
              },
            },
          ]);

          const cat_parent = await LanguageController.topic_parent_test(req, res);
          console.log("yo")
          console.log(cat_parent)

          res.render('topic-edit',{topics, languages, result, current_lang, user, topic_log, formatDatetime, cat_parent });
        }  catch (error) {
          console.error('Error fetching series data:', error);
        }
    }

    static add_new_topic = async (req, res) =>{
      try {
        let user = await UserModel.findById(req.session.userId);
        const all_cookies = req.cookies;
        const current_lang = all_cookies.current_lang || 'en';

        const topics = await TaxonomyModel.find({ type: 'topic', lang: 'en' });
        const languages = await LanguageModel.find();
        // const cat_parent = await LanguageController.topic_parent_test(req, res);
        const cat_parent = await TaxonomyModel.find({ type: 'topic', lang: 'en' })
        res.render('add-topic',{ topics, languages, current_lang, user, cat_parent });
      } catch (error) {
        console.log(error);
        res.send(error);
      } 
    }

    static topic_translation = async (req, res) =>{
    /*  const pipeline = [
        {
          $match: {
            type: 'topic',
          },
        },
        {
          $group: {
            _id: {
              relationlId: '$relationlId',
              lang: '$lang',
            },
            titles: {
              $push: '$title',
            },
          },
        },
        {
          $group: {
            _id: '$_id.relationlId',
            translations: {
              $push: {
                lang: '$_id.lang',
                titles: '$titles',
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            relationlId: {
              $toString: '$_id',
            },
            translations: 1,
          },
        },
        {
          $sort: {
            relationlId: 1, // Sort in ascending order by relationlId
          },
        },
      ]; 
      const groupedData = await TaxonomyModel.aggregate(pipeline); */
      const all_cookies = req.cookies;
      const current_lang = all_cookies.current_lang || 'en';
      let user = await UserModel.findById(req.session.userId);


      var groupedData = await TaxonomyModel.find({$and:[
        {type:'topic'},
        {lang:'en'}
      ]});
      

      res.render('topic-translation', { groupedData, user, current_lang });
    }


    static get_s3_images = async (req, res) =>{
      // res.send("these are our iamges ======");
      const targetMonth =  parseInt(req.query.month);
      const targetYear =  parseInt(req.query.year);
      const contenttype= req.query.type;
      const search= req.query.search;
      console.log("ya");
        console.log(search)
      const allfiles = await getAllFilesFromS3(targetMonth,targetYear,contenttype,search);
      console.log(allfiles);
      console.log('images here');
      res.send(allfiles);
    }

    static get_images = async (req, res) =>{
      // res.send("these are our iamges ======");
      const imageUrl = req.query.imageUrl;
      const allfile = await getImageDetailsFromURL(imageUrl);
      console.log(allfile);
      res.send(allfile);
    }

    static delete_images = async (req, res) =>{
      const imageUrl = req.body.filePath;
      const allfile = await deleteImageFromURL(imageUrl);
      
      res.send(allfile);
    }

    static set_s3_image = async (req, res) =>{
      try {
        const file = req.files.file;
        console.log(file);
        const datafile = await uploadFileToS3(file);
        // res.send(datafile);
        res.status(201).json({ status: 'success', data: datafile });
      } catch (error) {
        return res.status(500).json({ error: error });
      }
    
    }

  
   
}

export default TopicController;
