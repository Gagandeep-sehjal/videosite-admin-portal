$(document).ready(function () {
    // Array to store selected images
    var selectedImages = [];

    // Load images on modal open
    // $('#imageModal').on('show.bs.modal', function (e) {
    $('#media-tab').on('click', function (e) {
        $('.modal-body').html("");
        console.log("media tab is click ===");
        $.ajax({
            url: '/get_s3_images',
            type: 'GET',
            beforeSend: function() {
                // setting a timeout
                console.log("modal is loading ====");
                $('.modal-body').html(` <div class="loader-container text-center" id="loader-container">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading....
              </div>`);
            },
            success: function (data) {
                console.log(data);
                // let  images = JSON.parse(data);
                let  images = data;
                console.log(images);
                let image_rows = images.map((item, index)=>{
                    console.log(item);
                    console.log("image rows");
                    return `<img src="https://cdn.com/${item}" class="img-thumbnail" style="width: 120px; height: 120px; margin: 5px;">`;
                });
                console.log("all images")
                $('.modal-body').html("");
                $('.modal-body').html(`<div class="row">
                                            <div class="col-sm-9" id="image_area"></div>
                                            <div class="col-sm-3" id="select_image"></div>
                                    </div>        
                                    `);
                $('#image_area').html(image_rows);
                $("#image_submit_div").html(`<button id="save_img_btn" class="btn btn-primary">Save Image</button>`);

                // Update the part where you append images to the modal body


                var selectedImage = null;
                // Add click event to each image
                $('.modal-body img').click(function () {
                    console.log("clicking the images");
                    var imageUrl = $(this).attr('src');
                    var current_img = $(this);
                    $.ajax({
                        url: '/get_images',
                        type: 'GET',
                        data: { imageUrl: imageUrl },
                        beforeSend: function() {
                          $('#select_image').html(` <div class="loader-container text-center" id="loader-container">
                          <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading....
                          </div>`);
                      },
                        success: function (data) {
                            console.log(data);
                            console.log(imageUrl);
                    console.log("=== image url ====");

                    if (selectedImage !== null) {
                        selectedImage.removeClass('selected');
                    }

                    // Set the currently selected image
                    selectedImage = $(this);

                    // Add the 'selected' class to the clicked image
                    selectedImage.addClass('selected');
                     
                    $("#select_image").html(`<img`);

                    $(".img-thumbnail").removeClass("selected");
                    current_img.addClass("selected");

                    // Add the clicked image to the array of selected images
                    var selectedImages = [imageUrl];

                    // Toggle selection status
                    // if ($(this).hasClass('selected')) {
                    //     // Remove from selected images
                    //     selectedImages = selectedImages.filter(function (image) {
                    //         return image !== imageUrl;
                    //     });
                    //     $(this).removeClass('selected');
                    // } else {
                    //     // Add to selected images
                    //     selectedImages.push(imageUrl);
                    //     $(this).addClass('selected');
                    // }

                   const img = new Image();
                    img.src = imageUrl;
                   const width = img.width;
                   const height = img.height;
                   
             
               
      
                    console.log('total images');
                    console.log(selectedImages);
                    console.log(selectedImages[0]);
                    $("#select_image").html(`<img id="select_image" src="${selectedImages[0]}" style="height:250px;width:250px;display: inline-block;">`);
                    $("#select_image").append(`<input class="selected_input d-none" value=${selectedImages[0]}>`);
                    $("#select_image").append(`<div style="font-family: Arial, sans-serif; font-size:13px" >
                    <b>Uploaded on:</b> ${data.yearMonth}<br>
                    <b>File Name:</b> ${data.filename}<br>
                    <b>File Type:</b> ${data.contentType}<br>
                    <b>File Size:</b> ${data.sizeInKB}KB<br>
                    <b>Dimensions:</b> ${width} by ${height} pixels<br>
                    <b>Storage Provider:</b> ${data.storageProvider}<br>
                    <b>Region:</b> ${data.region}<br>
                    <b>Bucket:</b> ${data.bucket}<br>
                    </div>
                    `);

                    $("#select_image").append(`
            
                    File Url:  <input type="text" class="form-control border-gray" id="myInput" value="${imageUrl}"><br>
                    <button class="clip" style=" color:blue; border-color:blue;border-radius: 10px;">Copy URL to Clipboard</button>
                    <button class="attach" style=" color:blue; border-color:blue;border-radius: 10px;">View Attachment page</button>
                    <button class="delete" style=" color:red; border-color:red;border-radius: 10px;">Delete Permanentely</button>
                    
                    `)
                        
                        
                       $('.clip').on('click', function() {
                        var inputValue = $('#myInput').val();

                        // Use navigator.clipboard.writeText to copy text to clipboard
                        navigator.clipboard.writeText(inputValue)
                          .then(function() {
                            alert('URL copied to clipboard' );
                          })
                          .catch(function(error) {
                            console.error('Error copying text to clipboard:', error);
                          });
                       
                    });
                    $('.attach').on('click', function () {
                      var $link = $('<a>').attr('href', imageUrl).attr('target', '_blank');
                      $link[0].click();
                    });

                    $('.download').on('click', function() {
                      downloadImage(imageUrl, "yo");
                    });

                    $('.delete').on('click', function() {
                    
                      var isConfirmed = confirm('Are you sure you want to delete this file?');
                    
                      
                      if (isConfirmed) {
                        
                        var filePathToDelete = imageUrl;
                        console.log("ha");
                        console.log(filePathToDelete);
                        
                        $.ajax({
                          url: '/delete_images',
                          type: 'POST',
                          data: { filePath: filePathToDelete },
                          success: function(data) {
                            console.log('File deleted successfully:', data);
                            window.location.href = '/portal/library/';
                         
                          },
                          error: function(error) {
                            console.error('Error deleting file:', error);
                          }
                        });
                      } else {
                   
                        alert('File deletion canceled.');
                      }
                    });
                    
 


                   
                  
                      
                     
                }
            })  
                
                });
            }
        });
    });
 

  

                    
    // Handle form submission
    $('#submitImages').click(function () {
        // Perform AJAX request to save selected images
        $.ajax({
            url: 'save_images.php', // Replace with your server-side script to save images
            type: 'POST',
            data: { images: selectedImages },
            success: function (response) {
                // Handle the response from the server
                console.log(response);
            }
        });

        // Close the modal after submission
        $('#imageModal').modal('hide');
    });

    // gallery open code start 
    $("#img_upload").click(function(){
        $("#upload-tab").click();
        $('.modal-body').html(`<div id="content">
                          <form class="dropzone" id="file_upload"></form>
                              </div>`);
        $("#image_submit_div").html(`<button id="upload_btn" class="btn btn-primary">Upload</button>`);
              dropzonecode();
        $("#image_modal").click();
      })
  
              // gallery open code end 
  
      $("#upload-tab").click(function(){
        upload_tab();
      });
  
      function upload_tab(){
        $('.modal-body').html("");
        $('.modal-body').html(`<div id="content">
                  <form class="dropzone" id="file_upload"></form>
                      </div>`);
        $("#image_submit_div").html(`<button id="upload_btn" class="btn btn-primary">Upload</button>`);
        dropzonecode();
      }
  
      function removemsg(){
        setInterval(function () {
          $('.upload_message').html('');
        }, 4000);
      }
  
      function dropzonecode(){
          Dropzone.autoDiscover = false;
      
          var myDropzone = new Dropzone("#file_upload", { 
          url: "/set_s3_image",
          parallelUploads: 3,
          uploadMultiple: false,
          acceptedFiles: '.png,.jpg,.jpeg',
          autoProcessQueue: false,
          success: function(file,response){
              console.log(response);
              if(response.status == 'success'){
                $('#content .message').hide();
                $('.upload_message').html('<div class="message text-success">Images Uploaded Successfully.</div>');
                $('#media-tab').click();
                removemsg();
              }else{
                $('#content').append('<div class="message text-danger">Images Uploaded Successfully.</div>');
                removemsg();
              }
          },
          error: function(file, errorMessage, xhr) {
            // Handle the error here
            console.log(errorMessage);
            $('#content').append('<div class="message error">Error uploading file. Try after some time</div>');
          }
          });
  
          $('#upload_btn').click(function(){
          myDropzone.processQueue();
          });
      }
  
      // $("#save_img_btn").click(function(){
        $(document).on("click", "#save_img_btn", function(e) {
        let image_value = $(".selected_input").val();
        console.log(image_value);
        console.log("e");
        $("#thumbnail").val(image_value);
  
        $('#quick_modal').modal('toggle'); 
  
        $('#quick_thumbnail').val(image_value);
              
        $(".image-container").html(`<img src="${image_value}" alt="" class="rounded-image" />
                              <button class="btn btn-danger remove-field" type="button">X</button>`);
          $(".btn-close").click();
      });
  
      // $(".remove-field").click(function () {
        $(document).on("click", ".remove-field", function(e) {
            // Find the closest image and remove it
            $(this).closest(".image-container").find("img").remove();
            // Optionally, you can also remove the button itself if needed
            $(this).remove();
            $("#thumbnail").val("");
        });
  
});
