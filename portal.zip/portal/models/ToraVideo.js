import mongoose from 'mongoose';

// Define the schema
const toraVideoSchema = new mongoose.Schema({
  videoId: Number,
  title: {
    type: String,
    required: true,
  },
  description: String,
  slug: String,
  thumbnail: String,
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    // required: true,
  },
  user_id:Number,
  lang: [String],
  recordLocation: String,
  recordedAt: Date,
  uploadedAt: {
    type: Date,
    default: Date.now,
  },
  vimeoId: String,
  shortVideo: Number,
  uploadType: {
    type: String,
    enum: ['single_video', 'url', 'merge_video'], // Add the allowed values for UploadType
  },
  videoSource: String,
  video_audio_name:String,
  audioLink: String,
  has_mp3:Number,
  video_duration:String,
  video_audio_source_name:String,
  video_is_valid:String,
  hebrew_recorded_date:String,
  upload_finish:Number,
  visible: {
    type: String,
    enum: ['mobile', 'desktop', 'both', 'none'],
  },
  status: { 
    type: String, 
    enum: ['draft', 'publish', 'trash'], default: 'draft' 
  },
  hide_home_page:{
    type:String,
    enum:['yes','no'],default:'no'
  },

  publishedAt: Date,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: Date,
  link:String,
  likes:Number,
  views:Number,
  tab_numbers:Number,
  size:String

});

// Create the model
const ToraVideoModel = mongoose.model('tora_videos', toraVideoSchema);

export default ToraVideoModel;
