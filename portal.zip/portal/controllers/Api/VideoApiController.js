import mongoose from "mongoose";
import ToraLog from "../../models/ToraLog.js";
import ToraTermRelationModel from "../../models/ToraTermRelation.js";
import ToraVideoModel from "../../models/ToraVideo.js";
import UserModel from "../../models/User.js";
import ToraCommentsModel from "../../models/ToraComments.js";
import ToraLikesModel from "../../models/Toralikes.js";
import ToraTermRelation2Model from "../../models/ToraTermRelation2.js";
class VideoApiController{
    static get_videos = async (req, res) =>{
        try {
            const pageNumber = req.query.page;
            const status = req.query.status;
            const pageSize =  parseInt(req.query.page_size, 10); // Specify the number of documents per page
            // const pageSize =  200; 
            const queryparam = req.query.search;
            const auth_id = req.query.auth_id;
            const cat_id = req.query.cat_id;

            const skipCount = (pageNumber - 1) * pageSize;

            const sizeCondition = {
                // $regex: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9.]+)$/, // Matches patterns like 128.36MB, 304.8MB, 1.921GB
                $regex: /^[^1]\d*(\.\d+)?\s*GB$/i, // Matches patterns like 128.36MB, 304.8MB, 1.921GB
                // $gte: '2GB' // Greater than or equal to 2GB
            };

            // console.log("=== page no ===");
            // console.log(pageNumber);
            // console.log("== skip count ====");
            // console.log(skipCount);

            // const videos = await ToraVideoModel.find();
            const aggregationPipeline = [
                {
                    $sort: {
                        videoId: -1 // Sort by publishedAt in descending order (latest to oldest)
                    }
                },
                {
                    $lookup: {
                        from: 'tora_users', // The collection you want to join with
                        localField: 'user_id', // Field from the "tora_videos" collection
                        foreignField: 'user_id',  // Field from the "tora_users" collection
                        as: 'user' // Alias for the joined data
                    }
                },
                {
                    $lookup: {
                        from: 'tora_languages', // The collection you want to join with
                        localField: 'lang', // Field from the "tora_videos" collection
                        foreignField: 'langCode',  // Field from the "tora_users" collection
                        as: 'language' // Alias for the joined data
                    }
                },
                {
                    $lookup: {
                        from: 'tora_term_relations2', // The collection you want to join with
                        localField: 'videoId', // Field from the "tora_videos" collection
                        foreignField: 'objectId',  // Field from the "tora_users" collection
                        as: 'taxoinfo' // Alias for the joined data
                    }
                },
                {
                    $lookup: {
                        from: 'tora_taxonomies',
                        localField: 'taxoinfo.termId',
                        foreignField: 'term_id',
                        as: 'termRelations2',
                    },
                },
                {
                    $lookup: {
                        from: 'tora_countries',
                        localField: 'taxoinfo.termId',
                        foreignField: 'term_id',
                        as: 'countries',
                    },
                },
                {
                    $addFields: {
                    'termlang': {
                        $filter: {
                            input: '$termRelations2.translations',
                            as: 'translation',
                            cond: {},  
                        },
                    },
                    },
                },
                {
                    $project: {
                        taxonomies: 0, // Exclude the termRelations array from the result
                    },
                },
                {
                    $match: {
                        vimeoId: { $exists: true },
                        // size: { $exists: true },
                    }
                },
                // {
                //     $skip: (pageNumber - 1) * pageSize
                // },
                // {
                //     $limit: pageSize
                // }
            ];

            if (status) {
                if (status === "audio") {
                    aggregationPipeline.push({
                        $match: {
                            status: { $ne: 'trash' },
                            vimeoId: "0"
                        }
                    });
                } 
                else if(status == "short_clip"){
                    aggregationPipeline.push({
                        $match: {
                            status: { $ne: 'trash' },
                            shortVideo: 1
                        }
                    });
                }
                else if(status == "large_videos"){
                    aggregationPipeline.push({
                        $match: {
                            status: { $ne: 'trash' },
                            size: sizeCondition,
                        }
                    });
                }
                else {
                    aggregationPipeline.push({
                        $match: {
                            'status': status
                        }
                    });
                }
            } else {
                aggregationPipeline.push({
                    $match: {
                        status: { $ne: 'trash' },
                        vimeoId: { $ne: "0" }
                    }
                });
            }
            

            if(auth_id){
                aggregationPipeline.push({
                    $match: {
                        // 'user._id': new mongoose.Types.ObjectId(auth_id)
                        'user.user_id': parseInt(auth_id)
                    }
                });
            }

            if(cat_id){
                aggregationPipeline.push(
                    {
                    $match: {
                        // 'termRelations._id': new mongoose.Types.ObjectId(cat_id)
                        // 'termRelations2.term_id': parseInt(cat_id)
                        'taxoinfo.termId': parseInt(cat_id)
                    }
                });
            }

            // Add $skip and $limit stages
            if ((typeof queryparam !== "undefined") && queryparam) {
                // Add the $match stage conditionally if queryparam is not empty
                aggregationPipeline.push({
                    $match: {
                        'title': new RegExp(`^${queryparam}`, "i") // Case-insensitive match for titles starting with queryparam
                    }
                });
            }

            aggregationPipeline.push(
                {
                $skip: (pageNumber - 1) * pageSize
            }, {
                $limit: pageSize
            });

            const totalDocumentsPipeline = [...aggregationPipeline];
            const videos = await ToraVideoModel.aggregate(aggregationPipeline);
            // .skip(skipCount).limit(pageSize);

            // const totalDocuments = await ToraVideoModel.countDocuments(totalDocumentsPipeline).count("total");
            let totalPages = 0;
            if(videos.length != 0){
                const totalDocuments = await ToraVideoModel.aggregate(totalDocumentsPipeline).count("total");
                // const totalDocuments = videos.length;
                const totalCount = totalDocuments[0].total;
    
                totalPages = Math.ceil(totalCount / pageSize);
            }


            let count_query = {};
            if(status){
                if (status === "audio") {
                    count_query.status = { $ne: 'trash' },
                    count_query.vimeoId = "0"
                }
                else if(status == "short_clip"){
                    count_query.status = { $ne: 'trash' };
                    count_query.shortVideo = 1; 
                }
                else if(status == "large_videos"){
                    count_query.status = { $ne: 'trash' };
                    count_query.size = sizeCondition;
                }
                else{
                    count_query.status = status;
                }
            }else{
                count_query.status = { $ne: 'trash' };
                count_query.vimeoId = { $ne: "0" } 
            }

            if(auth_id){
                count_query.status = { $ne: 'trash' };
                count_query.user_id = parseInt(auth_id);
            }
            let totalvideos = await ToraVideoModel.countDocuments(count_query);
            if(cat_id){
                totalvideos = await ToraTermRelation2Model.countDocuments({termId:parseInt(cat_id)});
            }
            totalPages = Math.ceil(totalvideos / pageSize);
            console.log("total pages");
            console.log(totalPages);

            res.status(200).json({ status: "success", data: videos, totalPages: totalPages, totalvideos:totalvideos });  
        } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
        }
    }

    static update_videos = async (req, res) => {
        // res.send(req.body);
        try{
            const {title, description, thumbnail, record_location, recorded_date, vimeo_id, video_source, audio_link, visible, short_video, status, topics, series, language, organization, author, hebrew_recorded_date, video_field_id, hide_home_page,link ,upload_finish,video_audio_name,video_audio_source_name,likes,views,tab_numbers} = req.body;
            let user = await UserModel.findById(req.session.userId);
            const video_old_details = await ToraVideoModel.findById(req.params.id);
            // status change log
            if(video_old_details.status != status){
                const log_doc = new ToraLog({
                                    event:"Status Changed",
                                    entity:"Video",
                                    entityId: req.params.id,
                                    user:user._id,
                                    changes:{field:"status",oldValue:video_old_details.status, newValue:status}
                                });
                const logsave = await log_doc.save();
            }
            // title change log
            if(video_old_details.title != title){
                const log_doc = new ToraLog({
                                    event:"Title Changed",
                                    entity:"Video",
                                    entityId: req.params.id,
                                    user:user._id,
                                    changes:{field:"title",oldValue:video_old_details.title, newValue:title}
                                });
                const logsave = await log_doc.save();
            }

            // res.send(thumbnail);
          
            var shortVideo = (short_video) ? short_video : 0;

            const updateFields = {
                videoId:video_field_id,
                title: title,
                description: description,
                slug: "",
                thumbnail: thumbnail,
                lang: language,
                // userId:author,
                
                recordLocation: record_location,
                recordedAt: recorded_date,
                vimeoId: vimeo_id,
                videoSource: video_source,
                audioLink: audio_link,
                visible: visible,
                status: status,
                shortVideo: shortVideo,
                hebrew_recorded_date:hebrew_recorded_date,
                hide_home_page:hide_home_page,
                link:link,
                upload_finish:upload_finish,
                video_audio_name:video_audio_name,
                video_audio_source_name:video_audio_source_name,
                likes:likes,
                views:views,
                tab_numbers:tab_numbers
            };

            if(author){
                updateFields.user_id =author;
            }

            if (status === "publish") {
                updateFields.publishedAt = new Date(); // Add the current date to publishedAt
            }
            console.log("org edit")
            console.log(organization)
            var video_id = req.params.id;
            // console.log(video_id);
            console.log(video_field_id)
            // console.log("this is id");
            const torarelationdelete = await ToraTermRelation2Model.deleteMany({ objectId: video_field_id });

            if(torarelationdelete){
                if(video_id){
                    if (topics && topics.length > 0) {
                        var topics_val = Array.isArray(topics) ? topics : [topics];
                        for (const topic of topics_val) {
                            const tora_temrm = new ToraTermRelation2Model({
                            objectType: 'video', // Replace with the appropriate user ID
                            objectId: video_field_id,
                            termId: topic,
                            termName: 'topic',
                            });
                            await tora_temrm.save();
                        }
                    }
                    if (series && series.length > 0) {
                        var series_val = Array.isArray(series) ? series : [series];
                        for (const serie of series_val) {
                            const tora_temrm = new ToraTermRelation2Model({
                            objectType: 'video', // Replace with the appropriate user ID
                            objectId: video_field_id,
                            termId: parseInt(serie),
                            termName: 'series',
                            });
                            const savedToraTerms = await tora_temrm.save();
                        }
                    }
                    if (organization && organization.length > 0) {
                    var organization_val = Array.isArray(organization) ? organization : [organization];
                        for (const organiza of organization_val) {
                            const tora_temrm = new ToraTermRelation2Model({
                            objectType: 'video', // Replace with the appropriate user ID
                            objectId: video_field_id,
                            termId: parseInt(organiza),
                            termName: 'organization',
                            });
                           const yo= await tora_temrm.save();
                           console.log("after edit org")
                           console.log(yo)
                        }
                    }
                }
            }

            const result = await ToraVideoModel.findByIdAndUpdate(req.params.id, updateFields);
            res.status(201).json({ status: 'success', data: result });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }

        // res.send(req.params);
    }

    static delete_videos = async(req, res) =>{
        try {
            const result = await ToraVideoModel.findByIdAndRemove(req.params.id);
            res.status(201).json({ status: 'success', data: result });
          } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Failed to delete video.' });
          }
    }

    static latest_videos = async (req, res) =>{

        try {
            
            var current_lang = req.params.lang || 'en';

            const recent_vid  = await ToraVideoModel.aggregate([
               
                {
                    $match: {
                      'status': 'publish',
                    },
                },
                {
                $lookup: {
                    from: 'tora_users', // Assuming this is the name of the users collection
                    localField: 'userId',
                    foreignField: '_id',
                    as: 'user',
                },
                },
                {
                $lookup: {
                    from: 'tora_languages', // Assuming this is the name of the users collection
                    localField: 'lang',
                    foreignField: 'langCode',
                    as: 'languages',
                },
                },
               
                {
                    $lookup: {
                    from: 'tora_term_relations',
                    localField: '_id',
                    foreignField: 'objectId',
                    as: 'categories',
                    },
                },
                {
                    $unwind: '$categories',
                },
                {
                    $lookup: {
                        from: 'tora_taxonomies',
                        localField: 'categories.termId',
                        foreignField: '_id',
                        as: 'category',
                    },
                },
                {
                    $match: {
                        'category.type': 'topic',
                    },
                },
                {
                    $unwind: '$category',
                },
               
                {
                    $group: {
                        _id: '$title',
                        doc: { $first: '$$ROOT' },
                    },
                },
                {
                    $replaceRoot: { newRoot: '$doc' },
                },
                {
                    $sort: {
                        publishedAt: -1,
                    },
                },
                {
                    $project: {
                    _id: 1,
                    thumbnail: 1,
                    'user.thumbnail': 1,
                    title: 1,
                    'user.title': 1,
                    'user.firstName': 1,
                    'user.lastName': 1,
                    //   'category.translations': 1,
                    'category._id': 1,
                    publishedAt: 1,
                    'languages.language': 1,
                    'category.translations': {
                            $filter: {
                            input: '$category.translations',
                            as: 'translation',
                            cond: { $eq: ['$$translation.languageCode', current_lang] },
                            },
                        },
                    'category.title':1
                    },
                },
            ]);

            res.send(recent_vid);
        } catch (error) {
            console.log(error);
            res.status(500).json({ status: "error", message: error });
        }

    }


    static related_videos = async (req, res) =>{

        try {
            const page = req.query.pageno;
            const pageSize = parseInt(req.query.pagesize) || 10;
            var current_lang = req.params.lang || 'en';

            const recent_vid  = await ToraVideoModel.aggregate([
                {
                    $match: {
                      'status': 'publish',
                    },
                },
                {
                $lookup: {
                    from: 'tora_users', // Assuming this is the name of the users collection
                    localField: 'userId',
                    foreignField: '_id',
                    as: 'user',
                },
                },
                {
                $lookup: {
                    from: 'tora_languages', // Assuming this is the name of the users collection
                    localField: 'lang',
                    foreignField: 'langCode',
                    as: 'languages',
                },
                },
                {
                    $lookup: {
                    from: 'tora_term_relations',
                    localField: '_id',
                    foreignField: 'objectId',
                    as: 'categories',
                    },
                },
                {
                    $unwind: '$categories',
                },
                {
                    $lookup: {
                        from: 'tora_taxonomies',
                        localField: 'categories.termId',
                        foreignField: '_id',
                        as: 'category',
                    },
                },
                {
                    $unwind: '$category',
                },
                {
                    $project: {
                    _id: 1,
                    thumbnail: 1,
                    'user.thumbnail': 1,
                    title: 1,
                    'user.title': 1,
                    'user.firstName': 1,
                    'user.lastName': 1,
                    //   'category.translations': 1,
                    'category._id': 1,
                    publishedAt: 1,
                    'languages.language': 1,
                    'category.translations': {
                            $filter: {
                            input: '$category.translations',
                            as: 'translation',
                            cond: { $eq: ['$$translation.languageCode', current_lang] },
                            },
                        },
                    'category.title':1
                    },
                },
                {
                    $skip: (page - 1) * pageSize,
                },
                {
                    $limit: pageSize,
                },
                
            ]);

            res.send(recent_vid);
        } catch (error) {
            console.log(error);
            res.status(500).json({ status: "error", message: error });
        }

    }

    static single_videos = async (req, res)=>{
        try {
            // var single_vid = await ToraVideoModel.findById(req.params.id);
            const single_video = await ToraVideoModel.findById(req.params.id).select('_id title description visible status lang userId publishedAt hide_home_page');

            const topic_results = await ToraTermRelationModel.find({
                $and:[
                    { termName: 'topic' },
                    { objectId: req.params.id}   
                ]
            }).select('termId');
            const topicIds = topic_results.map(result => result.termId);

            const series_results = await ToraTermRelationModel.find({
                $and:[
                    { termName: 'series' },
                    { objectId: req.params.id}   
                ]
            }).select('termId');
            const seriesIds = series_results.map(result => result.termId);

            const organizaiton_results = await ToraTermRelationModel.find({
                $and:[
                    { termName: 'organization' },
                    { objectId: req.params.id}   
                ]
            }).select('termId');
            const organizationIds = organizaiton_results.map(result => result.termId);
          //  taxonomies: 0, // Exclude the termRelations array from the result

            res.status(201).json({ status: 'success', data: {'video_info':single_video, 'topic_id':topicIds, 'series_id':seriesIds, 'organization_id':organizationIds } });
        } catch (error) {
            console.log(error);
            res.status(500).json({ status: "error", message: error });
        }
    }

    static quick_vid_submit = async (req, res) => {
        try {
            const { title, description, topics, series, organization, status, visible, author, language ,hide_home_page} = req.body;
    
            let user = await UserModel.findById(req.session.userId);
            const video_old_details = await ToraVideoModel.findById(req.params.id);
    
            if (video_old_details.status != status) {
                const log_doc = new ToraLog({
                    event: "Status Changed",
                    entity: "Video",
                    entityId: req.params.id,
                    user: user._id,
                    changes: { field: "status", oldValue: video_old_details.status, newValue: status },
                });
                const logsave = await log_doc.save();
            }
    
            if (video_old_details.title != title) {
                const log_doc = new ToraLog({
                    event: "Title Changed",
                    entity: "Video",
                    entityId: req.params.id,
                    user: user._id,
                    changes: { field: "title", oldValue: video_old_details.title, newValue: title },
                });
                const logsave = await log_doc.save();
            }
    
            const updateFields = {
                title: title,
                description: description,
                lang: language,
                userId: author,
                visible: visible,
                status: status,
                hide_home_page:hide_home_page
            };
    
            if (status === "publish") {
                updateFields.publishedAt = new Date();
            }
    
            const video_id = req.params.id;
    
            await ToraTermRelationModel.deleteMany({ objectId: req.params.id });
    
            if (video_id) {
                if (topics && topics.length > 0) {
                    const topics_val = Array.isArray(topics) ? topics : [topics];
                    const topicDocuments = topics_val.map(topic => ({
                        objectType: 'video',
                        objectId: video_id,
                        termId: topic,
                        termName: 'topic',
                    }));
                    await ToraTermRelationModel.insertMany(topicDocuments);
                }
                if (series && series.length > 0) {
                    const series_val = Array.isArray(series) ? series : [series];
                    const seriesDocuments = series_val.map(serie => ({
                        objectType: 'video',
                        objectId: video_id,
                        termId: serie,
                        termName: 'series',
                    }));
                    await ToraTermRelationModel.insertMany(seriesDocuments);
                }
                if (organization && organization.length > 0) {
                    const organization_val = Array.isArray(organization) ? organization : [organization];
                    const organizationDocuments = organization_val.map(organiza => ({
                        objectType: 'video',
                        objectId: video_id,
                        termId: organiza,
                        termName: 'organization',
                    }));
                    await ToraTermRelationModel.insertMany(organizationDocuments);
                }
            }
    
            const result = await ToraVideoModel.findByIdAndUpdate(req.params.id, updateFields);
    
            res.status(201).json({ status: 'success', data: result });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
    }
    

    static bulk_video_submit = async (req, res) => {
        try {
            const { description, language, author, visible, status, topics, series, organization } = req.body;
    
            const formData = req.body;
            for (const key in formData) {
                if (key.startsWith('name')) {
                    const id = key.substr(4);
                    const newtitle = formData[key];
    
                    const updateFields = {
                        title: newtitle,
                    };

                    if(description){
                        updateFields.description = description;
                    }
                    if(language){
                        updateFields.lang = language;
                    }
                    if(author){
                        updateFields.userId = author;
                    }
                    if(visible){
                        updateFields.visible = visible;
                    }
                    if(status){
                        updateFields.status = status;
                    }
    
                    if (status === "publish") {
                        updateFields.publishedAt = new Date();
                    }
    
                    const video_id = id;
    
                    
                    if (video_id) {
                       
                            if (topics && topics.length > 0) {
                                await ToraTermRelationModel.deleteMany({ objectId: video_id, termName: 'topic' });
                                const topics_val = Array.isArray(topics) ? topics : [topics];
                                const topicDocuments = topics_val.map(topic => ({
                                    objectType: 'video',
                                    objectId: video_id,
                                    termId: topic,
                                    termName: 'topic',
                                }));
                                await ToraTermRelationModel.insertMany(topicDocuments);
                            }
                     
                      
                            if (series && series.length > 0) {
                                await ToraTermRelationModel.deleteMany({ objectId: video_id, termName: 'series' });
                                const series_val = Array.isArray(series) ? series : [series];
                                const seriesDocuments = series_val.map(serie => ({
                                    objectType: 'video',
                                    objectId: video_id,
                                    termId: serie,
                                    termName: 'series',
                                }));
                                await ToraTermRelationModel.insertMany(seriesDocuments);
                            }
                      
                     
                        if (organization && organization.length > 0) {
                            await ToraTermRelationModel.deleteMany({ objectId: video_id, termName: 'organization' });
                            const organization_val = Array.isArray(organization) ? organization : [organization];
                            const organizationDocuments = organization_val.map(organiza => ({
                                objectType: 'video',
                                objectId: video_id,
                                termId: organiza,
                                termName: 'organization',
                            }));
                            await ToraTermRelationModel.insertMany(organizationDocuments);
                        }
                    }
    
                    await ToraVideoModel.findByIdAndUpdate(video_id, updateFields);
                }
            }
    
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
    }

    static change_status = async (req,res) =>{
        try {
            var id = req.params.id;
            const updateFields = {
                status:'trash',
            };
            
            const result = await ToraVideoModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
      
    }

    static restore_vid = async (req, res) =>{
        try {
            var id = req.params.id;
            const updateFields = {
                status:'publish',
            };
            
            const result = await ToraVideoModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
    }

    static bulk_trash = async (req, res) =>{
        try{
  
          var ids = req.body;
          if (ids && Array.isArray(ids)) {
            for (const id of ids) {
              const result = await ToraVideoModel.findByIdAndUpdate(id.id,{ status: 'trash' });
            }
            res.status(201).json({ status: 'success' });
          }else {
            res.status(400).json({ error: 'Invalid request data.' });
          }
        } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
        }
      }
  
      static bulk_restore = async (req, res) =>{
        try{
  
          var ids = req.body;
          if (ids && Array.isArray(ids)) {
            for (const id of ids) {
              const result = await ToraVideoModel.findByIdAndUpdate(id.id,{ status: 'publish' });
            }
            res.status(201).json({ status: 'success' });
          }else {
            res.status(400).json({ error: 'Invalid request data.' });
          }
        } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
        }
      }
    
      static author_video = async (req, res) => {
        const auth_id = req.params.id;
    
        try {
            const result = await ToraVideoModel.aggregate([
                {
                    $match: { 'userId': new mongoose.Types.ObjectId(auth_id) }
                },
                
                {
                    $lookup: {
                        from: 'tora_users',
                        localField: 'userId',
                        foreignField: '_id',
                        as: 'user_info'
                    }
                },
                {
                    $project: {
                        title:1,
                         userId:1,
                          recordedAt:1,
                           status:1,
                            uploadedAt:1,
                             createdAt:1,
                              publishedAt:1,
                        user_info: {
                            _id: 1, // Include other fields from the users_models collection as needed
                            user_id: 1, // Add a new field for the auto-incremented ID
                            firstName:1,
                             lastName:1
                        }
                    }
                }
            ]);
    
            res.send(result);
        } catch (error) {
            console.error('Error:', error);
            res.status(500).send('Internal Server Error');
        }
    };

    

    static video_detail = async (req, res) => {
        const video_id = req.params.id;
    
        try {
            const result = await ToraVideoModel.aggregate([
                {
                    $match: { '_id': new mongoose.Types.ObjectId(video_id) }
                },
                
                {
                    $lookup: {
                        from: 'tora_users',
                        localField: 'userId',
                        foreignField: '_id',
                        as: 'user_info'
                    }
                },
                {
                    $lookup: {
                        from: 'tora_term_relations', 
                        localField: '_id', 
                        foreignField: 'objectId',  
                        as: 'taxonomies' 
                    }
                },
                {
                    $lookup: {
                        from: 'tora_taxonomies',
                        localField: 'taxonomies.termId',
                        foreignField: '_id',
                        as: 'category_info',
                    },
                },
                
              
                {
                    $addFields: {
                        category_info: {
                            $filter: {
                                input: '$category_info',
                                as: 'filtercat',
                                cond: { $eq: ['$$filtercat.type', 'topic'] }
                            }
                        }
                    }
                },
                
                {
                    $lookup: {
                        from: 'tora_comments',
                        localField: '_id',
                        foreignField: 'videoId',
                        as: 'comments_info',
                    },
                },
                {
                    $lookup: {
                        from: 'tora_likes',
                        localField: '_id',
                        foreignField: 'objectId',
                        as: 'likes_info',
                    },
                },
                {
                    $unwind: {
                        path: '$likes_info',
                        preserveNullAndEmptyArrays: true,
                    }, 
                },
                {
                    $match: {
                        $or: [
                            { 'likes_info.type': 'like' },
                            { 'likes_info': { $exists: false } },
                        ],
                    },
                },
                {
                    $group: {
                        _id: '$_id',
            title: { $first: '$title' },
            recordedAt: { $first: '$recordedAt' },
            views: { $first: '$views' },
            lang: { $first: '$lang' },
            video_is_valid: { $first: '$video_is_valid' },
            videoId: { $first: '$videoId' },
            has_mp3: { $first: '$has_mp3' },
            videoSource: { $first: '$videoSource' },
            video_audio_source_name: { $first: '$video_audio_source_name' },
            video_audio_name: { $first: '$video_audio_name' },
            link: { $first: '$link' },
            video_duration: { $first: '$video_duration' },
            hebrew_recorded_date: { $first: '$hebrew_recorded_date' },
            audioLink: { $first: '$audioLink' },
            likes: { $first: '$likes' },
            user_info: { $first: '$user_info' },
            category_info: { $first: '$category_info' },
            comments_info: { $first: '$comments_info' },
            likes_info: { $push: '$likes_info' },
             likes_count: { $sum: 1 }, // Count the number of likes
                    },
                },
                // {
                //     $lookup: {
                //         from: 'tora_likes',
                //         localField: '_id',
                //         foreignField: 'objectId',
                //         as: 'likes_info',
                //         cond: { $eq: ['$$likes_info.type', 'like'] }
                //     },
                // },
                // {
                //     $addFields: {
                //         likes_info: {
                //             $filter: {
                //                 input: '$likes_info',
                //                 as: 'filterlike',
                //                 cond: { $eq: ['$$filterlike.type', 'like'] }
                //             },
                //             likes_count: { $size: '$filterlike' } 

                //         },
                //     }
                // },
               
                
                {
                    $project: {
                        title:1,
                        recordedAt:1,
                        views:1,
                        lang:1,
                        video_is_valid:1,
                        videoId:1,
                        has_mp3:1,
                        videoSource:1,
                        video_audio_source_name:1,
                        video_audio_name:1,
                        link:1,
                        video_duration:1,
                        hebrew_recorded_date:1,
                        audioLink:1,
                        likes:1,
         

                        user_info: {
                            _id: 1, 
                            firstName:1,
                             lastName:1,
                             gender:1,
                             membertitle:1,
                        },

                        category_info:{
                           title :1,
                        },
                        comments_info:{
                            status:1,
                            comment:1,
                            
                        },
                        likes_info:{
                            type:1,
                            createdAt:1,
                        },
                        // likes_count:1,
                        likes_count: {
                            $cond: {
                                if: { $gt: [{ $size: "$likes_info" }, 0] }, // Check if likes_info is not empty
                                then: { $size: "$likes_info" }, // Count the number of likes
                                else: 0, // Set likes_count to 0
                            },
                        },
                    }
                },
                
            ]);
    
            res.send(result);
        } catch (error) {
            console.error('Error:', error);
            res.status(500).send('Internal Server Error');
        }
    };

    static comment_post = async (req, res) => {
        const videoId = req.params.id;
    
        const { status, comment, userId } = req.body;

        
      
        // Create a new comment object
        const newComment = {
          status,
          comment,
          userId,
          videoId,
        };
      
        // Store the comment in the dummy database
        ToraCommentsModel.create(newComment);
      
        // Return the created comment
        res.status(201).json(newComment);
    }

    static likes_post = async (req, res) => {
        const objectId = req.params.id;
    
        const { type, objectType, userId } = req.body;

        
      
        // Create a new comment object
        const newComment = {
           type,
          objectType,
          userId,
          objectId,
        };
      
        // Store the comment in the dummy database
        ToraLikesModel.create(newComment);
      
        // Return the created comment
        res.status(201).json(newComment);
    }
}


export default VideoApiController;