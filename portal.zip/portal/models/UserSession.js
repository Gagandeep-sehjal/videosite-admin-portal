import mongoose from 'mongoose';

const userSessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'UserModel', // Assuming you have a User model
    required: true,
  },
  userEmail: {
    type: String,
    required: true,
  },
  // You can add more fields as needed, such as sessionToken, createdAt, etc.
}, { timestamps: true });

// Create an index on userId to optimize queries
userSessionSchema.index({ userId: 1 });

// Create the UserSession model
const UserSessionModel = mongoose.model('UserSession', userSessionSchema);

// Export the UserSession model
export default UserSessionModel;
