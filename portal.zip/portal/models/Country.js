import mongoose from "mongoose";

const countrySchema = new mongoose.Schema({
  country: { type: String, required: true },
  countryCode: { type: String},
  deletedAt: Date,
  thumbnail:{type:String},
  slug:{type:String},
  term_id:Number,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

const CountryModel = mongoose.model("tora_countries", countrySchema);

export default CountryModel;
