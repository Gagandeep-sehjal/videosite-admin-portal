import { S3Client, GetObjectCommand,HeadObjectCommand ,DeleteObjectCommand, PutObjectCommand, ListObjectsV2Command } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';
import { Readable } from 'stream';
import fs from 'fs';
import https from 'https';
import AmazonCognitoIdentity from 'amazon-cognito-identity-js';
import { resolve } from 'path';
import AWS from 'aws-sdk';


const s3Config = {
  region: "us-east-1",
  credentials: {
    accessKeyId: "your_id",
    secretAccessKey: "your_id"
  }
};

const s3Client = new S3Client(s3Config);



const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);


const cognito = new AWS.CognitoIdentityServiceProvider();

// Define the getLanguageName function
function getLanguageName(langCode) {
    let languageName = '';
    switch (langCode) {
      case 'es':
        languageName = 'Spanish';
        break;
      case 'he':
        languageName = 'Hebrew';
        break;
      case 'yi':
        languageName = 'Yiddish';
        break;
      case 'en':
        languageName = 'English';
        break;
      default:
        // Default case or handle other language codes
        break;
    }
    return languageName;
}

function getTranslation(item, current_lang) {
  // Find the translation that matches the current language
  var translation = item.translations.find(function (t) {
    return t.languageCode === current_lang;
  });

  // If a matching translation is found, return it; otherwise, return the original title
  var title = translation ? translation.translation : "";
  var lang_name = translation ? translation.languageName : "English";
  return {title, lang_name}
}

function formatTime(date) {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return hours + ':' + minutes;
}

function formatDatetime(dateString) {
  const date = new Date(dateString);
  const options = {
    year: '2-digit',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  };
  return date.toLocaleString('en-US', options);
}

// Custom function to convert a title into a slug
function convertToSlug(title) {
  return title
      .toLowerCase() // Convert to lowercase
      .replace(/[^a-z0-9 -]/g, '') // Remove special characters
      .replace(/\s+/g, '-') // Replace spaces with hyphens
      .replace(/-+/g, '-') // Replace multiple hyphens with a single hyphen
      .trim(); // Remove leading/trailing hyphens
}

function convertSpacesToUnderscore(inputString) {
  // Replace spaces with underscores
  return inputString.replace(/ /g, '_');
}

const uploadFileToS3 = async (file) => {
  const filedata = file.data;
  const fileName = convertSpacesToUnderscore(file.name);

  // Get the current year and month
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth() + 1; // Months are zero-indexed

  console.log(currentDate);
  console.log("=== current date ====");
  console.log(currentYear);
  console.log("=== current year ====");

  // Define the folder structure in the S3 bucket
  const folderPath = `wp-content/uploads/${currentYear}/${currentMonth}`;

  // Create a readable stream from the file data
  const bodyStream = Readable.from(filedata);

  // Set the S3 bucket parameters to create folders if they don't exist
  const folderCreationParams = {
    Bucket: 'cdn.to.com',
    Key: `${folderPath}/`, // Add a trailing slash to represent a folder
    Body: '', // Empty body to represent an empty object
  };

  // Create an S3 putObject instance for folder creation
  const folderCreationUpload = new Upload({
    client: s3Client,
    params: folderCreationParams,
  });

  try {
    // Attempt to create the folders (if they don't exist)
    await folderCreationUpload.done();
  } catch (err) {
    // Ignore errors if the folders already exist
    if (err.name !== 'NoSuchKey') {
      console.error('Error creating folders on S3:', err);
      throw err;
    }
  }

  // Set the S3 bucket parameters for the actual file upload
  const fileUploadParams = {
    Bucket: 'cdn.com',
    Key: `${folderPath}/${fileName}`, // Include the folder structure in the key
    Body: bodyStream,
    ContentType: file.mimetype,
  };

  // Create an S3 upload instance for the file
  const fileUpload = new Upload({
    client: s3Client,
    params: fileUploadParams,
  });

  try {
    // Upload the file to S3
    const data = await fileUpload.done();
    return data;
  } catch (err) {
    console.error('Error uploading to S3:', err);
    throw err;
  }
};





const getAllFilesFromS3 = async (month, year, contentType,search) => {
  try {
    const listObjectsParams = {
      Bucket: 'cdn.com',
    };

    const listObjectsCommand = new ListObjectsV2Command(listObjectsParams);
    const data = await s3Client.send(listObjectsCommand);
// console.log(data)
    // Extract the keys (file names) from the list of objects
    let filteredKeys = data.Contents.map(object => object.Key);

      // Filter out only the image files from the specified route
    filteredKeys = filteredKeys.filter(key =>
      key.startsWith('wp-content/uploads/') &&
      /\.(jpg|jpeg|png|gif)$/i.test(key)
    );

    // Apply additional filters based on month and year if provided
    if (month && year) {
      filteredKeys = filteredKeys.filter(key => {
        const match = key.match(/\/(\d{4})\/(\d{2})\//);

        if (match) {
          const fileYear = parseInt(match[1], 10);
          const fileMonth = parseInt(match[2], 10);

          return fileYear === year && fileMonth === month;
        }

        return false;
      });
    }

    // Apply additional filter based on content type if provided
    if (contentType) {
      console.log(contentType)
      if(contentType== 'image'){
      filteredKeys = filteredKeys.filter(key =>
        key.startsWith('wp-content/uploads/') &&
        /\.(jpg|jpeg|png|gif)$/i.test(key)
      );
      }
      else if (contentType === 'video') {
          filteredKeys = filteredKeys.filter(key =>
            key.startsWith('wp-content/uploads/') &&
            /\.(mp4|avi|mov)$/i.test(key)
          );  
    }
    else{
      filteredKeys = filteredKeys.filter(key =>
        key.startsWith('wp-content/uploads/') &&
        /\.(mp3|wav)$/i.test(key)
      );  
  }
}


if(search){
  const searchTerm = search.toLowerCase();
  console.log(search)
  filteredKeys = filteredKeys.filter(key => {
 
    const filename = key.split('/').pop().toLowerCase();
    console.log(filename)
    return filename.includes(searchTerm);
  });
}
    console.log("filtered keys");
    console.log(filteredKeys);

    return filteredKeys;
  } catch (err) {
    console.error('Error listing images in S3:', err);
    throw err;
  }
};

   


const getImageDetailsFromURL = async (imageUrl) => {
  try {
  //   const response = await fetch(imageUrl, { method: 'HEAD' ,timeout: 5000});

    // if (!response.ok) {
    //   throw new Error(`Failed to fetch image from URL: ${imageUrl}`);
    // }

    const url = new URL(imageUrl);
    const bucketName = 'cdn.com'; // Replace with your S3 bucket name
    const objectKey = url.pathname.substring(1); // Removing leading '/'
    console.log(objectKey)

  
  //   // HeadObject request to get metadata
    const headObjectParams = {
      Bucket: bucketName,
      Key: objectKey,
    };

    const metadata = await s3Client.send(new HeadObjectCommand(headObjectParams));
    const sizeInBytes = metadata.ContentLength;
  const sizeInKB = Math.round(sizeInBytes / 1024);
   const contentType = metadata.ContentType;


    // const sizeInBytes = response.headers.get('content-length');
    // const sizeInKB = Math.round(sizeInBytes / 1024);
    // const contentType = response.headers.get('content-type');
    const storageProvider = 'Amazon S3'; // Assuming images are stored in Amazon S3
    const region = s3Config.region; // Replace with your S3 region
    const path = new URL(imageUrl).pathname;
    const access = 'public'; // Assuming the image is public, you may need to adjust this

    // const dimensions = {
    //   width: metadata.Metadata['x-amz-meta-width'],
    //   height: metadata.Metadata['x-amz-meta-height'],
    // };

    const urlSegments = imageUrl.split('/');
    const yearMonth = `${urlSegments[6]}/${urlSegments[5]}`;
    const filename = urlSegments[urlSegments.length - 1];
    const title = filename.replace(/\.[^/.]+$/, '');

    const bucket = 'cdn.oom.com'; // Replace with your S3 bucket name

    

    return {
      yearMonth,
      // modifiedTime,
      // dimensions,
      bucket,
      filename,
      storageProvider,
      region,
      path,
      access,
      sizeInKB,
      contentType,
      title,
    };
  } catch (err) {
    // Handle specific errors or log them
    if (err.name === 'NotFound') {
      console.error('Image not found:', err);
      // Return or handle as needed
    } else if (err.name === 'Forbidden') {
      console.error('Access to the image is forbidden:', err);
      // Return or handle as needed
    } else {
      console.error('Error getting image details from URL:', err);
      throw err; // Rethrow other errors
    }
  }
};

// function convertPercentageToSpaces(inputString) {
//   // Use decodeURIComponent to replace '%20' with spaces
//   return decodeURIComponent(inputString.replace(/\+/g, ' '));
// }
const deleteImageFromURL = async (filePath) => {
  const url = new URL(filePath);
  var objectKey = url.pathname.substring(1);
  // objectKey=convertPercentageToSpaces(objectKey)
  const deleteParams = {
    Bucket: 'cdn.com',
    Key: objectKey, // Full path including the folder structure
  };

  // Create an S3 delete instance for the file

  const fileDeletion = new DeleteObjectCommand(deleteParams);

  try {
    // Delete the file from S3
    console.log(objectKey)
    const data = await s3Client.send(fileDeletion);
    console.log("yo")
    return data;
  } catch (err) {
    console.error('Error deleting file from S3:', err);
    throw err;
  }


};



function organizeIntoTree(data) {
  const tree = {};

  // Iterate over each item and build the tree
  data.forEach(item => {
      // const parentId = item.parentId ? item.parentId.toString() : null;
      const parentId = item.parent_id ? item.parent_id : null;

      if (!parentId) {
      // if (!parentId) {
          // If there's no parentId, it's a top-level item
          // tree[item._id.toString()] = item;
          tree[item.term_id] = item;
      } else {
          // If there's a parentId, add it as a child to its parent (if the parent exists)
          // const parent = tree[parentId];
          // console.log("finally you are here ===");
          const parent = tree[parentId];
          if (parent) {
              // console.log("yes parent ====")
              parent.children = parent.children || [];
              parent.children.push(item);
          } else {
              // If the parent doesn't exist in the current tree, add it as a top-level item
              // console.log("pushing more =====")
              tree[parentId] = { children: [item] };
          }
      }
  });

  return tree;
}

const signUpCognito = async (req, res) =>{

    return new Promise((resolve, reject) => {
      try {
        const {first_name, last_name, email, password, gender, phone  } = req.body;

          console.log(req.body);
          console.log("this is body data ====");
        
          var fullName = first_name+" "+last_name;

          console.log(fullName);
          console.log("this is full name ===");

          const attributeList = [
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'name', Value: fullName }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'email', Value: email }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'phone_number', Value: phone }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'gender', Value: gender }), // Include the "gender" attribute
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'locale', Value: 'en_US' }) // Include the "locale" attribute
            ];

            console.log(attributeList);
            console.log("checking attribute list ====");
        
            userPool.signUp(email, password, attributeList, null, (err, data) => {
              if (err) {
                // reject(err);
                console.log(err);
                console.log("this is error value ====");
                if(err.code == "InvalidPasswordException"){
                  req.session.message = "Password must Contains at least 1 number, Contains at least 1 special character,1 uppercase letter and 1 lowercase letter.";
                  res.redirect("/register");
                }
                else if(err.code == "UsernameExistsException"){
                  req.session.message = "Username already exists";
                  res.redirect("/register");
                }else{
                  req.session.message = "Unable to register.";
                  res.redirect("/register");
                }
               
              }else{
                console.log("signup data");
                console.log(data);
                resolve(data);
              } 
            });
      } catch (error) {
        console.log("this is error message ====");
        console.log(error);
        req.session.message = "An Error occurred.";
        res.redirect("/register");
      }
    });
} 

const signUpCognitoApp = async (req, res) =>{

    return new Promise((resolve, reject) => {
      try {
        const {first_name, last_name, email, password, gender, phone } = req.body;

          console.log(req.body);
          console.log("this is body data ====");
        
          var fullName = first_name+" "+last_name;

          console.log(fullName);
          console.log("this is full name ===");

          const attributeList = [
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'name', Value: fullName }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'email', Value: email }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'phone_number', Value: phone }),
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'gender', Value: gender }), // Include the "gender" attribute
              new AmazonCognitoIdentity.CognitoUserAttribute({ Name: 'locale', Value: 'en_US' }) // Include the "locale" attribute
            ];

            console.log(attributeList);
            console.log("checking attribute list ====");
        
            userPool.signUp(email, password, attributeList, null, (err, data) => {
              if (err) {
                // reject(err);
                console.log(err);
                console.log("this is error value ====");
                if(err.code == "InvalidPasswordException"){
                  res.send({"status":"failed", "message": "Password must Contains at least 1 number, Contains at least 1 special character,1 uppercase letter and 1 lowercase letter."});
                }
                else if(err.code == "UsernameExistsException"){
                  res.send({"status":"failed", "message": "Username already exists"});
                }else{
                  res.send({"status":"failed", "message": "Unable to register."});
                }
               
              }else{
                console.log("signup data");
                console.log(data);
                resolve(data);
              } 
            });
      } catch (error) {
        console.log("this is error message cognito user ====");
        console.log(error);
        res.send({"status":"failed", "message": "Internal server error."});
      }
    });
} 

const verifycode = (username, code) =>{
    return new Promise((resolve, reject) =>{ 
      const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
      const userData = {
          Username: username,
          Pool: userPool
      };

      const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
      cognitoUser.confirmRegistration(code, true, (error, result)=>{
              if(error){
                  reject(error);
              }else{
                  resolve(result);
              }
      });
    })
}




const updateCognitoPassword = async (username,password,oldpassword) => {
  try{
    // const password=req.oldpassword;
    // const newpassword=req.password;
    console.log(password)
    console.log(oldpassword)
    console.log(username)
  var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
    Username: username,
    Password: oldpassword,
});

var userData = {
    Username: username,
    Pool: userPool
};
var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess: function (result) {
        cognitoUser.changePassword(oldpassword, password, (err, result) => {
            if (err) {
                console.log(err);
            } else {
                console.log("Successfully changed password of the user.");
                console.log(result);
            }
        });
    },
    onFailure: function (err) {
        console.log(err);
    },
});
  }catch(err){
    console.log(err);
  }
};


const disableUser = async (username) => {

    return new Promise((resolve, reject) => {
        
        const user_name = username;

        const params = {
          UserPoolId: userPoolId,
          Username: user_name,
        };

        cognito.adminDisableUser(params, function (err, data) {
          if (err) {
            console.log("Changing cognito error:");
            console.error(err, err.stack);
            // Handle error
            reject(err);
          } else {
            console.log(data);
            console.log('User status updated successfully');
            // User status updated successfully
            resolve(data);
          }
        });
    });
};

const enableUser = async (username) => {

    return new Promise((resolve, reject) => {
        
        const user_name = username;

        const params = {
          UserPoolId: userPoolId,
          Username: user_name,
        };

        cognito.adminEnableUser(params, function (err, data) {
          if (err) {
            console.log("Changing cognito error:");
            console.error(err, err.stack);
            // Handle error
            reject(err);
          } else {
            console.log(data);
            console.log('User status updated successfully');
            // User status updated successfully
            resolve(data);
          }
        });
    });
};

const adminSetUserPassword = async (username, newPassword) =>{
  // return new Promise((resolve, reject) => {
    try {
      const params = {
        UserPoolId: userPoolId,
        Username: username,
        Password: newPassword,
        Permanent: true, // Set to true if you want the password to be permanent
        // ClientMetadata: {
        //   client_id: clientId,
        // },
      };
  
      const data = await cognito.adminSetUserPassword(params).promise();
      console.log('Password set successfully:', data);
      return true; // Indicate success
    } catch (error) {
      console.error('Error setting user password:', error);
      return false; // Indicate failure
    }
  // });
}

const resetpassword = async (req, res) =>{
  try {
    const params = {
      ClientId: clientId, // Replace with your Cognito user pool client ID
      Username: req.body.email, // Replace with the username of the user
      ConfirmationCode: req.body.code, // Replace with the code entered by the user
      Password: req.body.password, // Replace with the new password
    };

    return new Promise((resolve, reject) => {
      cognito.confirmForgotPassword(params, function (err, data) {
        if (err) {
          console.log("cognito first erro")
          console.error(err);
          reject(err);
        } else {
          console.log('Password reset successful:', data);
          resolve(true);
        }
      });
    });

  } catch (error) {
      console.log(error);
      console.log("cognito erro ====");
      return false;
  }
}

const sendResetPasswordEmail = async (email) =>{
  try {
    const params = {
      ClientId: clientId, // Replace with your Cognito user pool client ID
      Username: email, // Replace with the username of the user
    };

    return new Promise((resolve, reject) => {
      cognito.forgotPassword(params, function (err, data) {
        if (err) {
          console.error(err);
          reject(err);
        } else {
          console.log('Reset code sent successfully:', data);
          resolve(true);
        }
      });
    });
  } catch (error) {
    console.log(error);
    console.log("cognito erro ====");
    return false;
  }
}




export {updateCognitoPassword,deleteImageFromURL,getImageDetailsFromURL,getLanguageName, getTranslation, formatTime, formatDatetime, convertToSlug, uploadFileToS3, getAllFilesFromS3, organizeIntoTree, signUpCognito, verifycode, disableUser, enableUser, adminSetUserPassword, resetpassword, sendResetPasswordEmail, signUpCognitoApp};
  

  