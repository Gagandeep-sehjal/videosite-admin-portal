
class librarycontroller{
static getpage = async(req, res) =>{
   

    res.render('library');
}
 static add_image= async(req,res)=>{

    res.render('add-library')
 }

}
export default librarycontroller;