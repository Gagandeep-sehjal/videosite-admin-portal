import mongoose from 'mongoose';


const LikesSchema = new mongoose.Schema({
    
    userId: String,
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    objectType: { 
        type: String, 
        enum: ['video', 'comment'], default: 'video' 
      },
      type: { 
        type: String, 
        enum: ['like', 'dislike'], default: 'like' 
      },
      objectId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
      },
});

// Create the Taxonomy model
const ToraLikesModel = mongoose.model('Tora_likes', LikesSchema);

export default ToraLikesModel;
