import mongoose from "mongoose";
import LanguageModel from "../models/Language.js";
import TaxonomyModel from "../models/Taxonomy.js";
import ToraFeaturesModel from "../models/ToraFeatures.js";
import ToraLog from "../models/ToraLog.js";
import ToraTermRelationModel from "../models/ToraTermRelation.js";
import ToraVideoModel from "../models/ToraVideo.js";
import UserModel from "../models/User.js";
import { getTranslation, formatTime, formatDatetime } from "../utils/utils.js";
import LanguageController from "./LanguageController.js";
import ToraTermRelation2Model from "../models/ToraTermRelation2.js";
import CountryModel from "../models/Country.js";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class VideosController{
    static add_videos = async (req, res) =>{
        const all_cookies = req.cookies;
        let message = req.session.message;
        delete req.session.message;
       
        const current_lang = all_cookies.current_lang || 'en';
        let user = await UserModel.findById(req.session.userId);
        const languages = await LanguageModel.find();
        const topics = await TaxonomyModel.find({type: 'topic',term_id: { $exists: true }});
        const series = await TaxonomyModel.find({ type: 'series',term_id: { $exists: true }});
        const organization = await TaxonomyModel.find({ type: 'organization',term_id: { $exists: true }});
        const author = await UserModel.find();
        const countries = await CountryModel.find();
        console.log(organization)
        res.render('add-videos', {countries,current_lang, user, languages, topics, series, organization, author,message, getTranslation});
    }

    static save_videos = async (req, res) =>{
        // res.send(req.body);
        try {
            let user = await UserModel.findById(req.session.userId);

            const {title, description, thumbnail, record_location, recorded_date, vimeo_id, video_source, audio_link, visible, short_video, video_field_id,status, topics, series, language, organization, author, hide_home_page ,upload_finish,video_audio_name,video_audio_source_name,likes,views,tab_numbers} = req.body;
            if(author == ""){
                req.session.message = 'Author field is required.';
                res.redirect("/portal/videos/add");
            }else{
            const video_doc = new ToraVideoModel({
                videoId:video_field_id,
                title:title,
                description:description,
                userId:author,
                slug:"",
                thumbnail:thumbnail,
                lang:language,
                recordLocation:record_location,
                recordedAt:recorded_date,
                vimeoId:vimeo_id,
                videoSource:video_source,
                audioLink:audio_link,
                visible:visible,
                status:status,
                shortVideo:short_video,
                hide_home_page:hide_home_page,
                link:link,
                upload_finish:upload_finish,
                video_audio_name:video_audio_name,
                video_audio_source_name:video_audio_source_name,
                likes:likes,
                views:views,
                tab_numbers:tab_numbers
            });

            if (status === "publish") {
                video_doc.publishedAt = new Date(); // Add the current date to publishedAt
            }

            const video =  await video_doc.save(video_doc);

            // res.send(video._id);
            console.log("topic add")
            console.log(topics)
            console.log(series)
            console.log(organization)
            
            if(video && video._id){
                if (topics && topics.length > 0) {
                    var topics_val = Array.isArray(topics) ? topics : [topics];
                    for (const topic of topics_val) {
                        const tora_temrm = new ToraTermRelation2Model({
                        objectType: 'video', // Replace with the appropriate user ID
                        objectId: video.videoId,
                        termId: topic,
                        termName: 'topic',
                        });
                        await tora_temrm.save();
                    }
                }
                if (series && series.length > 0) {
                    var series_val = Array.isArray(series) ? series : [series];

                    for (const serie of series_val) {
                        const tora_temrm = new ToraTermRelation2Model({
                        objectType: 'video', // Replace with the appropriate user ID
                        objectId: video.videoId,
                        termId:serie,
                        termName: 'series',
                        });
                        const savedToraTerms = await tora_temrm.save();
                        console.log("after add ser")
                        console.log(savedToraTerms)
                    }
                }
                if (organization && organization.length > 0) {
                    var organization_val = Array.isArray(organization) ? organization : [organization];

                    for (const organiza of organization_val) {
                        const tora_temrm = new ToraTermRelation2Model({
                        objectType: 'video', // Replace with the appropriate user ID
                        objectId: video.videoId,
                        termId: organiza,
                        termName: 'organization',
                        });
                        const yo=await tora_temrm.save();
                        console.log("after add org")
                        console.log(yo)
                    }
                }
            }

            req.session.message = 'Video Add successfully.';
            // res.send("data saved successfully");
            res.redirect('/portal/videos');
        }
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: error });   
        }       

    }

    static videos_list = async (req, res) =>{
        try {
            let message = req.session.message;
            delete req.session.message;
            const all_cookies = req.cookies;
            const current_lang = all_cookies.current_lang || 'en';
            let user = await UserModel.findById(req.session.userId);
            const author = await UserModel.find();
            const languages = await LanguageModel.find();
        
            const topics = await TaxonomyModel.find({ $and:[{ type: 'topic' }, {lang:'en'}]});
            const series = await TaxonomyModel.find({ type: 'series' });
            const organization = await TaxonomyModel.find({ type: 'organization' });
            const publishcount= await ToraVideoModel.countDocuments({status:"publish"});
            const allvideoscount = await ToraVideoModel.countDocuments({ status: { $ne: 'trash' },vimeoId: { $ne: "0" }  });
            const audiovideoscount = await ToraVideoModel.countDocuments({ status: { $ne: 'trash' },vimeoId:"0" });
            const pendingcount= await ToraVideoModel.countDocuments({status:"draft"});
            const trashcount= await ToraVideoModel.countDocuments({status:"trash"});
            const shortvideocount= await ToraVideoModel.countDocuments({status: { $ne: 'trash' },shortVideo:1 });
            const sizeCondition = {
                // $regex: /^\d+(\.\d+)?\s*GB$/i, // Matches patterns like 128.36MB, 304.8MB, 1.921GB
                $regex: /^[^1]\d*(\.\d+)?\s*GB$/i, // Matches patterns like 128.36MB, 304.8MB, 1.921GB
                // $gte: '2GB' // Greater than or equal to 2GB
            };

            const sizecount= await ToraVideoModel.countDocuments({status: { $ne: 'trash' }, size: sizeCondition });
            // const cat_parent = await LanguageController.topic_parent_test(req, res);
            const cat_parent = await TaxonomyModel.find({ type: 'topic', lang:'en' });
            // cat_parent.sort((a, b) => parseInt(a.key) - parseInt(b.key));

         
            // res.send(cat_parent);
            res.render('videos', {message, user, author, languages, topics, series, organization,current_lang, getTranslation, publishcount, pendingcount, trashcount, allvideoscount, cat_parent, audiovideoscount, shortvideocount, sizecount});
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: error });   
        }
    }

    static edit_videos = async (req, res) =>{
        try{
            const video = await ToraVideoModel.findById(req.params.id);
            const all_cookies = req.cookies;
            const current_lang = all_cookies.current_lang || 'en';
            let user = await UserModel.findById(req.session.userId);
            const languages = await LanguageModel.find();
            const topics = await TaxonomyModel.find({ type: 'topic' });
            const series = await TaxonomyModel.find({ type: 'series' });
            const organization = await TaxonomyModel.find({ type: 'organization' });

            // const topic_results = await ToraTermRelationModel.find({
            //     $and:[
            //         { termName: 'topic' },
            //         { objectId: req.params.id}   
            //     ]
            // }).select('termId');
            // const topicIds = topic_results.map(result => result.termId);

            const topic_results = await ToraTermRelation2Model.find({
                $and:[
                    { termName: 'topic' },
                    { objectId: video.videoId}   
                ]
            }).select('termId');
            const topicIds = topic_results.map(result => result.termId);
          console.log(topicIds)

            // const series_results = await ToraTermRelationModel.find({
            //     $and:[
            //         { termName: 'series' },
            //         { objectId: req.params.id}   
            //     ]
            // }).select('termId');
            // const seriesIds = series_results.map(result => result.termId);

            
            const series_results = await ToraTermRelation2Model.find({
                $and:[
                    { termName: 'series' },
                    { objectId: video.videoId}   
                ]
            }).select('termId');
            const seriesIds = series_results.map(result => result.termId);
           console.log(seriesIds)
            // const organizaiton_results = await ToraTermRelationModel.find({
            //     $and:[
            //         { termName: 'organization' },
            //         { objectId: req.params.id}   
            //     ]
            // }).select('termId');
            // const organizationIds = organizaiton_results.map(result => result.termId);

            const organizaiton_results = await ToraTermRelation2Model.find({
                $and:[
                    { termName: 'organization' },
                    { objectId: video.videoId}   
                ]
            }).select('termId');
            const organizationIds = organizaiton_results.map(result => result.termId);
             console.log(organizationIds);
             
            const author = await UserModel.find();

            // res.send("code isr jdklsj");

            const video_log = await ToraLog.aggregate([
                {
                  $match: {
                    $and: [
                      { entity: 'Video' },
                     { entityId: new mongoose.Types.ObjectId(req.params.id) }, // Assuming req.params.id is the ObjectId
                    ],
                  },
                },
                {
                  $lookup: {
                    from: 'tora_users', // Name of the tora_user collection
                    localField: 'user', // Field in ToraLog collection to match
                    foreignField: '_id', // Field in tora_user collection to match
                    as: 'userData', // Name for the merged user data field
                  },
                },
              ]);

            // const cat_parent = await LanguageController.topic_parent_test(req, res);
            const cat_parent = await TaxonomyModel.find({ type: 'topic', lang:'en' });
            const countries = await CountryModel.find();

            // res.send(topicIds)
            res.render('video-edit', {countries,video, current_lang, user, languages, topics, series, organization, getTranslation, topicIds, seriesIds, organizationIds, author, formatTime, video_log, formatDatetime, cat_parent});
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: error });   
        }     
    }

    

    static update_language = async (req, res) =>{
            const csvFilePath = join(__dirname, '..', 'public', 'assets', 'csv', 'video_with_size_4.csv');

             // Read and parse the CSV file
            const parser = csv.parse({ headers: true });

             // Handle the 'data' event
        parser.on('data', async (row) => {
            // Transform CSV data to match the MongoDB schema
            let lang = [];

            if(row.languages.trim().toLowerCase() == "español"){
              lang.push('es');
            }
            if(row.languages.trim().toLowerCase() == "english"){
              lang.push("en");
            }  
            if(row.languages == "עברית"){
              lang.push("he");
            }
            if(row.languages == "אידיש"){
              lang.push("yi");
            }
            if(row.languages.trim().toLowerCase() == "portuguese"){
              lang.push("pt");
            }
  
  
            const video_data = {
                lang:lang.slice()
            }
            

            const result = await ToraVideoModel.updateOne({ videoId: row.video_id }, video_data);
            // await ToraVideoModel.create(video_data);
        });

        // Handle the 'end' event
        const endPromise = once(parser, 'end');

        fs.createReadStream(csvFilePath)
            .pipe(parser);
    
        try {
            await endPromise; // Wait for the 'end' event to complete
            console.log('CSV file successfully processed.');
            res.send("updated");
        } catch (error) {
            console.error('Error processing CSV file:', error);
            res.status(500).send('Internal Server Error');
        }
    }

  

    
}

export default VideosController;















