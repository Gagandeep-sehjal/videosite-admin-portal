import mongoose from 'mongoose';
import TaxonomyModel from "../../models/Taxonomy.js";
import ToraFeaturesModel from '../../models/ToraFeatures.js';
import { getLanguageName, convertToSlug, uploadFileToS3 ,organizeIntoTree} from '../../utils/utils.js';
import path from 'path';
import UserModel from '../../models/User.js';
import ToraLog from '../../models/ToraLog.js';
import ToraTermRelation2Model from '../../models/ToraTermRelation2.js';
import ToraVideoModel from '../../models/ToraVideo.js';
class TopicApiController{
    static get_home_topics = async (req, res) =>{
        try {
            const pageNumber = req.query.page;
            const pageSize = 5; // Specify the number of documents per page

            const skipCount = (pageNumber - 1) * pageSize;

            // Query to retrieve data for the current page
            // const series = await SeriesModel.find()
            var current_lang;
            if(req.query.current_lang == "es" || req.query.current_lang == "he" || req.query.current_lang == "yi"){
              current_lang = req.query.current_lang;
            }else{
              current_lang = 'en';
            }

            const topics = await TaxonomyModel.find({ $and: [
              {type: 'topic'},
              {lang: 'en'}
            ] })
            .skip(skipCount) // Skip the initial documents
            .limit(pageSize); // Limit the number of documents returned

            // Total number of documents (for calculating total pages, etc.)
            const totalDocuments = await TaxonomyModel.countDocuments({ $and: [{ type: 'topic' }, {lang: 'en'}] });

            // Calculate total pages based on the total number of documents and page size
            const totalPages = Math.ceil(totalDocuments / pageSize);
            
            // Send the data as JSON
            res.status(200).json({ status: "success", data: topics, totalPages: totalPages });
          } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
          }
    }

    static create_topics = async (req, res) =>{
      try {
        const {name, parentTopic, description, position, language, spanish, hebrew, yiddish, thumbnail} = req.body;
        let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
        if(parentTopic == ""){
          const findtopic = await TaxonomyModel.findOne({title:name});
          if(findtopic){
            return res.status(500).json({ error: 'Topic already exists' });
          }else{
            const highestTermIdDocument = await TaxonomyModel.findOne().sort({ term_id: -1 });
            let highestTermId = 0;
            if (highestTermIdDocument && highestTermIdDocument.term_id) {
            highestTermId = highestTermIdDocument.term_id;
            }

            var topic_id = new mongoose.Types.ObjectId();
              const topic_doc = new TaxonomyModel({
                  _id:topic_id,
                  title:name,
                  slug:slug,
                  // parentId:parentTopic, 
                  description:description, 
                  type:'topic',
                  order:position, 
                  lang:language, 
                  translations: [
                    { languageCode: 'en', languageName:"english", translation: name },
                    { languageCode: 'es', languageName:"spanish", translation: spanish },
                    { languageCode: 'he', languageName:"hebrew", translation: hebrew },
                    { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
                  ],
                  relationlId:topic_id,
                  userId: "65118a686cd915d6963a6354",
                  status:'publish',
                  // Add the image file details to the model
                  thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
                  term_id:highestTermId + 1,
              });

              if (parentTopic) {
                topic_doc.parent_id = parentTopic;
              }

              const result = await topic_doc.save();
              console.log(result)
              // Return the saved series data as a response
              res.status(201).json({ status: 'success', data: result });
          }
        }
        else{
          // res.send({"status":"failed", "message":"You selected the topic"});
          const findparenttopic = await TaxonomyModel.findOne({parent_id:parentTopic,title:name});
          if(findparenttopic){
            return res.status(500).json({ error: 'Topic already exists in this parent' });
          }else{
            let slug = convertToSlug(name);
            let parentdata = await TaxonomyModel.findOne({_id:parentTopic});
            let parent_slug = parentdata.slug;
            slug = parent_slug+"-"+slug;
            const highestTermIdDocument = await TaxonomyModel.findOne().sort({ term_id: -1 });
            let highestTermId = 0;
            if (highestTermIdDocument && highestTermIdDocument.term_id) {
            highestTermId = highestTermIdDocument.term_id;
            }
            var topic_id = new mongoose.Types.ObjectId();
              const topic_doc = new TaxonomyModel({
                  _id:topic_id,
                  title:name,
                  slug:slug,
                  // parentId:parentTopic, 
                  description:description, 
                  type:'topic',
                  order:position, 
                  lang:language, 
                  translations: [
                    { languageCode: 'en', languageName:"english", translation: name },
                    { languageCode: 'es', languageName:"spanish", translation: spanish },
                    { languageCode: 'he', languageName:"hebrew", translation: hebrew },
                    { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
                  ],
                  relationlId:topic_id,
                  userId: "65118a686cd915d6963a6354",
                  status:'publish',
                  // Add the image file details to the model
                  thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
                  term_id:highestTermId + 1,

              });

              if (parentTopic) {
                topic_doc.parent_id = parentTopic;
              }

              const result = await topic_doc.save();
              console.log(result)
              // Return the saved series data as a response
              res.status(201).json({ status: 'success', data: parentdata });
          }
        }


        
        }
      catch (error) {
        if(error && error.code=== 11000){
          console.error('Error:name must be unique');
       
          return res.status(500).json({ error: 'Name already taken' });
        }else{
          console.log(error);
          // return res.status(500).json({ error: 'Failed to create a new series.' });
          return res.status(500).json({ error: error });
        }
      }
    }

    static view_single_topic = async (req, res)=>{
      try{
        const result = await TaxonomyModel.findById(req.params.id);
        console.log(result);
        res.status(200).json({ status: "success", data: result });
      }  catch (error) {
        console.error('Error fetching topic data:', error);
      }
    }

    static update_topic = async (req, res) =>{
      try {
        const {name,  parentTopic, description, position, language, spanish, hebrew, yiddish, thumbnail, visible} = req.body;
        console.log(req.body)
        let user = await UserModel.findById(req.session.userId);
        let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }

        if(parentTopic == ""){
          // const findtopic = await TaxonomyModel.findOne({title:name});
          // if(findtopic){
          //   return res.status(500).json({ error: 'Topic already exists' });
          // }else{
            let topic_old_detail = await TaxonomyModel.findById(req.params.id);
              // title change log
            if(topic_old_detail.title != name){
              const log_doc = new ToraLog({
                                  event:"Name Changed",
                                  entity:"Topic",
                                  entityId: req.params.id,
                                  user:user._id,
                                  changes:{field:"name",oldValue:topic_old_detail.title, newValue:name}
                              });
              const logsave = await log_doc.save();
            }

            // Get the uploaded file from the request
            const file = req.file;

            var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
            }

            const topic_doc = {
              title:name,
              slug:slug,
              // parentId:parentTopic, 
              description:description, 
              translations: [
                { languageCode: 'en', languageName:"english", translation: name },
                { languageCode: 'es', languageName:"spanish", translation: spanish },
                { languageCode: 'he', languageName:"hebrew", translation: hebrew },
                { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
              ],
              order:position, 
              lang:language, 
              status:'publish',
              // Add the image file details to the model
              thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
              visible:visible
            };

            if (parentTopic) {
              topic_doc.parent_id = parentTopic;
              topic_doc.parent = parentTopic;
            }else{
              topic_doc.parent_id = null;
            }

            const result = await TaxonomyModel.findByIdAndUpdate(req.params.id, topic_doc);

            res.status(201).json({ status: 'success', data: result });

          // }
        }else{
          // const findparenttopic = await TaxonomyModel.findOne({parentId:parentTopic,title:name});
          // if(findparenttopic){
          //   return res.status(500).json({ error: 'Topic already exists in this parent' });
          // }else{
            let topic_old_detail = await TaxonomyModel.findById(req.params.id);
              // title change log
            if(topic_old_detail.title != name){
              const log_doc = new ToraLog({
                                  event:"Name Changed",
                                  entity:"Topic",
                                  entityId: req.params.id,
                                  user:user._id,
                                  changes:{field:"name",oldValue:topic_old_detail.title, newValue:name}
                              });
              const logsave = await log_doc.save();
            }

            // Get the uploaded file from the request
            const file = req.file;

            var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
            }

            const topic_doc = {
              title:name,
              slug:slug,
              // parentId:parentTopic, 
              description:description, 
              translations: [
                { languageCode: 'en', languageName:"english", translation: name },
                { languageCode: 'es', languageName:"spanish", translation: spanish },
                { languageCode: 'he', languageName:"hebrew", translation: hebrew },
                { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
              ],
              order:position, 
              lang:language, 
              status:'publish',
              // Add the image file details to the model
              thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
              visible:visible
            };

            if (parentTopic) {
              topic_doc.parent_id = parentTopic;
              topic_doc.parent = parentTopic;
            }else{
              topic_doc.parent_id = null;
            }

            const result = await TaxonomyModel.findByIdAndUpdate(req.params.id, topic_doc);

            res.status(201).json({ status: 'success', data: result });
          // }
        }


        
      } catch (error) {
        if(error && error.code=== 11000){
       
          return res.status(500).json({ error: 'Name already taken' });
        }else{
          // return res.status(500).json({ error: 'Failed to create a new series.' });
          console.log("update category error");
          console.log(error);

          return res.status(500).json({ error: error });
        }
      }
    }

    static delete_topic = async (req, res) =>{
      try {
        const result = await TaxonomyModel.findByIdAndRemove(req.params.id);
        res.status(201).json({ status: 'success', data: result });
      } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Failed to delete series.' });
      }
      
    }

    static translate_topic = async (req, res) =>{
     /* console.log(req.body);
      const {topic_id, translate_text, lang_code} = req.body;  
      const result = await TaxonomyModel.findOneAndUpdate(
       {
         $and: [
           { relationlId: topic_id },
           { lang: lang_code },
           { type: 'topic' }
         ]
       },
       {
         $set: { title: translate_text }
       },
       { new: true } // This option returns the updated document
     );

     console.log("=== result ====");
     console.log(result);

     if(result){
       res.status(201).json({ status: 'success', data: result });
     }else{
         const eng_result = await TaxonomyModel.findById(topic_id);
         console.log(eng_result);

         const topic_doc = new TaxonomyModel({
           title:translate_text,
           slug: eng_result.slug,
           // parentId:parentSeries, 
           description:eng_result.description, 
           type:'topic',
           order:eng_result.position, 
           lang:lang_code, 
           relationlId:eng_result._id,
           userId: "65118a686cd915d6963a6354",
           status:'publish',
           // Add the image file details to the model
           thumbnail: eng_result.thumbnail, // Assuming 'file.path' contains the path to the uploaded image
       });

       const new_result = await topic_doc.save();

       res.status(201).json({ status: 'success', data: new_result }); 
       console.log("=== english data =====");
     } */

    //  res.send(req.body);

     try {
        const {topic_id, translate_text, lang_code} = req.body;
        var result = await TaxonomyModel.findOneAndUpdate(
          {
            _id: topic_id,
            type: 'topic',
            'translations.languageCode': lang_code // Match documents with the desired language code
          },
          {
            $set: {
              'translations.$.translation': translate_text // Update the translation field for the matched language
            }
          },
          { new: true } // This option returns the updated document
        );

        if (!result) {
          // If no matching document is found, create a new translation
          const language_name = getLanguageName(lang_code); // Refactor this part for better readability
      
          result = await TaxonomyModel.findOneAndUpdate(
            {
              _id: topic_id,
              type: 'topic',
            },
            {
              $push: {
                translations: {
                  languageCode: lang_code,
                  languageName: language_name,
                  translation: translate_text,
                },
              },
            },
            { new: true }
          );
        }

        res.status(201).json({ status: 'success', data: result });
      } catch (error) {
          console.log(error);
          return res.status(500).json({ error: 'Unable to update topic.' });
      }
    }

    // static category_home_slider = async(req, res) =>{
    //   const lang = req.params.lang; // Access the language code from req.params.lang
    //   res.json({ key: lang });
    //   // res.send(req);

    // }

    static category_home_slider = async(req, res) =>{

      try {

      var current_lang = req.params.lang || 'en';

      const results = await ToraFeaturesModel.aggregate([
        {
          $match: {
            'taxonomy_name': 'category_slider',
          },
        },
        {
          $lookup: {
            from: 'tora_taxonomies',
            localField: 'taxonomy_id',
            foreignField: '_id',
            as: 'taxonomyData',
          },
        },
        {
          $unwind: '$taxonomyData',
        },
        {
          $lookup: {
            from: 'tora_term_relations',
            localField: 'taxonomy_id',
            foreignField: 'termId',
            as: 'termRelations',
          },
        },
        {
          $unwind: '$termRelations',
        },
        {
          $lookup: {
            from: 'tora_videos',
            localField: 'termRelations.objectId',
            foreignField: '_id',
            as: 'videos',
          },
        },
        {
          $unwind: '$videos',
        },
        {
          $lookup: {
            from: 'tora_users',
            localField: 'videos.userId',
            foreignField: '_id',
            as: 'users',
          },
        },
        {
          $unwind: '$videos',
        },
        {
          $group: {
            _id: '$_id',
            taxonomyData: { $first: '$taxonomyData.translations' },
            termRelations: { $push: '$termRelations' },
            // videosdd: { $push: '$videos' },
            // users:{ $push: '$users' },
            videos: {
              $push: {
                // video_detial:'$videos',
                  _id: '$videos._id',
                  title: '$videos.title',
                  description: '$videos.description',
                  thumbnail: '$videos.thumbnail',
                  recordLocation: '$videos.recordLocation',
                  recordedAt: '$videos.recordedAt',
                  vimeoId: '$videos.vimeoId',
                  shortVideo: '$videos.shortVideo',
                  videoSource: '$videos.videoSource',
                  audioLink: '$videos.audioLink',
                  visible: '$videos.visible',
                  status: '$videos.status',
                  publishDate:'$videos.publishedAt',
                  lang:'$videos.lang',
                  hebrew_recorded_date:'$videos.hebrew_recorded_date',
                  user_thumbnail:{$first:'$users.thumbnail'},
                  // Include user data in the video object
                  user_first_name: {$first:'$users.firstName'},
                  user_last_name: {$first:'$users.lastName'},
                  category_name:{$first:'$taxonomyData.translations.translation'}
                  // user_first_name: { $arrayElemAt: ['$users.firstName', 0] },
                  // user_last_name: { $arrayElemAt: ['$users.lastName', 0] },
                  // category_name:{ $arrayElemAt: ['$taxonomyData.translations.translation', 0] }
                  // Add other video fields here as needed
              },
          },
          },
        },
        {
          $project: {
            termRelations: 0, // Exclude the termRelations array from the result
          },
        },
        {
          $addFields: {
            'taxonomyData': {
              $filter: {
                input: '$taxonomyData',
                as: 'translation',
                cond: { $eq: ['$$translation.languageCode', current_lang] },
              },
            },
          },
        },
        {
          $addFields: {
              'translated_title': { $arrayElemAt: ['$taxonomyData.translation', 0] }
          },
      },
      ]);

          res.send(results);
        } catch (error) {
          console.log(error);
          res.status(500).json({ status: "error", message: error });
        }
    }

    static delete_topic_lang = async (req, res) =>{
      // res.send(req.body.lang_code);
      try {
        const result = await TaxonomyModel.updateOne(
          { _id: req.params.id },
          {
            $pull: {
              translations: { languageCode: req.body.lang_code }
            }
          }
        );

        console.log(result);
      
        if (result.nModified === 0) {
          // Handle the case where no documents were modified (language code not found)
          return res.status(404).json({ error: 'Translation not found' });
        }
      
        console.log('Translation removed successfully');
        return res.status(201).json({ status: 'success' });
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Failed to delete translation.' });
      }
    }

    static home_topics = async (req, res) =>{

      try {
              var current_lang = req.params.lang || 'en';
              
              const results = await ToraFeaturesModel.aggregate([
                {
                  $match: {
                    'taxonomy_name': 'topic',
                  },
                },
                {
                  $lookup: {
                    from: 'tora_taxonomies',
                    let: { taxonomyId: '$taxonomy_id' },
                    pipeline: [
                      {
                        $match: {
                          $expr: {
                            $and: [
                              { $eq: ['$_id', '$$taxonomyId'] }, // Match the taxonomy_id field
                              { $eq: ['$status', 'publish'] }   // Match the status field
                              // { $eq: ['$translations'] }   // Match the status field
                            ]
                          }
                        }
                      }
                    ],
                    as: 'taxonomyData',
                  },
                },
                {
                  $unwind: '$taxonomyData',
                },
                {
                  $lookup: {
                    from: 'tora_term_relations',
                    localField: 'taxonomy_id',
                    foreignField: 'termId',
                    as: 'termRelations',
                  },
                },
                {
                  $unwind: '$termRelations',
                },
                {
                  $lookup: {
                    from: 'tora_videos',
                    localField: 'termRelations.objectId',
                    foreignField: '_id',
                    as: 'videos',
                  },
                },
                {
                  $unwind: '$videos',
                },
                {
                  $group: {
                    _id: '$_id',
                    taxonomyName: { $first: '$taxonomyData.translations' },
                    taxonomy: { $first: '$taxonomyData' },
                    termRelations: { $push: '$termRelations' },
                    videos: { $push: '$videos' },
                    users: { $push: '$videos.userId' },
                  },
                },
                {
                  $addFields: {
                    'taxonomyName': {
                      $filter: {
                        input: '$taxonomyName',
                        as: 'translation',
                        cond: { $eq: ['$$translation.languageCode', current_lang] },
                      },
                    },
                  'videoCount': { $size: '$videos' }, // Add a field 'videoCount' with the size of 'videos' array
                  'uniqueUserCount': {
                      $size: {
                        $setUnion: '$users' // Count unique user IDs using $setUnion
                      }
                    },
                  },
                  // 'traslated_title':$taxonomyName
                },
                {
                  $addFields: {
                      'translated_title': { $arrayElemAt: ['$taxonomyName.translation', 0] }
                  },
              },
                {
                  $project: {
                    termRelations: 0, // Exclude the termRelations array from the result
                    videos:0,
                    _id: 0,
                    users:0,
                  },
                },
              ]);
          
              res.send(results);
        } catch (error) {
          res.status(500).json({ status: "error", message: error });
        }
    }

    static bulk_trash = async (req, res) =>{
      try{

        var ids = req.body;
        if (ids && Array.isArray(ids)) {
          for (const id of ids) {
            // const result = await TaxonomyModel.findByIdAndRemove(id);
            const result = await TaxonomyModel.findByIdAndUpdate(id,{ status: 'trash' });
          }
          res.status(201).json({ status: 'success' });
        }else {
          res.status(400).json({ error: 'Invalid request data.' });
        }
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Failed to update video.' });
      }
    }


    static bulk_delete = async (req, res) => {
      try {
        var ids = req.body;
    
        if (ids && Array.isArray(ids)) {
          // Use deleteMany to delete multiple documents
          const result = await TaxonomyModel.deleteMany({ _id: { $in: ids } });
    
          if (result.deletedCount > 0) {
            res.status(201).json({ status: 'success' });
          } else {
            res.status(404).json({ error: 'No matching documents found.' });
          }
        } else {
          res.status(400).json({ error: 'Invalid request data.' });
        }
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Failed to delete documents.' });
      }
    };
    

    static bulk_restore = async (req, res) =>{
      try{

        var ids = req.body;
        if (ids && Array.isArray(ids)) {
          for (const id of ids) {
            // const result = await TaxonomyModel.findByIdAndRemove(id);
            const result = await TaxonomyModel.findByIdAndUpdate(id,{ status: 'publish' });
          }
          res.status(201).json({ status: 'success' });
        }else {
          res.status(400).json({ error: 'Invalid request data.' });
        }
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Failed to update video.' });
      }
    }

    static quick_edit_category = async (req, res)=>{
      // res.send(req.body);
      try {
        const {cat_id, name, slug, thumbnail} = req.body;

        let user = await UserModel.findById(req.session.userId);
        let topic_old_detail = await TaxonomyModel.findById(cat_id);

        // res.send(topic_old_detail);
        // title change log
        if(topic_old_detail.title != name){
          const log_doc = new ToraLog({
                              event:"Name Changed",
                              entity:"Series",
                              entityId: cat_id,
                              user:user._id,
                              changes:{field:"name",oldValue:topic_old_detail.title, newValue:name}
                          });
          const logsave = await log_doc.save();
        }

        const cat_doc = {
          title: name, // Update the title field
          slug: slug,  // Update the slug field
        };
        
        const result = await TaxonomyModel.updateOne(
          { _id: cat_id, 'translations.languageCode': { $in: ['en'] } },
          {
            $set: {
              title: name,
              slug: slug,
              thumbnail:thumbnail,
              'translations.$.translation': name, // Update the 'translation' field for the matching languageCode
            },
          }
        );
        

          res.status(201).json({ status: 'success', data: result });
        } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
        }
    }

    static change_status = async (req, res) =>{
      try {
        var id = req.params.id;
        const updateFields = {
            status:'trash',
        };
        
          const result = await TaxonomyModel.findByIdAndUpdate(id, updateFields);
          res.status(201).json({ status: 'success' });
      } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
      }
    }

    static restore_topic = async (req, res) =>{
      try {
        var id = req.params.id;
        const updateFields = {
            status:'publish',
        };
        
        const result = await TaxonomyModel.findByIdAndUpdate(id, updateFields);
        res.status(201).json({ status: 'success' });
      } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update video.' });
      }
    }
    
    static all_topic = async (req, res) =>{
      var current_lang = req.params.lang || 'en';
      const page = req.query.pageno;
      const pageSize = parseInt(req.query.pagesize) || 10;

      try {
        const results = await TaxonomyModel.aggregate([
            {
              $match: {
                'type': 'topic',
                'parent_id': { $in: [null, 0]},
            }
          },
           
            {
              $lookup: {
                from: 'tora_term_relations2',
                localField: 'term_id',
                foreignField: 'termId',
                as: 'termRelations',
              },
            },
            {
              $unwind: '$termRelations',
            },
            {
              $lookup: {
                from: 'tora_videos',
                localField: 'termRelations.objectId',
                foreignField: 'videoId',
                as: 'videos',
              },
            },
            {
              $unwind: '$videos',
            },

            {
              $group: {
                _id: '$_id',
                title: { $first: '$title' },
                translations: {
                  $first: '$translations' 
              },
                videos: { $push: '$videos' },
                users: { $push: '$videos.user_id' },
              },
            },
            {
              $addFields: {
                
               'videoCount': { $size: '$videos' }, // Add a field 'videoCount' with the size of 'videos' array
               'uniqueUsers': {
                
                  $setUnion: '$users' // Count unique user IDs using $setUnion
                
              }
              },
            },
            {
              $lookup: {
                  from: 'tora_users', 
                  localField: 'uniqueUsers',
                  foreignField: 'user_id',
                  as: 'user_info',
              },
              },
              {
                $addFields: {
                    user_info: {
                        $filter: {
                            input: '$user_info',
                            as: 'filtercat',
                            cond: {
                              $and: [
                                  { $eq: ['$$filtercat.role', 'speaker'] }, 
                                  { $eq: ['$$filtercat.status', 'active'] }  
                              ]
                          }
                        }
                    }
                }
            },
            {
              $addFields: {
                
               'SpeakerCount': { $size: '$user_info' }, 
              
              }
              },
            
          {
              $project: {
              _id: 1,
              title:1,
              translations: {
                $filter: {
                input: '$translations',
                as: 'translation',
                cond: { $eq: ['$$translation.languageCode', current_lang] },
                },
            },
            term_id:1,
            parent_id:1,
            parentId:1,

              // videos:1,
               videoCount:1,
              //  uniqueUsers:1,
              
              // user_info:{
              //   role:1,
              // },
              SpeakerCount:1,
           }
          },
          {
            $skip: (page - 1) * pageSize,
        },
        {
            $limit: pageSize,
        },
        
          ]);



        res.send(results);

      } catch (error) {
        console.error('Error:', error);
            res.status(500).send('Internal Server Error');
      }
      
      
    }

    static all_topics = async (req, res)=>{
      let parentdata = await TaxonomyModel.aggregate([
          {
              $match: {
                'type': 'topic',
                'lang':'en'
              },
          },
          {
            $lookup: {
              from: 'tora_term_relations2',
              localField: 'term_id',
              foreignField: 'termId',
              as: 'termRelations',
            },
          },
          {
            $unwind: '$termRelations',
          },
          {
            $lookup: {
              from: 'tora_videos',
              localField: 'termRelations.objectId',
              foreignField: 'videoId',
              as: 'videos',
            },
          },
          {
            $unwind: '$videos',
          },
      ]);

      const treeStructure = organizeIntoTree(parentdata);
      let idtitle = Object.entries(treeStructure).map(([key, value]) => {
        let allVideos = [];
      
        function collectVideos(node) {
          if (node.videos) {
            allVideos.push(node.videos.title);
          }
      
          if (node.children) {
            node.children.forEach(child => collectVideos(child));
            
          }
        }
      
        collectVideos(value);
      
        return {
          key: key,
          _id: value.term_id,
          title: value.title,
          videos: allVideos,
          children: value.children
            ? value.children.map(child => ({
                key: child.term_id,
                _id: child.term_id,
                title: child.title,
                videos: child.videos
        }))
            : [],
        };
      });

        let topic = await TaxonomyModel.find({
          $and: [
            { type: 'topic' },
            { lang: 'en' }
          ]
        });

        async function getNestedChildren(nodeId) {
          // const node = await TaxonomyModel.findOne({ _id: nodeId, type: 'topic', lang: 'en' });
          const node = await TaxonomyModel.findOne({ term_id: nodeId, type: 'topic', lang: 'en' });
          if (!node) {
            return null;
          }
        
          // const children = await TaxonomyModel.find({ parentId: nodeId, type: 'topic', lang: 'en' });
          const children = await TaxonomyModel.find({ parent_id: nodeId, type: 'topic', lang: 'en' });
          const nestedChildrenPromises = children.map(child => getNestedChildren(child.term_id));
          const nestedChildren = await Promise.all(nestedChildrenPromises);
        
          return {
            node,
            children: nestedChildren.filter(Boolean),
          };
        }
        
        // Assuming you want to start from the root nodes (nodes with null parentId)
        // const rootNodes = await TaxonomyModel.find({ parentId: null, type: 'topic', lang: 'en' });
        const rootNodes = await TaxonomyModel.find({ parent_id: 0, type: 'topic', lang: 'en' });
        const hierarchyPromises = rootNodes.map(rootNode => getNestedChildren(rootNode.term_id));
        const filteredHierarchy = await Promise.all(hierarchyPromises);
      // ... (previous code)

// Fetch videos associated with topics using lookup

        // return idtitle;
      res.send(idtitle);
      // res.send(hierarchy);

      
  }

  static child_topic = async (req, res) => {
    const topic_id = req.params.id;
        const results = await TaxonomyModel.aggregate([
            {
                $match: {'term_id': topic_id} 
            },
            {
                $project: {
                    _id: 1,
                    title: 1,
                }
            }
        ]);
        let result = await TaxonomyModel.find({
          term_id: topic_id,
        });
        console.log(result)
        console.log(results);

        res.send(results);

};


}

export default TopicApiController;
