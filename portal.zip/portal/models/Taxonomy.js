import mongoose from 'mongoose';

const translationSchema = new mongoose.Schema({
    languageCode: {
      type: String,
      required: true
    },
    languageName: {
      type: String,
      required: true
    },
    translation: {
      type: String,
    },
  });
  
// Define the Taxonomy schema
const taxonomySchema = new mongoose.Schema({
    term_id: Number,
    title: {
        type: String,
        required: true,
    },
    slug:String,
    description: String,
    thumbnail: String,
    type: {
        type: String,
        enum: ['topic', 'series', 'organization', 'dedicationMonth','category_slider'],
        required: true
    },
    parentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'TaxonomyModel' // Reference to the same model for parent-child relationships
    },
    parent_id: Number,
    order: Number,
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        // required: true
    },
    lang: String,
    translations: [translationSchema], 
    status: {
        type: String,
        enum: ['draft', 'publish', 'trash'],
        default: 'draft'
    },
    details: {
        type: mongoose.Schema.Types.Mixed // Storing JSON data as a mixed type
    },
    visible: {
        type: String,
        enum: ['mobile', 'desktop', 'both', 'none'],
    },
    // path:String,
    // level:Number,
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
});

// Create the Taxonomy model
const TaxonomyModel = mongoose.model('tora_taxonomy', taxonomySchema);

export default TaxonomyModel;
