// middleware.js

const setLanguage = (req, res, next) => {
    req.current_lang = req.params.lang || 'en';
    next();
  };
  
export default setLanguage;
  