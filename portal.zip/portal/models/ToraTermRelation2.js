import mongoose from 'mongoose';

// Define the schema
const toraTermRelation2Schema = new mongoose.Schema({
  objectType: {
    type: String,
    enum: ['video', 'dedicationMonth'],
    required: true,
  },
  objectId: {
    type: Number,
    required: true,
  },
  termId: {
    type: Number,
    required: true,
  },
  termName: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: Date,
});

// Create the model
const ToraTermRelation2Model = mongoose.model('tora_term_relations2', toraTermRelation2Schema);

export default ToraTermRelation2Model;