import UserModel from "../../models/User.js"
import bcrypt from 'bcrypt';
import path from 'path';
// import { signUpCognito, verifycode,updateCognitoPassword  } from "../../utils/utils.js";
import nodemailer from 'nodemailer';
import jwt from 'jsonwebtoken';
const JWT_SECRET =
  "";
import AmazonCognitoIdentity from 'amazon-cognito-identity-js';
import { signUpCognito, verifycode,updateCognitoPassword, disableUser, enableUser, adminSetUserPassword, signUpCognitoApp } from "../../utils/utils.js";
import mongoose from "mongoose";


// const poolData = {
//   UserPoolId: 'your_id',
//   ClientId: 'your_id',
// };


// const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  
class UserApiController{
    static userRegistrationApp = async (req, res) => {
        try {
            const {first_name, last_name, email, password, language, gender} = req.body;

            let signUpResult = await signUpCognitoApp(req, res);

            console.log("signupresult data");
            console.log(signUpResult);

            let response = {
                username:signUpResult.user.username,
                id:signUpResult.userSub,
                success:true
            }

            if(response.username){
                const user = await UserModel.findOne({email:email});
                if(user){
                    res.send({"status":"failed", "message":"Email already exists"});
                }else{
                    if(first_name && last_name && email && password && gender){
                            try {
                                const salt = await bcrypt.genSalt(10);
                                const hashPassword = await bcrypt.hash(password, salt);
                                // Find the highest user_id
                                const highestUserIdDoc = await UserModel.findOne({}, { user_id: 1 }).sort({ user_id: -1 });
                                // Calculate the new user_id
                                let newUserId = 1; // Default value if no users are present
                                if (highestUserIdDoc) {
                                    newUserId = highestUserIdDoc.user_id + 1;
                                }
                                const doc = new UserModel({
                                    user_id: newUserId,
                                    firstName:first_name,
                                    lastName:last_name,
                                    email:email, 
                                    password:hashPassword, 
                                    // preferredLang:language,
                                    // Lang_code:[language],
                                    gender:gender,
                                    role:'user',
                                });

                                if(language){
                                    doc.Lang_code = [language];
                                }
                                await doc.save();
                                const saved_user = await UserModel.findOne({email:email});
                                // Generate JWT Token 
                                const token = jwt.sign({userId: saved_user._id}, process.env.JWT_SECERT_KEY, {expiresIn: '5d'})
                                res.status(201).send({"status":"success", "message": "Register successfully. code send to user email address for verify email purpose.", "response": response})
                            } catch (error) {
                                console.log(error);
                                console.log("unable register error =====");
                                res.send({"status":"failed", "message": "Unable to register."});
                            }
                    
                    }else{
                        res.send({"status":"failed", "message": "All feilds are required."})
                    }
                }

            }
        } catch (error) {
            console.log(error)
            console.log("user registration error ====")
            res.send({"status":"failed", "message": "Internal server error."}) 
        }
    }

    static userLoginApp = async (req, res) => {
        try {
                const {email, password} = req.body;
                const authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
                    Username: email,
                    Password: password
                });
                const userData = {
                    Username: email,
                    Pool: userPool
                };

                const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
                cognitoUser.authenticateUser(authenticationDetails, {
                    onSuccess: async (resultdata) =>{
                        let accessToken = resultdata.getAccessToken().getJwtToken();
                        let idToken = resultdata.getIdToken().getJwtToken();
                        let refreshToken = resultdata.getRefreshToken().getToken()
                        const decoded = jwt.decode(accessToken, { complete: true });
                        const iddecode = jwt.decode(idToken, { complete: true });
                        const refreashdecode = jwt.decode(refreshToken, { complete: true });
                        let cognito_email;
                        let cognito_name;
                        if(iddecode && iddecode.payload){
                          cognito_email = iddecode.payload.email;
                          cognito_name = iddecode.payload.name;
                        }

                        if(cognito_email){
                          let result = await UserModel.findOne({email:cognito_email});
                            if(result != null && result.status != "reset_required"){
                                const isMatch = await bcrypt.compare(password, result.password);
                                if(result.email == email && isMatch){
                                    // console.log("you are in ---");
                                    // Generate JWT Token 
                                    const token = jwt.sign({userId: result._id}, process.env.JWT_SECERT_KEY, {expiresIn: '5d'})
                                    const user_info = {username:result.email, language:result.Lang_code, gender:result.gender }
                                    // res.status(201).send({"status":"success", "message": "Login successfully.", "token": token});
                                    res.status(201).send({"status":"success", "message": "Login successfully.", "idToken": idToken, "accessToken":accessToken, "refreashdecode": refreshToken, "user_info":user_info });
                                }else{
                                    res.status(201).send({"status":"failed", "message": "Email or Password not valid."});
                                }
                            }
                            else if(result.status == "reset_required"){
                                res.status(201).send({"status":"failed", "message": "Your password is reset. Reset code is sent to your email address."});
                            }
                            else{
                                res.status(201).send({"status":"failed", "message": "You are not register user."});
                            }
                        }else{
                          res.status(201).send({"status":"failed", "message": "You are not authenticate user."});
                        }
                      },
                    onFailure: err => {
                        console.log(err);
                        console.log("check failed error ===");
                        // console.log(err.name)
                        if(err.name == "NotAuthorizedException"){
                            res.status(201).send({"status":"failed", "message": "You are not a registered user."});
                        }
                        else if(err.name == "PasswordResetRequiredException"){
                            res.status(201).send({"status":"failed", "message": "Password reset required."});
                        }
                        else{
                            res.status(201).send({"status":"failed", "message": "Unable to logged in"});
                        }
                    },
        
                  });

            } catch (error) {
                console.log(error);
                console.log("cognito login error");
                res.send({"status":"failed", "message": "Internal Server Error."})
            }
        }


    static get_users = async(req, res) =>{
        // res.send("you are on user route =====");
        try {
            const pageNumber = req.query.page;
            const pageSize =  parseInt(req.query.page_size, 10); // Specify the number of documents per page
            // const pageSize =  2; // Specify the number of documents per page
            const role = req.query.role;
            const account_status = req.query.acc_status;
            const queryparam = req.query.search;

            const skipCount = (pageNumber - 1) * pageSize;

            // const users = await UserModel.find().skip(skipCount) // Skip the initial documents
            // .limit(pageSize);

            const userPipeline = [
                {
                    $lookup:{
                        from:'tora_languages',
                        // localField:'preferredLang',
                        localField:'Lang_code',
                        // foreignField:'_id',
                        foreignField:'langCode',
                        as:'language'
                    }
                }
            ];

            if(role){
                userPipeline.push({
                    $match: {
                        'role': role // Case-insensitive match for titles starting with queryparam
                    }
                });
            }

            if(account_status){
               
                userPipeline.push({
                    $match: {
                        'status': account_status // Case-insensitive match for titles starting with queryparam
                    }
                });
            }else{
                userPipeline.push({
                    $match: {
                        $and: [
                            { status: { $ne: "trash" } },
                            { status: { $ne: "inactive" } },
                            { status: { $ne: "expired" } }
                        ]
                      }
                });
            }

            if ((typeof queryparam !== "undefined") && queryparam) {
                // Add the $match stage conditionally if queryparam is not empty
                userPipeline.push({
                    $match: {
                        'firstName': new RegExp(`^${queryparam}`, "i"),
                    }
                });
            }
            const totalDocumentsPipeline = [...userPipeline];
            const users = await UserModel.aggregate(userPipeline).skip(skipCount).limit(pageSize);

            // res.send(users);

            // console.log("-- users data ====");
             console.log(users);

            // const totalDocuments = await UserModel.countDocuments();
            // const totalPages = Math.ceil(totalDocuments / pageSize);

            let totalPages = 0;
            if(users.length != 0){
                const totalDocuments = await UserModel.aggregate(totalDocumentsPipeline).count("total");
                // const totalDocuments = videos.length;
                const totalCount = totalDocuments[0].total;
    
                totalPages = Math.ceil(totalCount / pageSize);
            }

            res.status(200).json({ status: "success", data: users, totalPages: totalPages });  

        } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
        }
    }

    static update_user = async (req, res) =>{
        try {
            const {first_name, last_name, email, gender, phone, country, language, status, role, automatic_publish, membertitle, thumbnail, video_publisher, user_id,loggedin } = req.body;
           
            const file = req.file;
            
            const user_doc = {
                firstName:first_name,
                lastName:last_name,
                email:email,
                gender:gender,
                phone:phone,
                status:status,
                role:role,
                // preferredLang: language,
                Lang_code: language,
                thumbnail:thumbnail,
                // password:hashPassword,
                loggedin:loggedin,
            } 
            

            // if(pass){
            //     const salt = await bcrypt.genSalt(10);
            //     const hashPassword = await bcrypt.hash(pass, salt);
            //     user_doc.password = hashPassword;
            //     let setpass = await adminSetUserPassword(email, pass);
            //     console.log("set password detail");
            //     console.log(setpass);
            //     if(!setpass){
            //         return res.status(500).json({ error: "Password must Contains at least 1 number, Contains at least 1 special character,1 uppercase letter and 1 lowercase letter." });   
            //     }
            // }

            if(membertitle){
                user_doc.membertitle = membertitle;
            }

            var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
              user_doc.thumbnail = thumbnail
            }
    
          
    
            if(automatic_publish == "on"){
                user_doc.automatic_publish = 1;
            }

            if(video_publisher == "on"){
                user_doc.video_publisher = 1;
            }

            if (country !== '' && country !== null && country !== undefined) {
                user_doc.countryid = country;
            }
            const result = await UserModel.findByIdAndUpdate(req.params.id, user_doc);
            res.status(201).json({ status: 'success', data: result });
        
        } catch (error) {
            console.log("error message =====");
            console.log(error);
            return res.status(500).json({ error: 'Failed to update Topic.' });   
        }
       
    }

    static save_users = async (req, res) =>{
        // res.send(req.body.phone);
        try {
            const {first_name, last_name, email, password,password_confirmation, gender, phone, country, language, status, role, automatic_publish, thumbnail, video_publisher, membertitle } = req.body;

               // Check if passwords match
            if (password !== password_confirmation) {
                return res.status(500).json({ error: 'password and confirmed password does not match.' });   
            }
         
            let signUpResult = await signUpCognito(req, res);

            let response = {
                username:signUpResult.user.username,
                id:signUpResult.userSub,
                success:true
            }

            console.log("signup result ====");
            console.log(signUpResult);
            console.log("response =====");
            console.log(response);
            // let result = await verifycode(response.username, code);

            
            console.log("Result value ====");
            // console.log(result);
            if(response.username){
              
                const file = req.file;
                const lastUser = await UserModel.findOne({}, { user_id: 1 }).sort({ _id: -1 }).exec();
                let lastAutoIncrementId = 1;
                if(lastUser && lastUser.user_id){
                    lastAutoIncrementId = lastUser.user_id+1;
                }

               const user_doc = {
                    user_id: lastAutoIncrementId,
                    firstName:first_name,
                    lastName:last_name,
                    email:email,
                    gender:gender,
                    phone:phone,
                    status:status,
                    role:role,
                    preferredLang: language,
                    thumbnail:thumbnail,
                    
                } 
    
                if (country !== '' && country !== null && country !== undefined) {
                    user_doc.countryid = country;
                }
                
                var uploaded_path = '';
                if (file && file.path && file.path !== "undefined") 
                {
                     uploaded_path =  file.path.replace(`public${path.sep}`, '');
                     user_doc.thumbnail = thumbnail
                }
    
                if (password && password_confirmation) {
                    if(password === password_confirmation){
                        const salt = await bcrypt.genSalt(10)
                        const newHashPassword = await bcrypt.hash(password, salt)
                        user_doc.password = newHashPassword;
                    }else{
                        return res.status(500).json({ error: 'password and confirmed password does not match.' });   
                    }
                }
    
                if(membertitle){
                    user_doc.membertitle = membertitle;
                }
    
                if(automatic_publish == "on"){
                    user_doc.automatic_publish = 1;
                }
    
                if(video_publisher == "on"){
                    user_doc.video_publisher = 1;
                }
    
                const result = await UserModel.create(user_doc);
                res.status(201).json({ status: 'success', data: result });
            }else{
                res.status(500).send("Unable to create users");
            }
            // res.send(signUpResult);
        } catch (error) {
            console.log(error);
            res.status(500).send(error);
        }


    }

   

    static home_users = async (req, res) =>{
        var current_lang = req.params.lang || 'en';
        const result = await UserModel.aggregate([
                {
                    $lookup:{
                        from:'tora_languages',
                        localField:'preferredLang',
                        foreignField:'_id',
                        as:'language'
                    }
                },
               {
                    $lookup: {
                        from:'tora_videos',
                        localField:'_id',
                        foreignField:'userId',
                        as:'videos'
                    }
               },
               {
                    $addFields:{
                        'videoCount': { $size: '$videos' },
                    }
               },
               {
                    $project:{
                        // videos:0,
                        _id:1,
                        membertitle:1,
                        firstName:1,
                        lastName:1,
                        videoCount:1,
                        language:1,
                        thumbnail:1
                    }
               }
               
        ]);

        res.send(result);
    }

    static bulk_status_change = async (req, res) =>{
        try{
            var ids = req.body.checkids;
            var action = req.body.action;
            if (ids && Array.isArray(ids)) {
                if(action){
                    for (const id of ids) {
                        const updateFields = {
                            status:action,
                        };
                    const result = await UserModel.findByIdAndUpdate(id, updateFields);
                    }
                }
            
              res.status(201).json({ status: 'success' });
            }else {
              res.status(400).json({ error: 'Invalid request data.' });
            }
          } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
          }
    }

    static bulk_restore = async (req, res) =>{
        try{
            var ids = req.body.checkids;
            if (ids && Array.isArray(ids)) {
                    for (const id of ids) {
                        const updateFields = {
                            status:'active',
                        };
                    const result = await UserModel.findByIdAndUpdate(id, updateFields);
                    }
                
            
              res.status(201).json({ status: 'success' });
            }else {
              res.status(400).json({ error: 'Invalid request data.' });
            }
          } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update .' });
          }
    }

    static bulk_delete = async (req, res) => {
        try {
          var ids = req.body.checkids;
      
          if (ids && Array.isArray(ids)) {
            const result = await UserModel.deleteMany({ _id: { $in: ids } });
      
            if (result.deletedCount > 0) {
              res.status(201).json({ status: 'success' });
            } else {
              res.status(404).json({ error: 'No matching documents found.' });
            }
          } else {
            res.status(400).json({ error: 'Invalid request data.' });
          }
        } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to delete documents.' });
        }
      };

    static change_status = async (req, res) =>{
        try {
            var id = req.params.id;
            const updateFields = {
                status:'trash',
            };
            
            const result = await UserModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
    }

    static disable_access = async (req, res) =>{
        try {
            const id =  new mongoose.Types.ObjectId(req.params.id);
            const User = await UserModel.findOne({ _id: id });
            const email = User.email;
            const updateFields = {
                status:'inactive',
            };
            
            const disableuser = await disableUser(email);
            console.log("disable user");
            console.log(disableUser);

            const result = await UserModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            console.log("disable user error ====");
            return res.status(500).json({ error: 'Failed to update .' });
        }
    }

    static enable_access = async (req, res) =>{
        try {
            const id =  new mongoose.Types.ObjectId(req.params.id);
            const User = await UserModel.findOne({ _id: id });
            const email = User.email;
            const updateFields = {
                status:'active',
            };
            
            const enableuesr = await enableUser(email);

            console.log("enable user");
            console.log(enableuesr);

            const result = await UserModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            console.log("enable user error ====");
            return res.status(500).json({ error: 'Failed to update .' });
        }
    }

    static restore_vid = async (req, res) =>{
        try {
            var id = req.params.id;
            const updateFields = {
                status:'user',
            };
            
            const result = await UserModel.findByIdAndUpdate(id, updateFields);
            res.status(201).json({ status: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Failed to update video.' });
        }
    }

    static delete_user = async (req, res) =>{
        try {
            const result = await UserModel.findByIdAndRemove(req.params.id);
            res.status(201).json({ status: 'success', data: result });
          } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Failed to delete user.' });
          }
    }


    static reset_user = async (req, res) =>{
        try {
            // const email=req.params.id;
            const id =  new mongoose.Types.ObjectId(req.params.id);
            const User = await UserModel.findOne({ _id: id });
            const secret = JWT_SECRET + User.password;
            const token = jwt.sign({ email: User.email, id: User._id }, secret, {
                expiresIn: "5m",
              });
              const link=``;

            const transporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 465,
                secure: true,
                auth: {
                    user: '',
                    pass: '',
                }
            });
          
            const info = await transporter.sendMail({
                from: ``, // sender address
                to: `${User.email}`, // list of receivers
                subject: "Reset link", // Subject line
                text: link, // plain text body
                html:link, // html body
              });
            
              console.log("Message sent: %s", info.messageId);


              
            res.status(201).json({ status: 'success'});
        
        } catch (error) {
            console.log("error message =====");
            console.log(error);
            return res.status(500).json({ error: 'Failed to sent link' });   
        }
       
    }

    static resetpass_users = async (req, res) => {
        try {
            
            const { id, token } = req.params;
            console.log(req.params);

            const User = await UserModel.findOne({ _id: id });
            // console.log(bcrypt(User.password))
            const secret = JWT_SECRET + User.password;
            try {
                const verify = jwt.verify(token, secret);
                res.render("reset-user", { email: verify.email, status: "Not Verified" });
              } catch (error) {
                console.log(error);
                res.send("Not Verified");
              }
        } catch (error) {
          console.log(error);
          res.send(error);
        }
    }

    static update_password = async (req, res) => {
        const { id, token } = req.params;
        const { oldpassword,password } = req.body;

        const User = await UserModel.findOne({ _id: id });
        const email= User.email;
        const secret = JWT_SECRET + User.password;
        try {
            console.log("yo")
            await updateCognitoPassword(email,password,oldpassword);
          const verify = jwt.verify(token, secret);
          const encryptedPassword = await bcrypt.hash(password, 10);
          await UserModel.updateOne(
            {
              _id: id,
            },
            {
              $set: {
                password: encryptedPassword,
              },
            }
          );
      
          res.render("reset-user", { email: verify.email, status: "verified" });
        } catch (error) {
          console.log(error);
          res.json({ status: "Something Went Wrong" });
        }
    }
    

}

export default UserApiController;