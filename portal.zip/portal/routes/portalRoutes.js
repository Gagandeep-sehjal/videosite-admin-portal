import express from 'express';
const router = express.Router();
import SeriesController from '../controllers/SeriesController.js';
import TopicController from '../controllers/TopicController.js';
import setLanguage from '../middleware/set-Language.js';
import OrganizationController from '../controllers/OrganizationController.js';
import checkUserWebAuth from '../middleware/auth-web-midleware.js';
import VideosController from '../controllers/VideosController.js';
import UserController from '../controllers/userController.js';
import checkAdminWebAuth from '../middleware/auth-admin-midleware.js';
import LanguageController from '../controllers/LanguageController.js';
import librarycontroller from '../controllers/librarycontroller.js';


router.use('/series/', checkUserWebAuth);
router.use('/series/add', checkUserWebAuth, checkAdminWebAuth);
router.use(['/topics','/topic/*'], checkUserWebAuth);
router.use('/organization/*', checkUserWebAuth);
router.use('/feature', checkUserWebAuth);
router.use('/videos/*', checkUserWebAuth);
router.use('/users', checkUserWebAuth);
router.use('/user/add', checkUserWebAuth);
router.use('/language', checkUserWebAuth);
router.use('/language/add', checkUserWebAuth);
router.use('/countries', checkUserWebAuth);
router.use('/countries/add', checkUserWebAuth);
router.use('/dedication/add',checkUserWebAuth);
router.use('/dedication/edit/:id',checkUserWebAuth);


router.get('/dashboard', UserController.dashboard);
router.get('/languages', UserController.languages);


router.get('/videos/add', VideosController.add_videos);
router.get('/videos', VideosController.videos_list);

router.get('/series', SeriesController.get_home_series);
router.get('/series/add',  checkAdminWebAuth,SeriesController.add_series);
router.get('/series/edit/:id', checkAdminWebAuth, SeriesController.edit_series);
router.get('/series/translation', SeriesController.series_translation);

router.get('/topics', TopicController.get_home_topics);
router.get('/topic/add',  checkAdminWebAuth,TopicController.add_new_topic);
router.get('/topic/edit/:id', checkAdminWebAuth, TopicController.edit_topic);
router.get('/topic/translation', TopicController.topic_translation);

router.get('/feature', SeriesController.feature);

router.post('/feature', SeriesController.feature_data);

router.get('/organization/add', checkAdminWebAuth, OrganizationController.add_organization);
router.get('/organization', OrganizationController.get_organization);
router.get('/organization/edit/:id', checkAdminWebAuth,OrganizationController.edit_organization);

router.get('/videos/add', VideosController.add_videos);
router.post('/videos/add', VideosController.save_videos);
router.get('/videos/edit/:id',checkAdminWebAuth,VideosController.edit_videos);

router.get('/users', UserController.user_list);
router.get('/users/edit/:id',checkAdminWebAuth, UserController.edit_users);
router.get('/user/add', UserController.add_users);

router.get('/language', LanguageController.get_languages);
router.get('/language/add', LanguageController.add_languages);

router.get('/delete_countries', LanguageController.delete_countries);
router.get('/video_csv_update',VideosController.update_language);



router.get('/get_images', TopicController.get_images);

router.get('/library',librarycontroller.getpage)
router.get('/library/add',librarycontroller.add_image)



router.get('/countries', LanguageController.get_countries);
router.get('/countries/add', LanguageController.add_countries);




export default router;
