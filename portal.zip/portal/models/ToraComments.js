import mongoose from 'mongoose';


const CommentsSchema = new mongoose.Schema({
    comment:String,
    status: { 
        type: String, 
        enum: ['draft', 'publish','trash'], default: 'draft' 
      },
      userId: {
        type: mongoose.Schema.Types.ObjectId,
      },
      videoId: {
        type: mongoose.Schema.Types.ObjectId,
      },
      parentId: {
        type: mongoose.Schema.Types.ObjectId,
        
      },
});


// Create the Taxonomy model
const ToraCommentsModel = mongoose.model('Tora_comments', CommentsSchema);

export default ToraCommentsModel;
