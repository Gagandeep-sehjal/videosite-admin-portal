import mongoose from "mongoose";
import LanguageModel from "../models/Language.js";
import TaxonomyModel from "../models/Taxonomy.js";
import ToraLog from "../models/ToraLog.js";
import UserModel from "../models/User.js";
import path from 'path';
import { formatDatetime, convertToSlug } from "../utils/utils.js";
import { getAllFilesFromS3, getTranslation, uploadFileToS3 } from "../utils/utils.js";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class OrganizationController{
    static add_organization = async(req, res) =>{
        const all_cookies = req.cookies; 
      var current_lang = 'en';
      if(all_cookies.current_lang){
        var current_lang = all_cookies.current_lang;
      }

      const organization = await TaxonomyModel.find( {
        $and: [
          { type: 'organization' },
          { lang: current_lang }
        ]
      });

      const languages = await LanguageModel.find();
      let user = await UserModel.findById(req.session.userId);

        res.render('add-organization', {current_lang, organization, languages,user});
    }

    static create_organization = async(req, res) =>{
        try {
            const {name, parentOragnization, description, position, language, thumbnail, visible} = req.body;

            // Get the uploaded file from the request
            const file = req.file;
            let {slug}=req.body;
            if(slug == ""){
              slug = convertToSlug(name);
             }
           
            const highestTermIdDocument = await TaxonomyModel.findOne().sort({ term_id: -1 });
            let highestTermId = 0;
            if (highestTermIdDocument && highestTermIdDocument.term_id) {
            highestTermId = highestTermIdDocument.term_id;
            }
            const organization_doc = new TaxonomyModel({
                title:name,
                slug:slug,
                // parentId:parentSeries, 
                description:description, 
                type:'organization',
                order:position, 
                lang:language, 
                userId: "65118a686cd915d6963a6354",
                status:'publish',
                // Add the image file details to the model
                thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
                visible:visible,
                term_id:highestTermId + 1,

            });
            

            if (parentOragnization) {
                console.log("you are in ====");
                series_doc.parentId = parentOragnization;
            }

            console.log(organization_doc);
            console.log("parent series fds=====");

            const result = await organization_doc.save();
            console.log(result)
            // Return the saved series data as a response
            res.status(201).json({ status: 'success', data: result });
        } catch (error) {
          if(error && error.code=== 11000){
            console.error('Error:name must be unique');
         
            return res.status(500).json({ error: 'Name already taken' });
          }else{
            console.log(error);
            // return res.status(500).json({ error: 'Failed to create a new series.' });
            return res.status(500).json({ error: error });
          }
        }
    }

    static get_organization = async(req, res) =>{
      const { status } = req.query;
        try {
            const all_cookies = req.cookies; 
            var current_lang = 'en';
            if(all_cookies.current_lang){
              var current_lang = all_cookies.current_lang;
            }

            let user = await UserModel.findById(req.session.userId);
            // const organization = await TaxonomyModel.find( { type: 'organization' } );
            const baseMatch = {
              $and: [
                { type: 'organization' },
                { lang: 'en' },
              ]
            };

            if (status === 'trash') {
              baseMatch.$and.push({ status: 'trash' });
            }else{
              baseMatch.$and.push({ status: { $ne: 'trash' } });
            }

            const organization = await TaxonomyModel.aggregate([
              {
                  $match:baseMatch
              },
              {
                  $lookup: {
                      from: 'tora_term_relations2',
                      localField: 'term_id',
                      foreignField: 'termId',
                      as: 'videos'
                  }
              },
              {
                  $addFields: {
                      videoCount: { $size: '$videos' } // Add a new field for video count
                  }
              },
              {
                  $project: {
                      videos: 0 // Exclude the videos array from the final result if not needed
                  }
              },
              {
                $sort: {
                  title: 1 // 1 for ascending order, -1 for descending order
                }
              }
            ]);

            const languages = await LanguageModel.find();
            let trashcount = await TaxonomyModel.countDocuments({status:"trash",type:"organization"});
            let allcount = await TaxonomyModel.countDocuments({type:"organization",status: { $ne: 'trash' }});

            res.render('organization',{user, organization, languages, current_lang,trashcount,allcount,status });
          } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
          }
    }

    static edit_organization = async (req, res) =>{
        try{
            let user = await UserModel.findById(req.session.userId);
            const all_cookies = req.cookies;
            const current_lang = all_cookies.current_lang || 'en';
            
            const result = await TaxonomyModel.findOne({_id: req.params.id});
  
            const organization = await TaxonomyModel.find({ _id: { $ne: req.params.id }, type: 'organization' });
  
            const langauges = await LanguageModel.find();
            
            const organization_log = await ToraLog.aggregate([
              {
                $match: {
                  $and: [
                    { entity: 'Organization' },
                   { entityId: new mongoose.Types.ObjectId(req.params.id) }, // Assuming req.params.id is the ObjectId
                  ],
                },
              },
              {
                $lookup: {
                  from: 'tora_users', // Name of the tora_user collection
                  localField: 'user', // Field in ToraLog collection to match
                  foreignField: '_id', // Field in tora_user collection to match
                  as: 'userData', // Name for the merged user data field
                },
              },
            ]);

            res.render('organization-edit',{organization, langauges, result, current_lang, user, organization_log, formatDatetime });
          }  catch (error) {
            console.error('Error fetching series data:', error);
          }
    }

    static update_organization = async (req, res) =>{
        try {
            const {name,parentOragnization, description, position, language, thumbnail, visible} = req.body;
            let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
            let user = await UserModel.findById(req.session.userId);
            let organization_old_detail = await TaxonomyModel.findById(req.params.id);
            // title change log
            if(organization_old_detail.title != name){
              const log_doc = new ToraLog({
                                  event:"Name Changed",
                                  entity:"Organization",
                                  entityId: req.params.id,
                                  user:user._id,
                                  changes:{field:"name",oldValue:organization_old_detail.title, newValue:name}
                              });
              const logsave = await log_doc.save();
            }

            // Get the uploaded file from the request
            const file = req.file;
            console.log('file name ');
            console.log(file);
    
            var uploaded_path = '';
            if (file && file.path && file.path !== "undefined") 
            {
              uploaded_path =  file.path.replace(`public${path.sep}`, '');
            }
    
            const organization_doc = {
              title:name,
              slug:slug,
              description:description, 
              order:position, 
              lang:language, 
              status:'publish',
               // Add the image file details to the model
              thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
              visible:visible
            };
    
          if (parentOragnization) {
            series_doc.parentId = parentOragnization;
          }
    
            console.log(req.params);
            console.log("param error ====");
    
            const result = await TaxonomyModel.findByIdAndUpdate(req.params.id, organization_doc);
    
            res.status(201).json({ status: 'success', data: result });
          } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Failed to update series.' });
          }
    }

    static delete_organization = async (req, res) =>{
        try {
            const result = await TaxonomyModel.findByIdAndRemove(req.params.id);
            res.status(201).json({ status: 'success', data: result });
          } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Failed to delete organization.' });
          }
    }

   
}

export default OrganizationController;