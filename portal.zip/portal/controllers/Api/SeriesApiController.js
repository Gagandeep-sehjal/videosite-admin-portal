import mongoose from 'mongoose';
import SeriesModel from "../../models/Series.js";
import TaxonomyModel from "../../models/Taxonomy.js";
import ToraFeaturesModel from '../../models/ToraFeatures.js';
import {getLanguageName, convertToSlug} from '../../utils/utils.js';
import path from 'path';
import UserModel from '../../models/User.js';
import ToraLog from '../../models/ToraLog.js';
import ToraTermRelation2Model from '../../models/ToraTermRelation2.js';

class SeriesApiController{
    static get_home_series = async (req, res) =>{
        try {
            const pageNumber = req.query.page;
            const pageSize = 10; // Specify the number of documents per page

            const skipCount = (pageNumber - 1) * pageSize;

  

            var current_lang;
            // req.query.current_lang = null;
            if(req.query.current_lang == "es" || req.query.current_lang == "he" || req.query.current_lang == "yi"){
              current_lang = req.query.current_lang;
            }else{
              current_lang = 'en';
            }

            console.log("current language value =====");
            console.log(current_lang);
            console.log(req.query.current_lang);
            const series = await TaxonomyModel.find({ $and: [
              {type: 'series'},
              {lang: current_lang}
            ] })
            .skip(skipCount) // Skip the initial documents
            .limit(pageSize); // Limit the number of documents returned

            // Total number of documents (for calculating total pages, etc.)
            const totalDocuments = await TaxonomyModel.countDocuments({ $and: [
              {type: 'series'},
              {lang: current_lang}
            ] });

            console.log(totalDocuments);
            console.log("=== document number =====");

            // Calculate total pages based on the total number of documents and page size
            const totalPages = Math.ceil(totalDocuments / pageSize);
            
            // Send the data as JSON
            res.status(200).json({ status: "success", data: series, totalPages: totalPages });
          } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
          }
    }

    static create_series = async (req, res) =>{
      try {
        // console.log(req.body);
        // res.send( req.body);
        const {name, parentSeries, description, position, language, spanish, hebrew, yiddish, thumbnail, visible} = req.body;
        let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
       

          // Get the uploaded file from the request
        const file = req.file;

        console.log("file data");
        console.log(file);

          // Check if a file was uploaded
        // if (!file) {
        //     return res.status(400).json({ error: 'No image uploaded.' });
        // }

        var uploaded_path = '';
        if (file && file.path && file.path !== "undefined") 
        {
          uploaded_path =  file.path.replace(`public${path.sep}`, '');
        }

        var series_id = new mongoose.Types.ObjectId();

        console.log(req.body);
        console.log("parent series =====");
        const highestTermIdDocument = await TaxonomyModel.findOne().sort({ term_id: -1 });
            let highestTermId = 0;
            if (highestTermIdDocument && highestTermIdDocument.term_id) {
            highestTermId = highestTermIdDocument.term_id;
            }

          const series_doc = new TaxonomyModel({
              _id:series_id,
              title:name,
              slug:slug,
              // parentId:parentSeries, 
              description:description, 
              translations: [
                { languageCode: 'en', languageName:"english", translation: name },
                { languageCode: 'es', languageName:"spanish", translation: spanish },
                { languageCode: 'he', languageName:"hebrew", translation: hebrew },
                { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
              ],
              type:'series',
              order:position, 
              lang:language, 
              relationlId:series_id,
              userId: "65118a686cd915d6963a6354",
              status:'publish',
               // Add the image file details to the model
              thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
              visible:visible,
              term_id:highestTermId + 1,

          });

          if (parentSeries) {
            console.log("you are in ====");
            series_doc.parentId = parentSeries;
          }

          console.log(series_doc);
          console.log("parent series fds=====");

          const result = await series_doc.save();
          console.log(result)
           // Return the saved series data as a response
            res.status(201).json({ status: 'success', data: result });
        }
      catch (error) {
        if(error && error.code=== 11000){
          console.error('Error:name must be unique');
       
          return res.status(500).json({ error: 'Name already taken' });
        }else{
          console.log(error);
          // return res.status(500).json({ error: 'Failed to create a new series.' });
          return res.status(500).json({ error: error });
        }
      }
    }

    static view_single_series = async (req, res)=>{
      try{
        const result = await SeriesModel.findById(req.params.id);
        console.log(result);
        res.status(200).json({ status: "success", data: result });
      }  catch (error) {
        console.error('Error fetching series data:', error);
      }
    }

    static update_series = async (req, res) =>{
      try {
        const {name, parentSeries, description, position, language, spanish, hebrew, yiddish, thumbnail, visible} = req.body;
        let {slug}=req.body;
        if(slug == ""){
          slug = convertToSlug(name);
         }
        let user = await UserModel.findById(req.session.userId);
        let series_old_detail = await TaxonomyModel.findById(req.params.id);
          // title change log
          if(series_old_detail.title != name){
            const log_doc = new ToraLog({
                                event:"Name Changed",
                                entity:"Series",
                                entityId: req.params.id,
                                user:user._id,
                                changes:{field:"name",oldValue:series_old_detail.title, newValue:name}
                            });
            const logsave = await log_doc.save();
          }

        // Get the uploaded file from the request
        const file = req.file;

        var uploaded_path = '';
        if (file && file.path && file.path !== "undefined") 
        {
          uploaded_path =  file.path.replace(`public${path.sep}`, '');
        }

        const series_doc = {
          title:name,
          slug:slug,
          // parentId:parentSeries, 
          description:description, 
          translations: [
            { languageCode: 'en', languageName:"english", translation: name },
            { languageCode: 'es', languageName:"spanish", translation: spanish },
            { languageCode: 'he', languageName:"hebrew", translation: hebrew },
            { languageCode: 'yi', languageName:"yiddish",translation: yiddish },
          ],
          order:position, 
          lang:language, 
          status:'publish',
           // Add the image file details to the model
          thumbnail: thumbnail, // Assuming 'file.path' contains the path to the uploaded image
          visible:visible
        };

        if (parentSeries) {
          series_doc.parentId = parentSeries;
        }

        const result = await TaxonomyModel.findByIdAndUpdate(req.params.id, series_doc);

        res.status(201).json({ status: 'success', data: result });
      } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Failed to update series.' });
      }
    }

    static delete_series = async (req, res) =>{
      try {
        const result = await TaxonomyModel.findByIdAndRemove(req.params.id);
        res.status(201).json({ status: 'success', data: result });
      } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Failed to delete series.' });
      }
      
    }

    static change_status = async (req, res) =>{
      try {
        var id = req.params.id;
        const updateFields = {
            status:'trash',
        };
        console.log("yo")
          const result = await TaxonomyModel.findByIdAndUpdate(id, updateFields);
          res.status(201).json({ status: 'success' });
      } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update series.' });
      }
    }


    static restore_series = async (req, res) =>{
      try {
        var id = req.params.id;
        const updateFields = {
            status:'publish',
        };
        
        const result = await TaxonomyModel.findByIdAndUpdate(id, updateFields);
        res.status(201).json({ status: 'success' });
      } catch (error) {
          console.error(error);
          return res.status(500).json({ error: 'Failed to update series.' });
      }
    }

    static translate_series = async (req, res) =>{
      //  console.log(req.body);

      //  res.send(req.body);

       try {
        const {series_id, translate_text, lang_code} = req.body;
        var result = await TaxonomyModel.findOneAndUpdate(
          {
            _id: series_id,
            type: 'series',
            'translations.languageCode': lang_code // Match documents with the desired language code
          },
          {
            $set: {
              'translations.$.translation': translate_text // Update the translation field for the matched language
            }
          },
          { new: true } // This option returns the updated document
        );

        if (!result) {
          // If no matching document is found, create a new translation
          const language_name = getLanguageName(lang_code); // Refactor this part for better readability
      
          result = await TaxonomyModel.findOneAndUpdate(
            {
              _id: series_id,
              type: 'series',
            },
            {
              $push: {
                translations: {
                  languageCode: lang_code,
                  languageName: language_name,
                  translation: translate_text,
                },
              },
            },
            { new: true }
          );
        }
        
        res.status(201).json({ status: 'success', data: result });
       } catch (error) {
          console.log(error);
          return res.status(500).json({ error: 'Failed to delete series.' });
       }

      //  res.send(req.body);

      //  const {series_id, translate_text, lang_code} = req.body;  
      //  const result = await TaxonomyModel.findOneAndUpdate(
      //   {
      //     $and: [
      //       { relationlId: series_id },
      //       { lang: lang_code },
      //       { type: 'series' }
      //     ]
      //   },
      //   {
      //     $set: { title: translate_text }
      //   },
      //   { new: true } // This option returns the updated document
      // );

      // console.log("=== result ====");
      // console.log(result);

      // if(result){
      //   res.status(201).json({ status: 'success', data: result });
      // }else{
      //     const eng_result = await TaxonomyModel.findById(series_id);
      //     console.log(eng_result);

      //     const series_doc = new TaxonomyModel({
      //       title:translate_text,
      //       slug: eng_result.slug,
      //       // parentId:parentSeries, 
      //       description:eng_result.description, 
      //       type:'series',
      //       order:eng_result.position, 
      //       lang:lang_code, 
      //       relationlId:eng_result._id,
      //       userId: "65118a686cd915d6963a6354",
      //       status:'publish',
      //       // Add the image file details to the model
      //       thumbnail: eng_result.thumbnail, // Assuming 'file.path' contains the path to the uploaded image
      //   });

      //   const new_result = await series_doc.save();

      //   res.status(201).json({ status: 'success', data: new_result });

      //   console.log("=== english data =====");
      // }

    }

    static home_series = async (req, res) =>{
      var current_lang = req.params.lang || 'en';

      // const results = await ToraFeaturesModel.aggregate([
      //   {
      //     $match: {
      //       'taxonomy_name': 'series', // Filter by taxonomy_name
      //       // 'tora_term_relations.termName':'topic'
      //     },
      //   },
      //   {
      //     $lookup: {
      //       from: 'tora_taxonomies', // The name of the other collection
      //       localField: 'taxonomy_id', // Field from tora_features collection
      //       foreignField: '_id', // Field from tora_taxonomies collection
      //       as: 'taxonomyData', // Alias for the joined data
      //     },
      //   },
      //   {
      //     $unwind: '$taxonomyData',
      //   },
      //     {
      //       $lookup: {
      //         from: 'tora_term_relations', // The name of the other collection
      //         localField: 'taxonomy_id', // Field from tora_features collection
      //         foreignField: 'termId', // Field from tora_term_relations collection
      //         as: 'videoCounts', // Alias for the joined data
      //       },
      //     },
      //     {
      //       $lookup: {
      //         from: 'tora_users', // The name of the other collection
      //         localField: 'videoCounts.taxonomy_id', // Field from tora_features collection
      //         foreignField: '_id', // Field from tora_term_relations collection
      //         as: 'userCount', // Alias for the joined data
      //       },
      //     },
      //     {
      //       $addFields: {
      //         videoCount: { $size: '$videoCounts' },
      //         // userCount: { $first: '$userCount' },
      //         'taxonomyData': {
      //           $filter: {
      //             input: '$taxonomyData.translations',
      //             as: 'translation',
      //             cond: {
      //               $eq: ['$$translation.languageCode', current_lang] // Include only English translations
      //             },
      //           },
      //         },
      //       },
      //     },
      //   {  
      //     $project: {
      //       videoCounts: 0, // Exclude the videoCounts array from the result
      //     },
      //   },
      // ]);

    //   const results = await ToraFeaturesModel.aggregate([
    //   {
    //     $match: {
    //       'taxonomy_name': 'series', // Filter by taxonomy_name
    //     },
    //   },
    //   {
    //     $lookup: {
    //       from: 'tora_taxonomies', // The name of the other collection
    //       localField: 'taxonomy_id', // Field from tora_features collection
    //       foreignField: '_id', // Field from tora_taxonomies collection
    //       as: 'taxonomyData', // Alias for the joined data
    //     },
    //   },
    //   {
    //     $lookup: {
    //       from: 'tora_term_relations', // The name of the other collection
    //       localField: 'taxonomy_id', // Field from tora_features collection
    //       foreignField: 'termId', // Field from tora_term_relations collection
    //       as: 'videoCounts', // Alias for the joined data
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: '$taxonomyData._id', // Group by taxonomyData._id
    //       taxonomyData: { $first: '$taxonomyData' }, // Preserve the taxonomyData
    //       videoCount: { $videoCounts:{$count: {}} }, // Count the number of videos
    //     },
    //   },
    // ]);

    const results = await ToraFeaturesModel.aggregate([
      {
        $match: {
          'taxonomy_name': 'series',
          // 'tora_taxonomies.status':"publish"
        },
      },
      {
        $lookup: {
          from: 'tora_taxonomies',
          // localField: 'taxonomy_id',
          // foreignField: '_id',
          let: { taxonomyId: '$taxonomy_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ['$_id', '$$taxonomyId'] }, // Match the taxonomy_id field
                    { $eq: ['$status', 'publish'] }   // Match the status field
                    // { $eq: ['$translations'] }   // Match the status field
                  ]
                }
              }
            }
          ],
          as: 'taxonomyData',
        },
      },
      {
        $unwind: '$taxonomyData',
      },
      {
        $lookup: {
          from: 'tora_term_relations',
          localField: 'taxonomy_id',
          foreignField: 'termId',
          as: 'termRelations',
        },
      },
      {
        $unwind: '$termRelations',
      },
      {
        $lookup: {
          from: 'tora_videos',
          localField: 'termRelations.objectId',
          foreignField: '_id',
          as: 'videos',
        },
      },
      {
        $unwind: '$videos',
      },
      {
        $group: {
          _id: '$_id',
          taxonomyName: { $first: '$taxonomyData.translations' },
          taxonomy: { $first: '$taxonomyData' },
          termRelations: { $push: '$termRelations' },
          videos: { $push: '$videos' },
          users: { $push: '$videos.userId' },
        },
      },
      {
        $addFields: {
          'taxonomyName': {
            $filter: {
              input: '$taxonomyName',
              as: 'translation',
              cond: { $eq: ['$$translation.languageCode', current_lang] },
            },
          },
         'videoCount': { $size: '$videos' }, // Add a field 'videoCount' with the size of 'videos' array
         'uniqueUserCount': {
            $size: {
              $setUnion: '$users' // Count unique user IDs using $setUnion
            }
          }
        },
      },
      {
        $project: {
          termRelations: 0, // Exclude the termRelations array from the result
          videos:0,
          // users:0,
          // 'taxonomy.translations': 0, // Exclude the translations field
        },
      },
    ]);


    
      

        res.send(results);
    }

    static delete_series_lang = async (req, res) =>{
      // res.send(req.body.lang_code);
      try {
        const result = await TaxonomyModel.updateOne(
          { _id: req.params.id },
          {
            $pull: {
              translations: { languageCode: req.body.lang_code }
            }
          }
        );

        console.log(result);
      
        if (result.nModified === 0) {
          // Handle the case where no documents were modified (language code not found)
          return res.status(404).json({ error: 'Translation not found' });
        }
      
        console.log('Translation removed successfully');
        return res.status(201).json({ status: 'success' });
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Failed to delete translation.' });
      }
      
      
    }
    

    // static series_videos = async (req, res) =>{
    //   var current_lang = req.params.lang || 'en';
    //   const page = req.query.pageno;
    //   const pageSize = parseInt(req.query.pagesize) || 10;

    //   try {
    //     const results = await TaxonomyModel.aggregate([
    //         {
    //           $match: {
    //             'type': 'series', 
    //           },
    //         },
           
    //         {
    //           $lookup: {
    //             from: 'tora_term_relations2',
    //             localField: 'term_id',
    //             foreignField: 'termId',
    //             as: 'termRelations',
    //           },
    //         },
    //         {
    //           $unwind: '$termRelations',
    //         },
    //         {
    //           $lookup: {
    //             from: 'tora_videos',
    //             localField: 'termRelations.objectId',
    //             foreignField: 'videoId',
    //             as: 'videos',
    //           },
    //         },
    //         {
    //           $unwind: '$videos',
    //         },

    //         {
    //           $group: {
    //             _id: '$_id',
    //             title: { $first: '$title' },
    //             translations: {
    //               $first: '$translations' 
    //           },
    //             videos: { $push: '$videos' },
    //             users: { $push: '$videos.user_id' },
    //           },
    //         },
    //         {
    //           $addFields: {
                
    //            'videoCount': { $size: '$videos' }, // Add a field 'videoCount' with the size of 'videos' array
    //            'uniqueUsers': {
                
    //               $setUnion: '$users' // Count unique user IDs using $setUnion
                
    //           }
    //           },
    //         },
    //         {
    //           $lookup: {
    //               from: 'tora_users', 
    //               localField: 'uniqueUsers',
    //               foreignField: 'user_id',
    //               as: 'user_info',
    //           },
    //           },
    //           {
    //             $addFields: {
    //                 user_info: {
    //                     $filter: {
    //                         input: '$user_info',
    //                         as: 'filtercat',
    //                         cond: {
    //                           $and: [
    //                               { $eq: ['$$filtercat.role', 'speaker'] }, 
    //                               { $eq: ['$$filtercat.status', 'active'] }  
    //                           ]
    //                       }
    //                     }
    //                 }
    //             }
    //         },
    //         {
    //           $addFields: {
                
    //            'SpeakerCount': { $size: '$user_info' }, 
              
    //           }
    //           },
            
    //       {
    //           $project: {
    //           _id: 1,
    //           title:1,
            //   translations: {
            //     $filter: {
            //     input: '$translations',
            //     as: 'translation',
            //     cond: { $eq: ['$$translation.languageCode', current_lang] },
            //     },
            // },

    //           // videos:{
    //           //   title:1,
    //           // },
    //            videoCount:1,
    //           //  uniqueUsers:1,
              
    //           // user_info:{
    //           //   role:1,
    //           // },
    //           SpeakerCount:1,
    //        }
    //       },
         
        
    //       ]) .skip((page - 1) * pageSize)
    //       .limit(pageSize);



    //     res.send(results);

    //   } catch (error) {
    //     console.error('Error:', error);
    //         res.status(500).send('Internal Server Error');
    //   }
      
      
    // }

    static series_videos = async (req, res) => {
      const current_lang = req.params.lang || 'en';
      const page = req.query.pageno;
      const pageSize = parseInt(req.query.pagesize) || 10;
    
      try {
        const series_data = await TaxonomyModel.find({type:"series",'term_id': { $ne: null }},{
          _id:0,
          term_id:1,
          title:1,
          thumbnail:1,
          translations: {
                $filter: {
                input: '$translations',
                as: 'translation',
                cond: { $eq: ['$$translation.languageCode', current_lang] },
                },
      }}).limit(10).skip((page - 1) * pageSize).limit(pageSize);;

        const getauthorcount = async (term_id)=>{
          return  await ToraTermRelation2Model.aggregate([
            {
                $match: {
                    termId: parseInt(term_id) 
                }
            },
            {
                $lookup: {
                    from: 'tora_videos',
                    localField: 'objectId',
                    foreignField: 'videoId',
                    as: 'videoInfo'
                }
            },
            {
                $unwind: '$videoInfo'
            },
            {
                $group: {
                    _id: null, // Group all documents into a single group
                    userCount: { $addToSet: '$videoInfo.user_id' },
                    videoCount: { $addToSet: '$videoInfo' }
                }
            },
            {
                $project: {
                    userCount: { $size: '$userCount' },
                    videoCount: { $size:'$videoCount'},
                    _id: 0
                }
            }
        ]);
        }

       // Add an extra field and log term_id for each document in the array
        const seriesDataWithExtraField = await Promise.all(series_data.map(async doc => {
          console.log(doc.term_id); // Log term_id for each document
          const authorCount = await getauthorcount(doc.term_id);
          return {
              ...doc.toObject(),
              counts: authorCount,
            
          };
      }));

        res.send(seriesDataWithExtraField);
      } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
      }
    }
    

    static series_detail = async (req, res) =>{
      const series_id=req.params.id;
      var current_lang = req.params.lang || 'en';
      const page = req.query.pageno;
      const pageSize = parseInt(req.query.pagesize) || 10;

try{ 
const result = await TaxonomyModel.aggregate([
  {
      $match: { '_id': new mongoose.Types.ObjectId(series_id) }
  },
  {
  $lookup: {
    from: 'tora_term_relations',
    localField: '_id',
    foreignField: 'termId',
    as: 'termRelations',
  },
},
{
  $unwind: '$termRelations',
},
{
  $lookup: {
    from: 'tora_videos',
    localField: 'termRelations.objectId',
    foreignField: '_id',
    as: 'videos',
  },
},
{
  $unwind: '$videos',
},

{
  $lookup: {
      from: 'tora_users', 
      localField: 'videos.userId',
      foreignField: '_id',
      as: 'users_info',
  },
  },
  
{
  $project: {
  _id: 1,
  title:1,
  translations: {
    $filter: {
    input: '$translations',
    as: 'translation',
    cond: { $eq: ['$$translation.languageCode', current_lang] },
    },
},
  videos:{
    publishedAt:1,
    views:1,
    _id: 1,
   title:1,
   thumbnail:1,
   link:1,
   userId:1,
   lang:1,
  },
  users:1,
  users_info:{
    _id: 1,
    firstName:1,
    lastName:1,
  }
}
},
{
  $skip: (page - 1) * pageSize,
},
{
  $limit: pageSize,
},

]);

  res.send(result);

}catch(error){
  console.error('Error:', error);
            res.status(500).send('Internal Server Error');
      }
      }
      
      
}
      
    
export default SeriesApiController;
