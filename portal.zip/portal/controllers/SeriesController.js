import mongoose from 'mongoose';
import LanguageModel from "../models/Language.js";
import SeriesModel from "../models/Series.js";
import TaxonomyModel from "../models/Taxonomy.js";
import ToraFeaturesModel from "../models/ToraFeatures.js";
import UserModel from "../models/User.js";
import ToraLog from "../models/ToraLog.js";
import { getAllFilesFromS3, getTranslation, uploadFileToS3 } from "../utils/utils.js";
import { formatDatetime } from '../utils/utils.js';
import LanguageController from './LanguageController.js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


class SeriesController{
    static get_home_series = async (req, res) =>{
        try {
            const all_cookies = req.cookies; 
            const { status } = req.query;
            var current_lang = 'en';
            if(all_cookies.current_lang){
              var current_lang = all_cookies.current_lang;
            }

            let user = await UserModel.findById(req.session.userId);
            // const series = await TaxonomyModel.find( {
            //   $and: [
            //     { type: 'series' },
            //     { lang: 'en' }
            //   ]
            // });

            const baseMatch = {
              $and: [
                { type: 'series' },
                { lang: 'en' },
              ]
            };

            if (status === 'trash') {
              baseMatch.$and.push({ status: 'trash' });
            }else{
              baseMatch.$and.push({ status: { $ne: 'trash' } });
            }

            const series = await TaxonomyModel.aggregate([
              {
                  $match: baseMatch
              },
              {
                  $lookup: {
                      from: 'tora_term_relations2',
                      localField: 'term_id',
                      foreignField: 'termId',
                      as: 'videos'
                  }
              },
              {
                  $addFields: {
                      videoCount: { $size: '$videos' } // Add a new field for video count
                  }
              },
              {
                  $project: {
                      videos: 0 // Exclude the videos array from the final result if not needed
                  }
              }
          ]);

            // res.send(series);
            const languages = await LanguageModel.find();
            // localStorage.setItem('current_lang', 'en');
            // const storedValue = localStorage.getItem('current_lang'); // Replace 'key' with your actual key

            function getTranslation(item, current_lang) {
              // Find the translation that matches the current language
              var translation = item.translations.find(function (t) {
                return t.languageCode === current_lang;
              });
          
              // If a matching translation is found, return it; otherwise, return the original title
              var title = translation ? translation.translation : "";
              var lang_name = translation ? translation.languageName : "English";
              return {title, lang_name}
            }
            let trashcount = await TaxonomyModel.countDocuments({status:"trash",type:"series"});
            let allcount = await TaxonomyModel.countDocuments({type:"series",lang:"en",status: { $ne: 'trash' }});

            res.render('series',{user, series, languages, current_lang,trashcount, status,allcount,getTranslation });
          } catch (error) {
            console.error('Error fetching series data:', error);
            res.status(500).json({ status: "error", message: "Internal server error" });
          }
    }

    static add_series = async (req, res) =>{
      let user = await UserModel.findById(req.session.userId);
      const all_cookies = req.cookies; 
      var current_lang = 'en';
      if(all_cookies.current_lang){
        var current_lang = all_cookies.current_lang;
      }
      const series = await TaxonomyModel.find( {
        $and: [
          { type: 'series' },
          { lang: current_lang }
        ]
      });
      const languages = await LanguageModel.find();
      res.render('add-series', {current_lang, series, languages, user});
    }

    static edit_series = async (req, res) =>{
        try{
          let user = await UserModel.findById(req.session.userId);
          const all_cookies = req.cookies; 
          var current_lang = 'en';
          if(all_cookies.current_lang){
            var current_lang = all_cookies.current_lang;
          }
          
          // const result = await TaxonomyModel.findById(req.params.id);
          const result = await TaxonomyModel.findOne({ $and: [
            {_id: req.params.id},
            {lang: current_lang}
          ] });
          // const result_lang = await TaxonomyModel.find({ _id: { $ne: req.params.id }, relationlId:req.params.id }, '_id title lang relationlId');
          const result_lang = await TaxonomyModel.find({ $and: [
            {relationlId: req.params.id},
            {lang: {$ne: current_lang}}
          ] }, '_id title lang relationlId');

          // res.send(result.translations);
          // const result_lang = await TaxonomyModel.find({ _id: { $ne: req.params.id } }, '_id title lang');
          // console.log(result);
          // const series = await TaxonomyModel.find();
          const series = await TaxonomyModel.find({ _id: { $ne: req.params.id }, type: 'series', lang: 'en' });

          console.log("all series ====");
          console.log(result_lang);
          const langauges = await LanguageModel.find();
          const series_log = await ToraLog.aggregate([
            {
              $match: {
                $and: [
                  { entity: 'Series' },
                 { entityId: new mongoose.Types.ObjectId(req.params.id) }, // Assuming req.params.id is the ObjectId
                ],
              },
            },
            {
              $lookup: {
                from: 'tora_users', // Name of the tora_user collection
                localField: 'user', // Field in ToraLog collection to match
                foreignField: '_id', // Field in tora_user collection to match
                as: 'userData', // Name for the merged user data field
              },
            },
          ]);

          res.render('series-edit',{series, langauges, result, result_lang, user, series_log, formatDatetime });
        }  catch (error) {
          console.error('Error fetching series data:', error);
        }
    }

    static series_translation = async(req, res) =>{
     
      const all_cookies = req.cookies;
      const current_lang = all_cookies.current_lang || 'en';
      let user = await UserModel.findById(req.session.userId);

      var groupedData = await TaxonomyModel.find({$and:[
        {type:'series'},
        {lang:'en'}
      ]});
      
      // res.send(groupedData);

      // Now you have a groupedData object with data organized by relationlId and language
      res.render('series-translation', { groupedData, user, current_lang });

    }

    static feature = async(req, res) =>{
        const all_cookies = req.cookies; 
        let user = await UserModel.findById(req.session.userId);
        var current_lang = 'en';
        if(all_cookies.current_lang){
          var current_lang = all_cookies.current_lang;
        }
        let message = req.session.message;
        delete req.session.message;
        let series = await TaxonomyModel.find({
          $and: [
            { type: 'series' },
            { lang: current_lang }
          ]
        });
        let topic = await TaxonomyModel.find({
          $and: [
            { type: 'topic' },
            { lang: current_lang }
          ]
        });
        // const cat_parent = await LanguageController.topic_parent_test(req, res);
        const cat_parent = await TaxonomyModel.find({type: 'topic'} );

        let organization = await TaxonomyModel.find({
          $and: [
            { type: 'organization' },
            { lang: current_lang }
          ]
        });

       
        // const results = await ToraFeaturesModel.find({ taxonomy_name: 'series' });
        const series_results = await ToraFeaturesModel.find({ taxonomy_name: 'series' }).select('taxonomy_id');
        const seriesIds = series_results.map(result => result.taxonomy_id);
        const topic_results = await ToraFeaturesModel.find({ taxonomy_name: 'topic' }).select('taxonomy_id');
        const topicIds = topic_results.map(result => result.taxonomy_id);
        const category_results = await ToraFeaturesModel.find({ taxonomy_name: 'category_slider' }).select('taxonomy_id');
        const categoryIds = category_results.map(result => result.taxonomy_id);

        const organization_results = await ToraFeaturesModel.find({ taxonomy_name: 'organization' }).select('taxonomy_id');
        const organizationIds = organization_results.map(result => result.taxonomy_id);
        console.log(organizationIds);
        console.log(organization);
        console.log("=== organization ids ===");

        res.render('feature', {series, topic, organization, current_lang, seriesIds, topicIds,categoryIds, organization_results, organizationIds, message, user, cat_parent});
    }

    static feature_data = async (req, res) =>{
    
      try{
        const {series, topic, category_slider, organization} = req.body;
        let user = await UserModel.findById(req.session.userId);
        const postData = {
          series,
          topic,
          category_slider,
          organization
        };
       let torafeature = await ToraFeaturesModel.deleteMany({ taxonomy_name: { $in: ['series', 'topic','category_slider','organization'] } });

      // Iterate through the postData object
        for (const taxonomyName in postData) {
          if (postData.hasOwnProperty(taxonomyName)) {
            const taxonomyIds = postData[taxonomyName];

            console.log("taxonomy ids ====");
            console.log(taxonomyIds);


            console.log(torafeature);
            console.log("=== torafeature =====");
            
            // Ensure taxonomyIds is always an array
            const taxonomyIdsArray = Array.isArray(taxonomyIds) ? taxonomyIds : [taxonomyIds];
            // Create and save a tora_features document for each taxonomyName and taxonomyId
            // taxonomyIds.forEach(async (taxonomyId) => {
            for (const taxonomyId of taxonomyIdsArray) {
              const toraFeature = new ToraFeaturesModel({
                userId: '65117e2831e976738455fb4c', // Replace with the appropriate user ID
                taxonomy_name: taxonomyName,
                taxonomy_id: taxonomyId,
                langcode: "en", // Replace with the appropriate langcode
              });

              console.log("--- feature details =====");
              console.log(toraFeature);
              console.log("== feature ids =====");
              console.log(taxonomyId);

                const savedToraFeature = await toraFeature.save();
                console.log(`Saved: ${taxonomyName} - ${taxonomyId}`);
                console.log(`Saved: savedToraFeature`);
            };

          }
        }

        req.session.message = 'Feature updated.';

        res.redirect("/portal/feature");
      }
      catch (error) {
        console.error("Error:", error);
        res.status(500).send("Internal Server Error");
      }
    }

    
}

export default SeriesController;
