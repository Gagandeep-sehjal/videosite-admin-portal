import express from 'express';
import SeriesApiController from "../controllers/Api/SeriesApiController.js";
import TopicApiController from "../controllers/Api/TopicApiController.js"
import multer from 'multer';
import path from 'path';
import OrganizationApiController from '../controllers/Api/OrganizationApiController.js';
import OrganizationController from '../controllers/OrganizationController.js';
import VideoApiController from '../controllers/Api/VideoApiController.js';
import UserApiController from '../controllers/Api/UserApiController.js';
import LanguageController from '../controllers/LanguageController.js';
import AuthenticateToken from '../middleware/auth-token.js';
import checkAdminWebAuth from '../middleware/auth-admin-midleware.js';
import UserController from '../controllers/userController.js';
const router = express.Router();


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      // Specify the directory where uploaded files will be stored
      let destinationPath = './public/uploads'; // Default destination path

       // Check if the route is for '/users/update/:id' and update the destination path accordingly
      if (req.path.startsWith('/users/update/')) {
        destinationPath = './public/uploads/users';
      }

      if(req.path.startsWith('/language')){
        destinationPath = './public/uploads/flags'
      }

      cb(null, destinationPath);
      // const uploadDir = path.join(path.resolve(), 'public', 'uploads'); // Construct an absolute path
      // cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
       // Generate a unique filename based on the current date and time
      const dateNow = new Date().toISOString().replace(/:/g, '-');
      const filename = dateNow + '-' + file.originalname;
      cb(null, filename);
    },
  });

  // Create a multer instance with the defined storage strategy
const upload = multer({ storage: storage });

router.get('/series', SeriesApiController.get_home_series);
router.post('/series', SeriesApiController.create_series);
router.get('/series/view/:id', SeriesApiController.view_single_series);
router.post('/series/update/:id',  checkAdminWebAuth,SeriesApiController.update_series);
router.post('/series/change_status/:id', checkAdminWebAuth, SeriesApiController.change_status);
router.post('/series/restore_series/:id', checkAdminWebAuth, SeriesApiController.restore_series);
router.post('/series/delete/:id', checkAdminWebAuth, SeriesApiController.delete_series); 
router.post('/series/translate', SeriesApiController.translate_series); 
router.get('/:lang?/series-home', SeriesApiController.home_series); 
router.get('/:lang?/all-series',SeriesApiController.series_videos)

router.post('/series/delete_lang/:id', SeriesApiController.delete_series_lang); 

router.get('/topics', TopicApiController.get_home_topics);
router.post('/topic',  TopicApiController.create_topics);
router.get('/topic/view/:id', TopicApiController.view_single_topic);
router.post('/topic/update/:id',  checkAdminWebAuth, TopicApiController.update_topic);
router.post('/topic/delete/:id', checkAdminWebAuth, TopicApiController.delete_topic); 
router.post('/topic/change_status/:id',  checkAdminWebAuth,TopicApiController.change_status); 
router.post('/topic/restore_topic/:id',  checkAdminWebAuth,TopicApiController.restore_topic); 
router.post('/topic/translate', TopicApiController.translate_topic); 
router.get('/:lang?/category-home-slider', TopicApiController.category_home_slider); 
router.get('/:lang?/latest-videos',VideoApiController.latest_videos); 
router.get('/:lang?/topic-home', TopicApiController.home_topics); 
router.post('/taxonomy/bulk_trash', TopicApiController.bulk_trash); 
router.post('/taxonomy/bulk_restore', TopicApiController.bulk_restore);
router.post('/taxonomy/bulk_delete', TopicApiController.bulk_delete);
router.post('/quick_edit_category', checkAdminWebAuth, TopicApiController.quick_edit_category); 

router.post('/topic/delete_lang/:id', TopicApiController.delete_topic_lang);

router.post('/organization',  OrganizationController.create_organization);
router.post('/organization/update/:id',  checkAdminWebAuth,OrganizationController.update_organization);
router.post('/organization/delete/:id', checkAdminWebAuth, OrganizationController.delete_organization); 
router.post('/quick_edit_organization',  checkAdminWebAuth, OrganizationApiController.quick_edit_organization);

router.get('/videos', VideoApiController.get_videos); 
router.post('/videos/update/:id', VideoApiController.update_videos); 
router.post('/videos/delete/:id',  VideoApiController.delete_videos); 
router.post('/videos/change_status/:id',  VideoApiController.change_status); 
router.post('/videos/restore_vid/:id',  VideoApiController.restore_vid); 
router.post('/videos/bulk_trash',  VideoApiController.bulk_trash); 
router.post('/videos/bulk_restore',  VideoApiController.bulk_restore); 
router.get('/single-video/:id',  VideoApiController.single_videos); 
router.post('/quick_video_submit/:id',  VideoApiController.quick_vid_submit); 
router.post('/bulk_video_submit',  VideoApiController.bulk_video_submit); 
router.get('/author_video/:id',VideoApiController.author_video); 
router.get('/video_detail/:id',VideoApiController.video_detail); 

router.post('/comment_post/:id',VideoApiController.comment_post); 
router.post('/likes_post/:id',VideoApiController.likes_post); 



router.get('/users', UserApiController.get_users); 
router.post('/users/update/:id',  UserApiController.update_user);
router.post('/users/delete/:id',  UserApiController.delete_user);
router.post('/user/change_status/:id',  UserApiController.change_status);
router.post('/user/restore_vid/:id',  UserApiController.restore_vid);
router.post('/user/add',  UserApiController.save_users);
router.get('/user-home',UserApiController.home_users);
router.post('/user/bulk_status_change',UserApiController.bulk_status_change);
router.post('/users/disable-access/:id',UserApiController.disable_access);
router.post('/users/enable-access/:id',UserApiController.enable_access);
router.post('/user/bulk_delete',UserApiController.bulk_delete); 
router.post('/user/bulk_restore',UserApiController.bulk_restore);



router.post('/language', LanguageController.save_language); 
router.post('/countries', LanguageController.save_countries); 
router.get('/language/edit/:id',LanguageController.edit_language);
router.post('/language/update/:id',LanguageController.update_language);
router.get('/countries/edit/:id',LanguageController.edit_countries);
router.post('/countries/update/:id',LanguageController.update_countries);




router.get('/related-videos',VideoApiController.related_videos);




router.get('/users/reset-password/:id/:token', UserApiController.resetpass_users); 
router.post('/users/reset-password/:id/:token', UserApiController.update_password); 
router.post('/users/email/:id',  UserApiController.reset_user);
router.post('/reset-password', UserController.setresetpassoword);
router.post('/users/reset-pass-email/:id', UserController.sendresetemail);
 

export default router;


