import UserModel from "../models/User.js";
import bcrypt from 'bcrypt';

const checkAdminWebAuth = async (req, res, next) =>{
    console.log(req.session);
    console.log("can't come Admin path");
    if (req.session.userId) {
        const result = await UserModel.findOne({email:req.session.email});
        if(result != null && (result.role == 'admin' || result.role == 'speaker') ){
            console.log("you are admin brother ====");
            
            next();
        }else{
            console.log("you can't go to dashboard ----");
            let message = 'You are not authorize.';
            res.render('error',{message})
        }
    } else {
        // User is not authenticated, redirect to the login page
        console.log("you can't go to dashboard ----");
        res.redirect('/login');
    }

}

export default checkAdminWebAuth;